"""Post-run numerical and failure-mode audit. Does not change or retune WRL3."""
from collections import Counter
import ctypes
import json
from pathlib import Path
import sys
import warnings

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
import torch
from torch import nn
from hydraulic import METHODS,SENSORS,TARGETS,scale_from_train,dtw,save_json


def python_dtw(q,g):
    length=len(q);d=np.full((length+1,length+1),np.inf);d[0,0]=0
    for i in range(1,length+1):
        for j in range(max(1,i-3),min(length,i+3)+1):
            cost=float(np.sum((q[i-1]-g[j-1])**2))
            d[i,j]=cost+min(d[i-1,j],d[i,j-1],d[i-1,j-1])
    return d[-1,-1]


def main():
    root,out=map(Path,sys.argv[1:]);a=np.load(root/'features.npz')
    torch.set_num_threads(2)
    lib=ctypes.CDLL('/tmp/wrl3-dtw.dylib');records=[];warning_counts=Counter()
    for file in sorted(root.glob('*-cooler*-n*-s*.npz')):
        data=np.load(file);target=file.name.split('-')[0];seed=int(file.stem.rsplit('s',1)[1])
        train,query=data['train_ids'],data['query_ids']
        labels=np.unique(a['profile'][:,TARGETS[target]])
        y=np.searchsorted(labels,a['profile'][:,TARGETS[target]])
        f,_,_=scale_from_train(a['features'],train)
        t,_,_=scale_from_train(a['temporal'],train,True)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            logistic=LogisticRegression(C=1,max_iter=2000).fit(f[train],y[train])
            lp=logistic.predict_proba(f[query])
        warning_counts.update(str(w.message) for w in caught)
        # Avoid BLAS entirely for the independent multinomial logit computation.
        logits=np.einsum('nf,kf->nk',f[query],logistic.coef_,optimize=False)+logistic.intercept_
        probabilities=np.exp(logits-logits.max(1,keepdims=True));probabilities/=probabilities.sum(1,keepdims=True)
        error=float(np.max(abs(lp-probabilities)))
        assert error<1e-10 and np.isfinite(probabilities).all()
        np.testing.assert_array_equal(lp,data['probabilities'][METHODS.index('logistic')])
        train_logits=np.einsum('nf,kf->nk',f[train],logistic.coef_,optimize=False)+logistic.intercept_
        p=np.exp(train_logits-train_logits.max(1,keepdims=True));p/=p.sum(1,keepdims=True)
        residual=p-np.eye(4)[y[train]]
        gradient=np.einsum('nk,nf->kf',residual,f[train],optimize=False)/len(train)+logistic.coef_/len(train)
        stationarity=max(float(abs(gradient).max()),float(abs(residual.mean(0)).max()))
        assert stationarity<.001,(file.name,stationarity)
        forest=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,
                   class_weight='balanced',n_jobs=1,random_state=seed).fit(f[train],y[train])
        np.testing.assert_array_equal(forest.predict_proba(f[query]),data['probabilities'][METHODS.index('rf')])
        m=nn.Sequential(nn.Conv1d(14,16,5,padding=2),nn.ReLU(),nn.Conv1d(16,32,5,padding=2),
                         nn.ReLU(),nn.AdaptiveAvgPool1d(10),nn.Flatten(),nn.Linear(320,4))
        m.load_state_dict(torch.load(file.with_suffix('.pt'),weights_only=True));m.eval()
        with torch.no_grad(): p=m(torch.tensor(t[query].transpose(0,2,1),dtype=torch.float32)).softmax(1).numpy()
        np.testing.assert_array_equal(p.astype('f8'),data['probabilities'][METHODS.index('tcn')])
        ref=int(data['dtw_ids'][0,0]);q=int(query[0])
        expected=python_dtw(t[q],t[ref]);actual=float(data['dtw_cost'][0,0])
        np.testing.assert_allclose(actual,expected,rtol=1e-12,atol=1e-8)
        # Diagnose existing feature distances, without recomputing new predictions.
        difference=f[query]-f[data['knn_ids'][:,0]]
        channel_cost=(difference.reshape(len(query),14,20)**2).sum(2)
        share=(channel_cost/np.maximum(channel_cost.sum(1,keepdims=True),1e-30)).mean(0)
        records.append({'case':file.stem,'logistic_independent_probability_max_error':error,
                        'logistic_stationarity_max_abs_gradient':stationarity,
                        'logistic_iterations':logistic.n_iter_.tolist(),'rf_refit_exact':True,'cnn_checkpoint_exact':True,
                        'dtw_real_pair_relative_error':abs(actual-expected)/max(1.,abs(expected)),
                        'nearest_distance_share_by_sensor':dict(zip(SENSORS,map(float,share))),
                        'temperature_distance_share':float(sum(share[SENSORS.index(s)] for s in ('TS1','TS2','TS3','TS4'))),
                        'max_abs_heldout_feature_z':float(abs(f[query]).max())})
    assert len(records)==60
    result={'scope':'Post-run audit; no changed predictions, parameters or selection',
             'cases_checked':len(records),'captured_refit_warnings':dict(warning_counts),'cases':records,
             'max_independent_logistic_error':max(r['logistic_independent_probability_max_error'] for r in records),
             'max_stationarity_gradient':max(r['logistic_stationarity_max_abs_gradient'] for r in records),
             'max_dtw_relative_error':max(r['dtw_real_pair_relative_error'] for r in records),
             'mean_temperature_distance_share':float(np.mean([r['temperature_distance_share'] for r in records]))}
    save_json(out,result)
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))


if __name__=='__main__':main()
