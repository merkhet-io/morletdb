"""WRL2: frozen controlled-budget forecasting. External upstream code is not vendored."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import resource
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

L, H, C = 720, 96, 7
PERIODS = (4, 2, 1)
METHODS = ('nlinear', 'raft', 'raft-zero', 'raft-random', 'raft-shuffled',
           'xlstm', 'xlstm-retrieval', 'xlstm-random')
HASHES = {'ETTh1': 'f18de3ad269cef59bb07b5438d79bb3042d3be49bdeecf01c1cd6d29695ee066',
          'ETTh2': 'a3dc2c597b9218c7ce1cd55eb77b283fd459a1d09d753063f944967dd6b9218b'}


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def split_starts(l=L, h=H):
    return {'train': np.arange(8640-l-h+1),
            'valid': np.arange(8640-l, 11520-l-h+1),
            'test': np.arange(11520-l, 14400-l-h+1)}


def standardize(a):
    mu, sd = a[:8640].mean(0), a[:8640].std(0)
    assert np.isfinite(a).all() and (sd > 0).all()
    return ((a-mu)/sd).astype('f4'), mu, sd


def eligible(n, start, train, length=L+H):
    return np.flatnonzero(np.abs(np.arange(n)-start) >= length) if train else np.arange(n)


def windows(a, ids, l=L, h=H):
    return (torch.from_numpy(np.stack([a[i:i+l] for i in ids])),
            torch.from_numpy(np.stack([a[i+l:i+l+h] for i in ids])))


def json_write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def prepare(a, starts, out):
    from layers.Retrieval import RetrievalTool
    rt = RetrievalTool(L, H, C, n_period=3, topm=20)
    x, y = windows(a, starts['train'])
    rt.train_data_all, rt.y_data_all = x, y
    rt.train_data_all_mg, _ = rt.decompose_mg(x)
    rt.y_data_all_mg, _ = rt.decompose_mg(y)
    rt.n_train = len(x)
    # Cache original normalized keys. This avoids repeating normalization on every
    # query batch, with identical arithmetic and original top-k/weighted outputs.
    flat = rt.train_data_all_mg.flatten(start_dim=2)
    keys = F.normalize(flat-flat.mean(2, keepdim=True), dim=2)
    values = rt.y_data_all_mg
    rng = np.random.default_rng(20261123)
    timing = {}
    cache = {v: {} for v in ('raft', 'random', 'shuffled')}
    for split, ids in starts.items():
        t = time.perf_counter()
        collected = {v: [] for v in cache}
        for j in range(0, len(ids), 64):
            ix = ids[j:j+64]
            q, _ = windows(a, ix)
            qm, _ = rt.decompose_mg(q)
            qf = qm.flatten(start_dim=2)
            qn = F.normalize(qf-qf.mean(2, keepdim=True), dim=2)
            sims = torch.bmm(qn, keys.transpose(1, 2))
            if split == 'train':
                mask = abs(torch.arange(len(x))[None, :]-torch.tensor(ix)[:, None]) < L+H
                sims.masked_fill_(mask[None], -float('inf'))
            scores, chosen = sims.topk(20, dim=2)
            weights = (scores/.1).softmax(2)
            random_ids = np.empty((3,len(ix),20), dtype='i8')
            shuffle_ids = np.empty_like(random_ids)
            for b, start in enumerate(ix):
                candidates = eligible(len(x), start, split == 'train')
                for g in range(3):
                    random_ids[g,b] = rng.choice(candidates,20,replace=False)
                    shuffle_ids[g,b] = rng.choice(candidates,20,replace=False)
            outputs = {}
            for name, index, w in [('raft',chosen,weights),
                                    ('random',torch.from_numpy(random_ids),torch.full_like(weights,1/20)),
                                    ('shuffled',torch.from_numpy(shuffle_ids),weights)]:
                outputs[name] = torch.stack([(values[g,index[g]]*w[g,:,:,None,None]).sum(1)
                                             for g in range(3)])
                collected[name].append(outputs[name])
            if j == 0:
                with torch.no_grad():
                    expected = rt.retrieve(q,torch.tensor(ix),train=split=='train')
                error = (expected-outputs['raft']).abs().max().item()
                assert error < 2e-5, (split,error)
                print(json.dumps({'parity':split,'max_abs':error}),flush=True)
            if j % 1024 == 0:
                print(json.dumps({'retrieving':split,'done':j,'total':len(ids)}),flush=True)
        for v in cache:
            cache[v][split] = torch.cat(collected[v],dim=1)
        timing[split] = time.perf_counter()-t
    torch.save(cache,out/'retrieval.pt')
    json_write(out/'retrieval.json',{'seconds':timing,'gallery':len(x),
               'cache_bytes':(out/'retrieval.pt').stat().st_size,
               'source_train_f32_bytes':a[:8640].nbytes,
               'materialized_gallery_tensor_bytes':sum(v.numel()*v.element_size() for v in
                  (x,y,rt.train_data_all_mg,rt.y_data_all_mg)),
               'note':'Memory sizes are accounting, not database benchmarks.'})
    return cache


class NLinear(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(L,H)
    def forward(self,x,index,mode):
        offset = x[:,-1:,:].detach()
        return self.linear((x-offset).transpose(1,2)).transpose(1,2)+offset


def make_model(name, cache):
    if name == 'nlinear':
        return NLinear()
    if name.startswith('raft'):
        from models.RAFT import Model
        m = Model(SimpleNamespace(gpu=0,task_name='long_term_forecast',seq_len=L,
                    pred_len=H,enc_in=C,n_period=3,topm=20))
        m.device = torch.device('cpu')
        key = {'raft':'raft','raft-zero':'raft','raft-random':'random','raft-shuffled':'shuffled'}[name]
        m.retrieval_dict = cache[key] if name != 'raft-zero' else {k:torch.zeros_like(v) for k,v in cache[key].items()}
        del m.rt
        return m
    import xlstm_mixer.models.xlstm_mixer as xm
    from xlstm import sLSTMLayerConfig
    xm.sLSTMLayerConfig = lambda **kw: sLSTMLayerConfig(**kw,backend='vanilla',dtype='float32')
    class Mixer(nn.Module):
        def __init__(self):
            super().__init__()
            self.base = xm.xLSTMMixer(pred_len=H,seq_len=L,enc_in=C,num_mem_tokens=2,xlstm_dropout=.25)
            self.augmented = name != 'xlstm'
            if self.augmented:
                self.adapters = nn.ModuleList([nn.Linear(H//g,H) for g in PERIODS])
                for layer in self.adapters:
                    nn.init.zeros_(layer.weight)
                    nn.init.zeros_(layer.bias)
        def forward(self,x,index,mode):
            y = self.base.forecast(x,None)
            if self.augmented:
                key = 'raft' if name == 'xlstm-retrieval' else 'random'
                values = cache[key][mode][:,index]
                for layer,g,v in zip(self.adapters,PERIODS,values):
                    y = y+layer(v[:,::g,:].transpose(1,2)).transpose(1,2)
            return y
    return Mixer()


def evaluate(model,a,ids,mode):
    model.eval()
    errors = []
    with torch.no_grad():
        for j in range(0,len(ids),64):
            x,y = windows(a,ids[j:j+64])
            p = model(x,torch.arange(j,min(j+64,len(ids))),mode)
            assert p.shape == y.shape and torch.isfinite(p).all()
            d = (p-y).double()
            errors.append(torch.stack((d.square().mean((1,2)),d.abs().mean((1,2))),dim=1).numpy())
    return np.concatenate(errors)


def fit(name,seed,a,starts,cache,out):
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = make_model(name,cache)
    optimizer = torch.optim.Adam(model.parameters(),lr=.001)
    best, state, history = float('inf'), None, []
    t = time.perf_counter()
    for epoch in range(10):
        model.train()
        lr = .001/2*(1+math.cos(math.pi*epoch/10))
        for group in optimizer.param_groups:
            group['lr'] = lr
        # Independent batch RNG makes permutations identical across architectures.
        order = np.random.default_rng(seed*100+epoch).permutation(len(starts['train']))
        loss_sum = 0.
        for j in range(0,len(order),32):
            ids = order[j:j+32]
            x,y = windows(a,starts['train'][ids])
            optimizer.zero_grad()
            prediction = model(x,torch.tensor(ids),'train')
            loss = F.mse_loss(prediction,y)
            assert torch.isfinite(loss)
            loss.backward()
            optimizer.step()
            loss_sum += loss.item()*len(ids)
        val = evaluate(model,a,starts['valid'],'valid')[:,0].mean().item()
        history.append({'epoch':epoch+1,'train_mse':loss_sum/len(order),'valid_mse':val,'lr':lr})
        if val < best:
            best, state = val, copy.deepcopy(model.state_dict())
            best_epoch = epoch+1
        print(json.dumps({'method':name,'seed':seed,**history[-1]}),flush=True)
    train_seconds = time.perf_counter()-t
    model.load_state_dict(state)
    torch.save(state,out/f'{name}-{seed}.pt')
    t = time.perf_counter()
    errors = evaluate(model,a,starts['test'],'test')
    np.save(out/f'{name}-{seed}-errors.npy',errors)
    result = {'model':name,'seed':seed,'mse':float(errors[:,0].mean()),'mae':float(errors[:,1].mean()),
              'best_epoch':best_epoch,'valid_mse':best,'history':history,
              'parameters':sum(p.numel() for p in model.parameters()),
              'train_seconds':train_seconds,'test_seconds':time.perf_counter()-t,
              'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              'weekly_mse':[float(errors[i:i+168,0].mean()) for i in range(0,len(errors),168)]}
    json_write(out/f'{name}-{seed}.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('history','weekly_mse')}),flush=True)


def naive(a,starts,out):
    for name,period in [('persistence',1),('daily',24),('weekly',168)]:
        errors=[]
        for ids in np.array_split(starts['test'],45):
            x,y=windows(a,ids)
            p=x[:,-period:,:][:,torch.arange(H)%period,:]
            d=(p-y).double()
            errors.append(torch.stack((d.square().mean((1,2)),d.abs().mean((1,2))),dim=1).numpy())
        errors=np.concatenate(errors)
        np.save(out/f'{name}-errors.npy',errors)
        json_write(out/f'{name}.json',{'model':name,'mse':float(errors[:,0].mean()),'mae':float(errors[:,1].mean()),
                   'weekly_mse':[float(errors[i:i+168,0].mean()) for i in range(0,len(errors),168)]})


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data',type=Path,required=True)
    p.add_argument('--dataset',choices=HASHES,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--raft',default='/tmp/waverag-anchor-raft')
    p.add_argument('--xlstm',default='/tmp/waverag-xlstm-mixer')
    p.add_argument('--methods',nargs='+',default=list(METHODS),choices=METHODS)
    args=p.parse_args()
    sys.path[:0]=[args.raft,args.xlstm]
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    assert digest(args.data)==HASHES[args.dataset]
    a,mu,sd=standardize(np.loadtxt(args.data,delimiter=',',skiprows=1,usecols=range(1,8))[:14400])
    starts=split_starts()
    args.out.mkdir(parents=True,exist_ok=True)
    manifest={'dataset':args.dataset,'data_sha256':digest(args.data),'harness_sha256':digest(__file__),
              'protocol_sha256':digest(Path(__file__).with_name('FORECAST_PROTOCOL.md')),
              'torch':torch.__version__,'numpy':np.__version__,'python':sys.version,
              'train_mean':mu.tolist(),'train_std':sd.tolist(),'windows':{k:len(v) for k,v in starts.items()}}
    mp=args.out/'manifest.json'
    if mp.exists():
        assert json.loads(mp.read_text())==manifest,'Do not resume changed harness/protocol'
    else:
        json_write(mp,manifest)
    cache_path=args.out/'retrieval.pt'
    cache=torch.load(cache_path,weights_only=True) if cache_path.exists() else prepare(a,starts,args.out)
    naive(a,starts,args.out)
    for name in args.methods:
        for seed in range(3):
            if not (args.out/f'{name}-{seed}.json').exists():
                fit(name,seed,a,starts,cache,args.out)


if __name__=='__main__':
    main()
