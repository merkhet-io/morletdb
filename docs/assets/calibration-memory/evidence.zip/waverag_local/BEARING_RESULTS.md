# WRL5: fresh bearings support local calibration, not a learned-memory advantage

Completed locally on 2026-11-23. [Protocol](BEARING_PROTOCOL.md),
[full results](results/bearing_table.md), [summary](results/bearing_summary.json),
[source-only selections](results/bearing_source_selection.json),
[independent audit](results/bearing_audit.json), [evidence examples](results/bearing_examples.json).

## Outcome

On two previously unused HUST bearing types, adding four seconds of labelled signal
per class improves learned-embedding retrieval from .4537 to .8680 recording
macro-F1. Spectral-feature retrieval improves from .3416 to .9467. Ordinary
adaptation is at least as strong: the best weighted forest reaches .9587, and a
weighted RBF SVM reaches .9467 with only half a second per class.

**The predeclared superiority criterion fails.** Learned retrieval trails every
ordinary adaptation baseline at the largest support budget, as well as spectral
retrieval. It does beat the fixed neural classifier and random/shuffled references.
This confirms a useful local-calibration effect on a fresh dataset, but not a
special neural-memory advantage, cross-factory generalization or database moat.

| Method | No local signal | 0.5 sec/class | 1 sec/class | 4 sec/class |
|---|---:|---:|---:|---:|
| Frozen neural classifier | .4077 | .4077 | .4077 | .4077 |
| Spectral-feature retrieval | .3416 | .3416 | .3416 | .9467 |
| Learned-embedding retrieval | .4537 | .4537 | .4737 | .8680 |
| Random references | .2244 | .1864 | .1884 | .1089 |
| Shuffled reference labels | .1620 | .1098 | .1935 | .1559 |
| Adapted logistic regression | .1800 | .6433 | .7067 | .9467 |
| Adapted random forest | .2857 | .6787 | .7227 | .9360 |
| Adapted weighted forest | .2857 | .6373 | .7547 | **.9587** |
| Adapted weighted RBF SVM | .4000 | **.9467** | **.9467** | .9467 |

Values are mean acquisition-level macro-F1 over five seeds and two target bearing
types. They are not accuracy percentages or independent population estimates.
Every positive support budget uses the SAME five labelled acquisitions per target
(one per class); durations change, not the number of independently obtained labels.
Four seconds means eight adjacent half-second windows from one acquisition.

![Measured fresh-bearing calibration curves](results/bearing_memory_growth.png)

## What was new and how it was separated

Source: Nguyen Duc Thuan and Hoang Si Hong,
[HUST bearing, Mendeley Data V3](https://data.mendeley.com/datasets/cbv7jyx4p9/3),
DOI10.17632/cbv7jyx4p9.3, CC BY4.0;
[original paper](https://link.springer.com/article/10.1186/s13104-023-06400-4).
This is the Hanoi dataset, distinct from Huazhong's similarly named dataset.
No HUST experiments or files were found in the existing project before this study.

We downloaded 75 original MAT recordings for the five conditions common to all
bearing types: normal, inner fault, outer fault, inner+outer, and outer+ball.
Source development uses types 6204/6205; source validation uses 6206. Final source
training includes all three. Targets 6207/6208 enter only fixed feature extraction
and final evaluation after the protocol freeze. Each target's unloaded recordings
supply support; separate 200/400 W recordings supply queries. No source/target or
support/query acquisition overlap occurs. Source and target nevertheless share one
laboratory rig; target support and query share a bearing/fault condition across loads.

The source supplies 45 labelled recordings, yielding 873 source windows. Targets
have 10 query recordings each, yielding 200 and 190 query windows. Labels for all
five target conditions are assumed available in the unloaded support recordings.
That is supervised calibration, not discovery of an unknown fault or deployment
with only healthy examples. The paper's physical-specimen counts are not fully
consistent with the file inventory, so claims use bearing-type/acquisition groups.

Raw MAT `data` arrays are untouched float64 samples. Sample rate 51200 Hz comes from
the original documentation. MATLAB `fs` is shaft frequency (e.g. 24.93 Hz), not
sample rate. Calibration units are not inferred. Every reference retains the
original filename, SHA256, rate and half-open sample interval.

## Representation and model-selection evidence

The candidate representation uses 128 Welch spectral-energy bands, 64 envelope
spectral bands and eight amplitude/distribution statistics. A 64-dimensional
neural embedding is learned from these 200 features. The two candidates differ by
whether supervised contrastive loss accompanies classification loss. Amplitude
statistics remain available; derived spectra do not replace or resample raw data.

Source-only validation selected the contrastive candidate (.4490 mean recording
F1) over classification-only (.3549). However, logistic regression and RBF SVM
both reached .7333, and the forest .5000 on that validation type. **We did not
establish a stronger learned representation.** Each neural seed selected epoch 1
by validation cross entropy; later training did not lower that loss. These choices
were saved and committed before target confirmation. Final source training followed
those epoch counts without target-dependent changes.

Nearest-neighbour prediction uses five uniform votes. Embeddings and source
classifiers remain fixed as support grows. Conventional models refit on the same
source/support labels. Weighted forest/SVM give target support total weight equal
to source total weight; unweighted comparators are also retained. This prevents
concluding retrieval helps merely because conventional models ignore scarce local
labels. The SVM uses uncalibrated softmax decision scores, not probability-calibrated
risk estimates.

## What the new evidence says about episodic memory

- **Useful examples can overcome poor transfer without retraining the encoder.**
  Learned retrieval improves 46.03 points over the frozen classifier at four seconds
  per class. Random/shuffled memories do not reproduce that improvement.
- **Much of the benefit is local calibration.** At four seconds, 90.60% of retrieved
  neighbours are target-support windows. Retrieved-label agreement rises from 47.06%
  without local support to 89.92%; random agreement is 19.38% at the largest budget.
  These are window-level diagnostic agreements, not explanations or causal evidence.
- **Learned encoding is not necessary for the observed high score.** Spectral
  retrieval reaches .9467 without training a neural encoder. It is 1.20 points below
  the best ordinary baseline; this small gap does not establish statistical equivalence.
- **Ordinary adaptation uses short calibration signals more effectively here.**
  At half a second/class, weighted SVM is .9467 while spectral and learned retrieval
  remain .3416/.4537. Same label count, different observed signal duration.
- **Retrieval aggregation is a plausible bottleneck, not a proven fix.** With only
  one or two support windows per class, five-neighbour uniform voting can still be
  dominated by older source windows. Target-neighbour share is 18.11%/36.59% at
  those budgets versus 90.60% at eight. The experiment did not retune k or introduce
  acquisition-aware voting after observing this. Correlated windows are not eight
  independent experiences.
- **Performance varies by target.** At four seconds/class, learned retrieval is
  .7573 on 6207 and .9787 on 6208; spectral retrieval is1.0000/.8933. A pooled number
  cannot establish a uniformly better method.

No statistical significance claim is made from two bearing-type groups and repeated
seeds. Complete per-load, per-acquisition predictions and paired disagreements are
saved. Generated evidence cards use a deterministic first-window-per-class rule,
include failures, and are explicitly window-level examples, not cherry-picked
recording-level explanations.

## Freeze, correction, verification

- Initial protocol/harness freeze: 2011507, before target files were downloaded.
  One source-only file N400.mat had been inspected for schema at discovery.
- Initial preparation failed before any model training: the uniform 512000-sample
  assumption did not hold. A shape-only inventory found six 512001-sample files,
  three shorter source OB recordings and one shorter target recording. The
  [pre-training amendment](BEARING_PROTOCOL.md#pre-training-schema-amendment-2026-11-23)
  in 813d49a uses complete half-second windows and explicitly records unused tails.
  Failed logs and all original files are preserved. No scoring preceded this fix.
- Source-only selections were committed in 4e4e3df before confirmation. All frozen
  input/harness/protocol hashes match. No tuning or rerun followed target scores.
- Eight new contract tests plus 20 existing research tests pass (28 total).
  They cover grouped splits, nested support, source-only scaling, independent
  contrastive-loss fixtures, feature partitioning, ranking ties, query-label
  isolation, recording-level metrics and variable-length/trailing-sample handling.
- All 75 publisher SHA256s match. Independent FFT-based Welch/envelope extraction
  reconstructs all 1463 model windows; maximum feature error 1.34e-15.
- All 10 development checkpoints and five final encoders replay exactly. All 360
  target prediction sets and both per-load breakdowns are independently checked.
  All spectral and embedding nearest rankings match independent distance sums and
  tuple sorting. Every retrieved reference belongs to an eligible gallery and has
  an acquisition distinct from its query.
- Numerical matmul warnings from the local NumPy/scikit-learn stack are retained.
  Independent non-BLAS logistic predictions differ by at most 2.11e-15; maximum
  final objective-gradient component 9.78e-5 is below the 1e-4 default tolerance.
  All 80 forest and 40 SVM refits reproduce predictions exactly.
- Learned retrieval averages about .089 ms per window at 913 gallery windows, measured
  as elapsed batch time divided by query count. It excludes feature extraction,
  encoding, storage I/O and serving overhead. No inference-latency advantage over
  adaptation or production database performance was tested.
- Local precheck, Markdown-link and diff checks pass. Database integration tests
  are inapplicable: no SQL, migrations, application or website changes were made.

## Decision

The useful product hypothesis is now more specific: **an inspectable archive of
labelled calibration recordings can support adapting diagnosis to new equipment
and loads.** Retrieval is one consumer of that archive; ordinary classifiers can
benefit just as much or more. The archive's usefulness should be tested separately
from claims that a learned memory model or a new database extension is necessary.

The next genuinely different scientific test would need independent physical
specimens and episode-level sampling/aggregation, with any alternatives frozen
before seeing new outcomes. A stronger neural representation has not been achieved
by this finite candidate comparison. JEPA, xLSTM, repair-outcome memory and a
MorletDB serving advantage remain untested. No new extension is justified by WRL5.

## Reproduce

From the isolated worktree using the existing pinned research environment:

```sh
RESEARCH_PY=/Users/zin/sophia/morletdb/.venv-research/bin/python
RESEARCH_OUT=/tmp/wrl5-reproduction
$RESEARCH_PY -m unittest discover -s research/waverag_local -p 'test_*.py' -v
# Each stage refuses to overwrite its primary completed output.
mkdir -p "$RESEARCH_OUT"
cp /Users/zin/sophia/morletdb/data/wrl5-20261123/source_metadata.json "$RESEARCH_OUT/"
$RESEARCH_PY research/waverag_local/download_bearing.py --out "$RESEARCH_OUT"
$RESEARCH_PY research/waverag_local/bearing_memory.py prepare --out "$RESEARCH_OUT"
$RESEARCH_PY research/waverag_local/bearing_memory.py select --out "$RESEARCH_OUT"
$RESEARCH_PY research/waverag_local/bearing_memory.py confirm --out "$RESEARCH_OUT"
$RESEARCH_PY research/waverag_local/summarize_bearing_memory.py --out "$RESEARCH_OUT" --destination /tmp/wrl5-summary
$RESEARCH_PY research/waverag_local/audit_bearing_memory.py --out "$RESEARCH_OUT"
```

Raw recordings, metadata, features, models, per-query predictions and logs are
persisted under ignored `data/wrl5-20261123/` (~520MB). Tracked summaries, source
manifests and artifact hashes make the evidence reviewable without committing raw
recordings. Prior WRL1–4 evidence and unrelated user work remain intact. Everything
stays local on `research/waverag-local-evidence`; no PR was opened or pushed.
