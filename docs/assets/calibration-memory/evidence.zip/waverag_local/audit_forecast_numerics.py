"""Independent linear arithmetic and persisted-checkpoint replay; no tuning."""
import json
from pathlib import Path
import sys

import numpy as np
import torch

from forecast import L, make_model, evaluate, split_starts, standardize, windows


def main():
    root,out=map(Path,sys.argv[1:])
    sys.path[:0]=['/tmp/waverag-anchor-raft','/tmp/waverag-xlstm-mixer']
    torch.set_num_threads(2)
    result={}
    for ds in ('ETTh1','ETTh2'):
        folder=root/ds
        a,_,_=standardize(np.loadtxt('/tmp/waverag-anchor-'+ds+'.csv',delimiter=',',
                                    skiprows=1,usecols=range(1,8))[:14400])
        starts=split_starts()
        cache=torch.load(folder/'retrieval.pt',weights_only=True)
        model=make_model('nlinear',cache)
        model.load_state_dict(torch.load(folder/'nlinear-0.pt',weights_only=True))
        x,_=windows(a,starts['test'][:16])
        with torch.no_grad(): actual=model(x,torch.arange(16),'test').numpy()
        # Independent float64 accumulation over the exact float32-centered input.
        centered=(x-x[:,-1:,:]).numpy().astype('f8')
        weight=model.linear.weight.detach().numpy().astype('f8')
        bias=model.linear.bias.detach().numpy().astype('f8')
        expected=np.einsum('blc,hl->bhc',centered,weight,optimize=False)+bias[None,:,None]+x[:,-1:,:].numpy()
        error=float(np.max(abs(actual-expected)))
        assert error<2e-5,error
        replay={}
        for name in ('nlinear','raft','xlstm','xlstm-retrieval','xlstm-random'):
            m=make_model(name,cache)
            m.load_state_dict(torch.load(folder/f'{name}-0.pt',weights_only=True))
            new=evaluate(m,a,starts['test'],'test')
            old=np.load(folder/f'{name}-0-errors.npy')
            delta=float(np.max(abs(new-old)))
            assert delta<1e-10,(ds,name,delta)
            replay[name]=delta
        result[ds]={'independent_nlinear_max_abs_error':error,
                    'checkpoint_replay_per_query_errors_max_delta':replay}
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
