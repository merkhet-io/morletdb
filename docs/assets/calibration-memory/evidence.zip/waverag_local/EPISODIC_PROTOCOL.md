# WRL4: learned representations and episodic hydraulic diagnosis

Exploratory, pre-scoring protocol, 2026-11-23. WRL3 data have already informed this
hypothesis; no independent confirmation or fleet/brain/JEPA claim. No product changes.

## Hypothesis and data
A frozen supervised signal encoder plus a source-trained memory gate can improve
component diagnosis when a few labelled episodes from a new cooler condition are
added, beyond encoder-only, random memory, and ordinary adaptation.
Use the unchanged WRL3 hydraulic ZIP and derived features (archive SHA256
24128aad2ee45eea7e6b63ebbd9992cdf25d0483a2cebefbfc13bc69079af1f2).
Physical signals are 60x14 one-second means, explicitly lossy model views, not raw
waveforms. Original samples and source.json specifications remain authoritative.
Stable cycles only (oracle flag=0); targets valve and accumulator, four classes each.
Cooler holds 3,20,100; seeds 0..4. One rig, not independent machines.

## Fixed split and information budget
For each target/cooler, deterministic seed-independent block permutation (seed4400
+ target column*100 + held cooler). Each held-cooler class has12 stable blocks:
first8 support pool, last4 test. Test uses all stable cycles in those16 blocks.
For each source cooler/class, first8 blocks train, remaining4 validation. Select one
stable cycle per train/validation/support block using seed440000+seed. Thus64 source
training labels and32 validation labels. All methods have access to these96 labels.
Encoder fits64 labels; validation selects its checkpoint. RF/logistic adaptation
fit all96 source labels, making them stronger information-matched baselines.
Support budgets0,1,2,8/class use a nested prefix of the8 support blocks; same test
blocks for every budget and seed. No support/test block enters encoder scaling,
training, checkpoint selection, or gate fitting. Labels used for balanced sampling
are oracle experimental information, not a real label-discovery workflow.
This is offline support/query evaluation, not chronological replay. No acquisition
order or component condition labels are input features or retrieval filters.

## Fixed algorithms
Training-only standardization uses temporal mean/std across64 training recordings;
statistical features use their corresponding training-only mean/std. Scale below
1e-6 becomes1; this is explicit numerical protection, not a fitted parameter. All
14 physical channels retained. No augmentation assuming amplitude is irrelevant.
Encoder: Conv1d14->32,k5,pad2,ReLU,Conv32->64,k5,pad2,ReLU,adaptive average pool6,
flatten,Linear384->64,tanh,L2 normalization. Linear64->4 classifier. Adam .001,
weight_decay .0001, batch32,100 epochs, two CPU threads, float32. Choose earliest
lowest validation cross entropy. Store every loss and chosen checkpoint.

Retrieval: exact squared Euclidean distance of unit embeddings (equivalent cosine
ranking), deterministic cycle-ID ties, top5, uniform label votes. Statistical
baseline uses standardized280-feature Euclidean distance, same top5. Gallery at
evaluation comprises all96 source episodes plus currently available support.

Gate: sigmoid linear function of five inputs: base max probability, memory max
probability, mean selected squared embedding distance, base-memory class agreement,
and entropy(memory)/log4. Fit on32 source validation episodes with each episode's
gallery restricted to the OTHER source cooler's32 training episodes. Frozen
encoder. Concatenate genuine and random-reference examples (64 rows); optimize
negative log likelihood of (1-gate)*base + gate*memory for300 full-batch Adam .02
steps, weight_decay .01. Init all gate weights/bias0. No test tuning or gate refit
when target episodes are added. The same gate/encoder weights serve nearest,
random and shuffled-label controls; recompute gate inputs for each control.

Methods: stat-knn, encoder-only, embedding-knn, gated-memory, gated-random,
gated-shuffled, adapted-logistic (C1,max_iter2000 on frozen embeddings), adapted-RF
(200 trees,max_features=sqrt,min_samples_leaf1 on statistical features). Adapted
models refit using all source plus support labels, no other hyperparameters.
Random chooses5 eligible references without replacement per query. Shuffle permutes
gallery labels globally with deterministic seed; never modifies stored truth.
Additional stress control: feed gate random references all carrying the encoder's
least-probable class; diagnostic only, not a realistic unknown-detection benchmark.

## Outcomes and advance rule
Primary block macro-F1, aggregating cycle probabilities then argmax. Equal weight
seeds then cooler holds. Report both targets and ALL budgets. Primary decision at
8 support/class, separately each target: gated-memory must beat encoder-only,
gated-random, gated-shuffled and BOTH adapted baselines by >=.03 absolute macro-F1,
and improve versus encoder-only and strongest adapted baseline in every held cooler
(seed mean). No selecting a favourable target after observing results: report both
flags. Lower budgets characterize memory benefit, not additional pass opportunities.
Also compare embedding-knn with stat-knn and encoder-only; label purity, memory gate
mean, harmful/helpful changed block predictions, memory growth, wall-clock inference
latency (batch elapsed per cycle, not serving p95). Stress control reports gate and
accuracy degradation, no forced pass rule. Unknown-state rejection is NOT tested.
Paired block bootstrap (2000 draws, seed4404) within target/class/cooler, keeping
seeds paired on the same block, estimates descriptive intervals on primary differences.
These intervals do not represent uncertainty across factories or independent machines.

## Integrity and stopping
Freeze protocol and harness before real training/scoring. Test disjoint block splits,
nested support, train-only scaling, deterministic ties, gate no-memory limit and
mixed probabilities. Save checkpoints, scalers, query/gallery/support IDs, retrieved
IDs, distances, predictions, training losses, timing and hashes. Assert only eligible
episodes are returned. Independently recompute metrics and nearest rankings; replay
saved checkpoints and verify source references. Do not tune after results; retain
negative outcomes. No new dependencies, GPU, external API, LLM, SQL, JEPA or xLSTM
needed for this first isolated mechanism test. A positive result warrants a new
untouched dataset and encoder comparison, not a database-moat claim.
