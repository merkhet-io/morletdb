"""Summarize the complete frozen WRL4 matrix; paired, class-stratified block bootstrap."""
import argparse
import json
from pathlib import Path
import numpy as np
from episodic import METHODS,BUDGETS
from hydraulic import save_json


def summarize(out,destination):
    cases=[json.loads(p.read_text()) for p in sorted(out.glob('*-cooler*.json'))]
    assert len(cases)==30
    summaries={};lines=['# WRL4 complete results','', 'Macro-F1: mean over five seeds, then three cooler holds.','']
    for target in ('valve','accumulator'):
        selected=[x for x in cases if x['target']==target];rows={};details={}
        for bi,n in enumerate(BUDGETS):
            rows[n]={m:float(np.mean([c['results'][bi]['metrics'][m]['block_macro_f1'] for c in selected])) for m in METHODS}
            details[n]={key:float(np.mean([c['results'][bi][key] for c in selected])) for key in
                        ('purity','random_purity','gate_mean','random_gate_mean','shuffled_gate_mean','adversarial_gate_mean','memory_ms_per_cycle')}
        per_hold={str(h):{m:float(np.mean([c['results'][-1]['metrics'][m]['block_macro_f1'] for c in selected if c['held_cooler']==h])) for m in METHODS} for h in (3,20,100)}
        comps=('encoder-only','gated-random','gated-shuffled','adapted-logistic','adapted-RF')
        passed=all(rows[8]['gated-memory']-rows[8][m]>=.03 for m in comps) and all(
            r['gated-memory']>max(r['encoder-only'],r['adapted-logistic'],r['adapted-RF']) for r in per_hold.values())
        # Bootstrap whole blocks, stratified by class and hold, same resampling across seeds/methods.
        rng=np.random.default_rng(4404);samples=[]
        for held in (3,20,100):
            hs=sorted([c for c in selected if c['held_cooler']==held],key=lambda x:x['seed'])
            metrics=[c['results'][-1]['metrics'] for c in hs]
            truth=np.array(metrics[0]['encoder-only']['block_truth'])
            for mm in metrics:assert mm['encoder-only']['block_truth']==truth.tolist()
            predictions=np.array([[np.array(mm[m]['block_probabilities']).argmax(1) for m in METHODS] for mm in metrics])
            indices=np.concatenate([rng.choice(np.flatnonzero(truth==c),size=(2000,4),replace=True) for c in range(4)],axis=1)
            pred=predictions[:,:,indices].transpose(2,0,1,3);actual=truth[indices][:,None,None,:]
            f1=np.zeros(pred.shape[:-1])
            for label in range(4):
                tp=((pred==label)&(actual==label)).sum(-1);fp=((pred==label)&(actual!=label)).sum(-1);fn=((pred!=label)&(actual==label)).sum(-1)
                denom=2*tp+fp+fn;f1+=np.divide(2*tp,denom,out=np.zeros_like(tp,dtype=float),where=denom!=0)/4
            samples.append(f1.mean(1))
        boot=np.mean(samples,axis=0)
        intervals={m:{'mean_difference':rows[8]['gated-memory']-rows[8][m],
            'paired_block_bootstrap_95_percentile':np.quantile(boot[:,METHODS.index('gated-memory')]-boot[:,METHODS.index(m)],[.025,.975]).tolist()} for m in comps}
        changes={}
        for bi,n in enumerate(BUDGETS):
            helpful=harmful=unchanged=0
            for c in selected:
                mm=c['results'][bi]['metrics'];bt=np.array(mm['encoder-only']['block_truth'])
                base=np.argmax(mm['encoder-only']['block_probabilities'],1);mem=np.argmax(mm['gated-memory']['block_probabilities'],1)
                helpful+=int(((base!=bt)&(mem==bt)).sum());harmful+=int(((base==bt)&(mem!=bt)).sum());unchanged+=int((base==mem).sum())
            changes[n]={'helpful':helpful,'harmful':harmful,'unchanged_prediction':unchanged,'block_seed_observations':240}
        summaries[target]={'means':rows,'diagnostics':details,'n8_per_cooler':per_hold,'n8_comparisons':intervals,'advance_gate_passed':bool(passed),'prediction_changes':changes}
        lines.extend([f'## {target}','', '| Method | 0/class | 1/class | 2/class | 8/class |','|---|---:|---:|---:|---:|'])
        for m in METHODS:lines.append('| '+m+' | '+' | '.join(f'{rows[n][m]:.4f}' for n in BUDGETS)+' |')
        lines.extend(['',f'Advance gate passed: **{passed}**.',''])
    save_json(destination/'episodic_summary.json',summaries)
    (destination/'episodic_table.md').write_text('\n'.join(lines).rstrip()+'\n')
    print('\n'.join(lines))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--destination',type=Path,required=True)
    args=ap.parse_args();args.destination.mkdir(parents=True,exist_ok=True);summarize(args.out,args.destination)
