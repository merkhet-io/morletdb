# WRL4: episodes help a weak frozen model; ordinary adaptation wins

Completed locally on 2026-11-23. [Protocol](EPISODIC_PROTOCOL.md),
[complete results](results/episodic_table.md), [machine-readable summary](results/episodic_summary.json),
[independent audit](results/episodic_audit.json).
This is exploratory reuse of the hydraulic dataset, not independent confirmation,
a brain model, a JEPA/xLSTM evaluation, or a database benchmark.

## Result

Thirty encoder/gate fits cover two diagnostic targets, three held-out cooler
conditions and five seeds. Each evaluates four nested support budgets and nine
methods/controls: 1,080 prediction sets. At eight new confirmed episodes per class:

| Method | Valve macro-F1 | Accumulator macro-F1 |
|---|---:|---:|
| Frozen encoder classifier | .1745 | .1183 |
| Statistical-feature retrieval | .3769 | .5086 |
| Learned-embedding retrieval | .4267 | .6064 |
| Frozen encoder + gated memory | .3276 | .2466 |
| Same gate + random memory | .1750 | .1183 |
| Same gate + shuffled memory labels | .1772 | .1383 |
| Logistic adaptation on frozen embeddings | .3124 | .1364 |
| Random-forest adaptation on statistical features | **.8341** | **.8234** |

Scores average block macro-F1 over seeds and cooler holds, not sample accuracy.
All methods have access to the same 96 source labels and up to 32 new support labels.
Encoder training uses 64 source labels and checkpoint selection uses 32 validation
labels. The adapted baselines fit all 96 source labels plus support. The gate fits
source validation examples using only opposite-source-cooler training galleries.
Evaluation galleries contain all 96 source episodes plus available target support.

**Both predeclared advance gates fail.** Gated memory improves the frozen encoder
by 15.30 and 12.83 percentage points, but trails the adapted forest by 50.65 and 57.68
points. It also fails the required 3-point margin over logistic adaptation on valve.
The valve cooler 3 holdout gets worse than encoder-only (.1428 vs .1553). All results,
including that failure, are retained. There was no post-result tuning or rerun.

![Measured performance as episode memory grows](results/episodic_memory_growth.png)

The memory-growth experiment is informative: embedding retrieval changes from
.2122 to .4267 on valve and .1243 to .6064 on accumulator as support grows from 0 to 8
per class, without updating encoder weights. Gated memory changes from .2069 to
.3276 and .1184 to .2466. Random-forest adaptation changes from .8125 to .8341 and
.1043 to .8234. More labelled information helps ordinary learning too; retrieval
must be compared with that alternative, not only the fixed model.

## What the evidence supports

1. **The archive contains useful examples for this diagnosis task.** At 8/class,
   retrieved-label agreement is 44.98% for valve and 52.18% for accumulator, versus
   random 25.28% and 25.01%. These are diagnostic label agreements, not causal matches.
2. **A learned representation can help retrieval in this setup.** Embedding kNN
   exceeds statistical kNN at 8/class by 4.98 and 9.78 points. This does not establish
   a universal representation advantage: at 0 support/class it loses on both tasks.
3. **The tested gate limits the benefit.** Embedding kNN exceeds gated memory by
   9.91 and 35.98 points. Mean gate weights at 8/class are .363 and .336; random-memory
   weights are .087 and .086. The gate can distinguish some reference structure, but
   the source-trained weighting does not transfer well enough to exploit it.
4. **The frozen classifier is a weak comparator under this shift.** Mean source
   training cycle accuracy is 97.19%/93.23%; source validation 62.29%/70.83%; target
   query 30.83%/26.72%. These post-run diagnostics suggest overfitting/domain-shift
   sensitivity, not proof that a particular architecture change will fix it.
5. **Practical superiority is not established.** The forest wins every target/cooler
   aggregate at 8/class. The experiment does not support replacing it with this
   memory system for diagnostic accuracy.

Across 240 block-seed observations per target at 8/class, the gate corrects 30 and 25
encoder mistakes, while introducing 3 and 0 mistakes respectively. Repeated seeds
are not independent machines. Descriptive paired block-bootstrap 95% intervals for
its advantage over encoder-only are [12.36,17.31] and [9.93,15.02] percentage points;
its differences from the forest are [-57.05,-43.27] and [-65.18,-48.46]. Bootstrap
resamples whole test blocks within class/cooler, with seeds paired. These intervals
cannot support factory-population claims.

The synthetic deliberately-wrong-label stress arm preserves encoder-only macro-F1;
mean gate weights remain .108/.117. This is not a successful unknown-state detector:
it tests artificial contradiction and the baseline is already weak. True rejection
of unfamiliar states remains untested.

## Integrity, timing and limitations

- Five new contract tests and the existing 15 research tests pass (20 total). Checks
  cover disjoint whole blocks, fixed query sets, nested support, source-only scaling,
  deterministic rankings, mixture limits, and query labels not affecting retrieval.
- All 30 checkpoints reproduce embeddings and base probabilities exactly. All 1,080
  metric sets are independently recomputed. Nearest IDs match independent Python
  tuple ranking and coordinate-wise distances. Gate reconstruction max absolute
  probability error is 7.32e-8. Every reference belongs to the eligible gallery.
- Scikit-learn emits divide/overflow/invalid matmul warnings on this local stack.
  Logs are retained. Independent non-BLAS logistic predictions differ by at most
  5.56e-16; maximum final objective-gradient component is 9.94e-5 (default tolerance
  1e-4). All 120 forest refits reproduce predictions exactly. No non-finite saved
  prediction is accepted.
- The original ZIP SHA and all 14 sensor member hashes match WRL3. Readback of 1,408
  involved cycles across 14 sensors (19,712 recordings) reproduces temporal inputs
  exactly. Raw recordings retain original sampling rates, units and specifications;
  one-second means are explicitly derived model inputs.
- Exact retrieval plus gate averages about .0135/.0133 ms per query at 128 episodes,
  calculated from batched timings with embeddings precomputed. This excludes signal
  encoding, database I/O and serving overhead; it is not a deployment latency claim.
- One rig and three co-occurring cooler conditions are not three factories. Stable
  filtering and balanced label acquisition use oracle labels. Test blocks are fixed
  and disjoint, but this is offline support/query adaptation, not chronological
  history, maintenance-action learning, or a test of real unknown conditions.
- No source pretraining on unlabelled recordings, JEPA, contrastive encoder, xLSTM,
  learned attention over raw retrieved signals, SQL/MorletDB search or new extension
  was implemented. This is the first supervised-encoder/gated-memory mechanism test.
- Freeze-order deviation: the initial shell attempted the local commit, encountered
  a sandbox index-lock restriction, and still started the run. The runner wrote the
  protocol, harness and input hashes BEFORE training; commit 64bb054 was then made
  with authorization while the run continued, before results were inspected. The
  committed files match those pre-training hashes exactly. This is not the intended
  commit-before-training order; no protocol/code change or hidden rerun followed.

## Next decision

Do not build a new extension or claim a diagnostic advantage from WRL4. The narrow
positive finding is that adding relevant episodes can improve a frozen model and
that learned retrieval can outperform the tested statistical distance with enough
support. Before choosing JEPA or another backbone, an independently frozen study
should compare a stronger encoder with nearest-episode prediction and ordinary
adaptation on untouched assets. To test the original lessons-learned idea in full,
obtain episodes linking signals to actual interventions and measured outcomes.

Related existing issues: [#216 event library](https://github.com/merkhet-io/morletdb/issues/216),
[#217 confirmed findings](https://github.com/merkhet-io/morletdb/issues/217),
[#416 abnormality ranking](https://github.com/merkhet-io/morletdb/issues/416),
[#582 held-out investigations](https://github.com/merkhet-io/morletdb/issues/582).
No duplicate issue or PR was opened; this work remains local.

## Reproduce

Use the existing pinned `.venv-research` environment. Run from the isolated research
worktree. Output folders must be new; the harness refuses to overwrite completed cases.

```sh
RESEARCH_PY=/Users/zin/sophia/morletdb/.venv-research/bin/python
RESEARCH_DATA=/Users/zin/sophia/morletdb/data
$RESEARCH_PY -m unittest discover -s research/waverag_local -p 'test_*.py' -v
$RESEARCH_PY research/waverag_local/episodic.py --input "$RESEARCH_DATA/wrl3-20261123/features.npz" --out /tmp/wrl4-reproduction
$RESEARCH_PY research/waverag_local/summarize_episodic.py --out /tmp/wrl4-reproduction --destination /tmp/wrl4-reproduction-summary
$RESEARCH_PY research/waverag_local/audit_episodic.py --out /tmp/wrl4-reproduction --data "$RESEARCH_DATA/wrl3-20261123/features.npz" --archive "$RESEARCH_DATA/wrl2-20261123/inputs/wrl2-hydraulic.zip"
```

Persistent outputs: ignored `data/wrl4-20261123/` in the main checkout. Each case has
JSON metrics/losses, NPZ predictions/scalers/references and a Torch checkpoint.
The tracked artifact manifest hashes all persisted files. No migrations or production
changes; earlier WRL1/2/3 evidence and unrelated website work remain intact.
