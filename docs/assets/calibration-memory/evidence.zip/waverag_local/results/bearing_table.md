# WRL5 complete results

Recording macro-F1; mean across five seeds and two target bearing types.
Support windows are correlated half-second excerpts from ONE zero-load acquisition per class.

| Method | 0 sec/class | 0.5 sec/class | 1 sec/class | 4 sec/class |
|---|---:|---:|---:|---:|
| source-encoder | 0.4077 | 0.4077 | 0.4077 | 0.4077 |
| spectral-knn | 0.3416 | 0.3416 | 0.3416 | 0.9467 |
| embedding-knn | 0.4537 | 0.4537 | 0.4737 | 0.8680 |
| random-knn | 0.2244 | 0.1864 | 0.1884 | 0.1089 |
| shuffled-knn | 0.1620 | 0.1098 | 0.1935 | 0.1559 |
| adapted-logistic | 0.1800 | 0.6433 | 0.7067 | 0.9467 |
| adapted-RF | 0.2857 | 0.6787 | 0.7227 | 0.9360 |
| balanced-RF | 0.2857 | 0.6373 | 0.7547 | 0.9587 |
| balanced-SVM | 0.4000 | 0.9467 | 0.9467 | 0.9467 |

Primary advance criterion passed: **False**.

## At four seconds per class, by target bearing type

| Method | 6207 | 6208 |
|---|---:|---:|
| source-encoder | 0.4507 | 0.3648 |
| spectral-knn | 1.0000 | 0.8933 |
| embedding-knn | 0.7573 | 0.9787 |
| random-knn | 0.0800 | 0.1379 |
| shuffled-knn | 0.1591 | 0.1528 |
| adapted-logistic | 0.8933 | 1.0000 |
| adapted-RF | 0.9787 | 0.8933 |
| balanced-RF | 1.0000 | 0.9173 |
| balanced-SVM | 1.0000 | 0.8933 |

## Source-only validation

| Candidate | Recording macro-F1 |
|---|---:|
| ce | 0.3549 |
| contrastive | 0.4490 |
| rf | 0.5000 |
| logistic | 0.7333 |
| svm | 0.7333 |

Selected encoder: contrastive; epochs: [1, 1, 1, 1, 1]; logistic C=0.1; SVM C=1.0.
