| Model | ETTh1 median MSE | ETTh2 median MSE |
|---|---:|---:|
| nlinear | 0.37751 | 0.27639 |
| raft | 0.36675 | 0.28076 |
| raft-zero | 0.37166 | 0.27000 |
| raft-random | 0.37250 | 0.27098 |
| raft-shuffled | 0.37238 | 0.27050 |
| xlstm | 0.38758 | 0.30633 |
| xlstm-retrieval | 0.38986 | 0.31313 |
| xlstm-random | 0.39151 | 0.30666 |
| persistence | 1.29437 | 0.43166 |
| daily | 0.51223 | 0.39052 |
| weekly | 0.65699 | 0.58238 |
