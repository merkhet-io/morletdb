# WRL4 complete results

Macro-F1: mean over five seeds, then three cooler holds.

## valve

| Method | 0/class | 1/class | 2/class | 8/class |
|---|---:|---:|---:|---:|
| stat-knn | 0.3390 | 0.2034 | 0.3175 | 0.3769 |
| encoder-only | 0.1745 | 0.1745 | 0.1745 | 0.1745 |
| embedding-knn | 0.2122 | 0.2197 | 0.3702 | 0.4267 |
| gated-memory | 0.2069 | 0.2007 | 0.2060 | 0.3276 |
| gated-random | 0.1776 | 0.1748 | 0.1776 | 0.1750 |
| gated-shuffled | 0.1963 | 0.1706 | 0.1994 | 0.1772 |
| adapted-logistic | 0.1829 | 0.2143 | 0.2305 | 0.3124 |
| adapted-RF | 0.8125 | 0.8256 | 0.8452 | 0.8341 |
| gated-adversarial | 0.1745 | 0.1745 | 0.1745 | 0.1745 |

Advance gate passed: **False**.

## accumulator

| Method | 0/class | 1/class | 2/class | 8/class |
|---|---:|---:|---:|---:|
| stat-knn | 0.1307 | 0.1940 | 0.3836 | 0.5086 |
| encoder-only | 0.1183 | 0.1183 | 0.1183 | 0.1183 |
| embedding-knn | 0.1243 | 0.1581 | 0.3297 | 0.6064 |
| gated-memory | 0.1184 | 0.1218 | 0.1527 | 0.2466 |
| gated-random | 0.1183 | 0.1183 | 0.1183 | 0.1183 |
| gated-shuffled | 0.1183 | 0.1070 | 0.1131 | 0.1383 |
| adapted-logistic | 0.1254 | 0.1230 | 0.1343 | 0.1364 |
| adapted-RF | 0.1043 | 0.4730 | 0.5508 | 0.8234 |
| gated-adversarial | 0.1183 | 0.1183 | 0.1183 | 0.1183 |

Advance gate passed: **False**.
