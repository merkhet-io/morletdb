import unittest
import numpy as np
from run import corrected, eligible, nearest


class Contracts(unittest.TestCase):
    def test_query_and_future_labels_are_excluded(self):
        cuts = np.arange(1, 51)
        self.assertEqual(cuts[eligible(cuts, 30)].tolist(), [10, 20])
        self.assertEqual(cuts[eligible(cuts, 31)].tolist(), [10, 20, 30])

    def test_independent_expected_distance_and_tie(self):
        x = np.array([[3., 4.], [0., 5.], [0., 0.]])
        ids, distances = nearest(x, np.array([20, 10, 30]), np.array([0, 1]), np.zeros(2))
        self.assertEqual(ids.tolist(), [1, 0])
        self.assertEqual(distances.tolist(), [5., 5.])

    def test_unavailable_exact_match_does_not_win(self):
        x = np.array([[2.], [0.]])
        ids, _ = nearest(x, np.array([10, 20]), np.array([0]), np.array([0.]))
        self.assertEqual(ids.tolist(), [0])

    def test_residual_corrects_bias_not_absolute_wear(self):
        self.assertEqual(corrected(100., np.array([20., 30.]), np.array([25., 35.])), 105.)
        self.assertEqual(corrected(1., np.array([20.]), np.array([0.])), 0.)


if __name__ == "__main__":
    unittest.main()
