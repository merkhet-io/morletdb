"""WRL3 frozen small-label diagnosis; raw archive never modified."""
import argparse
import ctypes
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import time
import zipfile

import numpy as np
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, balanced_accuracy_score, confusion_matrix
import torch
from torch import nn

ARCHIVE_SHA='24128aad2ee45eea7e6b63ebbd9992cdf25d0483a2cebefbfc13bc69079af1f2'
SENSORS=[*(f'PS{i}' for i in range(1,7)),'EPS1','FS1','FS2',*(f'TS{i}' for i in range(1,5)),'VS1']
TARGETS={'valve':1,'accumulator':3}
COOLERS=(3,20,100)
METHODS=['prior','logistic','rf','tcn','knn','dtw','rf-knn','rf-random','rf-shuffled',
         'tcn-knn','tcn-random','tcn-shuffled']


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save_json(p,v): Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')


def block_ids(profile):
    return np.r_[True,np.any(profile[1:,:4]!=profile[:-1,:4],axis=1)].cumsum()-1


def select_train(profile,blocks,target,held,budget,seed):
    assert budget in (2,8)
    rng=np.random.default_rng(20261123+seed*1000+target*100+held)
    chosen=[]
    for label in np.unique(profile[:,target]):
        for cooler in COOLERS:
            if cooler==held: continue
            eligible=np.flatnonzero((profile[:,4]==0)&(profile[:,target]==label)&(profile[:,0]==cooler))
            candidates=np.unique(blocks[eligible])
            selected=rng.permutation(candidates)[:4]
            draws=[int(rng.choice(eligible[blocks[eligible]==b])) for b in selected]
            chosen.extend(draws[:budget//2])
    chosen=np.array(sorted(chosen))
    assert len(chosen)==4*budget and len(np.unique(blocks[chosen]))==len(chosen)
    assert (profile[chosen,0]!=held).all()
    return chosen


def scale_from_train(x,ids,temporal=False):
    axes=(0,1) if temporal else 0
    mu=x[ids].mean(axis=axes); sd=x[ids].std(axis=axes)
    sd=np.where(sd>1e-12,sd,1.)
    return (x-mu)/sd,mu,sd


def nearest(distances,ids,k):
    return np.stack([np.lexsort((ids,row))[:k] for row in distances])


def votes(indices,labels):
    return np.eye(4)[labels[indices]].mean(axis=1)


def evaluate(prob,y,blocks):
    unique=np.unique(blocks)
    yp=np.stack([prob[blocks==b].mean(0) for b in unique])
    truth=np.array([y[blocks==b][0] for b in unique])
    assert all(len(np.unique(y[blocks==b]))==1 for b in unique)
    pred=yp.argmax(1)
    return {'block_macro_f1':float(f1_score(truth,pred,labels=np.arange(4),average='macro',zero_division=0)),
            'block_balanced_accuracy':float(balanced_accuracy_score(truth,pred)),
            'cycle_macro_f1':float(f1_score(y,prob.argmax(1),labels=np.arange(4),average='macro',zero_division=0)),
            'block_confusion_matrix':confusion_matrix(truth,pred,labels=np.arange(4)).tolist(),
            'block_ids':unique.tolist(),'block_truth':truth.tolist(),'block_probabilities':yp.tolist()}


def dtw(q,g,lib):
    q=np.ascontiguousarray(q,dtype='f8');g=np.ascontiguousarray(g,dtype='f8')
    assert q.ndim==g.ndim==3 and q.shape[1:]==g.shape[1:]
    result=np.empty((len(q),len(g)),dtype='f8')
    ptr=np.ctypeslib.ndpointer(dtype='f8',flags='C_CONTIGUOUS')
    lib.hydraulic_dtw.argtypes=[ptr,ptr,*([ctypes.c_int]*5),ptr]
    lib.hydraulic_dtw.restype=None
    lib.hydraulic_dtw(q,g,len(q),len(g),q.shape[1],q.shape[2],3,result)
    assert np.isfinite(result).all() and (result>=0).all()
    return result


def prepare(archive,out):
    assert sha(archive)==ARCHIVE_SHA
    features=[];temporal=[];spec=[]
    with zipfile.ZipFile(archive) as z:
        profile=np.loadtxt(io.BytesIO(z.read('profile.txt'))).astype('i8')
        for sensor in SENSORS:
            content=z.read(sensor+'.txt')
            a=np.loadtxt(io.BytesIO(content))
            assert len(a)==len(profile) and a.shape[1] in (60,600,6000) and np.isfinite(a).all()
            rate=a.shape[1]//60
            stats=np.stack([a.mean(1),a.std(1),a.min(1),a.max(1),np.sqrt(np.mean(a*a,1)),
                            np.quantile(a,.1,axis=1),np.quantile(a,.9,axis=1),a[:,-1]-a[:,0]],axis=1)
            bins=a.reshape(len(a),12,-1).mean(2)
            features.append(np.concatenate((stats,bins),axis=1))
            temporal.append(a.reshape(len(a),60,rate).mean(2))
            spec.append({'sensor':sensor,'member':sensor+'.txt','member_sha256':hashlib.sha256(content).hexdigest(),
                         'cycles':len(a),'sample_rate_hz':rate,'sample_interval':[0,a.shape[1]]})
            print('extracted',sensor,flush=True)
    f=np.concatenate(features,axis=1);t=np.stack(temporal,axis=2)
    assert f.shape==(2205,280) and t.shape==(2205,60,14)
    blocks=block_ids(profile)
    np.savez_compressed(out/'features.npz',features=f,temporal=t,profile=profile,blocks=blocks)
    save_json(out/'source.json',{'archive_sha256':ARCHIVE_SHA,'representation':'WRL3-stat280-paa1s-v1',
              'sensors':spec,'stable_cycles':int((profile[:,4]==0).sum()),'full_blocks':int(blocks.max()+1),
              'stable_blocks':len(np.unique(blocks[profile[:,4]==0])),
              'raw_authority':'Original ZIP; derived features do not replace source samples.'})


def fit_tcn(x,y,query,seed):
    torch.manual_seed(seed)
    m=nn.Sequential(nn.Conv1d(14,16,5,padding=2),nn.ReLU(),nn.Conv1d(16,32,5,padding=2),
                    nn.ReLU(),nn.AdaptiveAvgPool1d(10),nn.Flatten(),nn.Linear(320,4))
    opt=torch.optim.Adam(m.parameters(),lr=.001)
    x=torch.tensor(x.transpose(0,2,1),dtype=torch.float32)
    y=torch.tensor(y,dtype=torch.long)
    rng=np.random.default_rng(seed)
    losses=[]
    for epoch in range(100):
        order=rng.permutation(len(x));total=0.
        for j in range(0,len(order),8):
            batch=order[j:j+8];opt.zero_grad()
            loss=nn.functional.cross_entropy(m(x[batch]),y[batch])
            assert torch.isfinite(loss)
            loss.backward();opt.step();total+=loss.item()*len(batch)
        losses.append(total/len(x))
    m.eval()
    with torch.no_grad(): p=m(torch.tensor(query.transpose(0,2,1),dtype=torch.float32)).softmax(1).numpy()
    return p,m.state_dict(),losses


def run_case(a,target,held,budget,seed,lib,out):
    profile,blocks=a['profile'],a['blocks'];column=TARGETS[target]
    labels=np.unique(profile[:,column]);y=np.searchsorted(labels,profile[:,column])
    train=select_train(profile,blocks,column,held,budget,seed)
    query=np.flatnonzero((profile[:,4]==0)&(profile[:,0]==held))
    assert set(blocks[train]).isdisjoint(blocks[query])
    f,fmu,fsd=scale_from_train(a['features'],train)
    t,tmu,tsd=scale_from_train(a['temporal'],train,True)
    begin=time.perf_counter()
    log=LogisticRegression(C=1,max_iter=2000).fit(f[train],y[train])
    forest=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,
                  class_weight='balanced',n_jobs=1,random_state=seed).fit(f[train],y[train])
    tp,state,losses=fit_tcn(t[train],y[train],t[query],seed)
    diff=f[query,None,:]-f[train][None,:,:]
    distances=np.sqrt(np.einsum('qnf,qnf->qn',diff,diff,optimize=False))
    idx=nearest(distances,train,5)
    dt=dtw(t[query],t[train],lib);di=nearest(dt,train,1)
    rng=np.random.default_rng(900000+seed*1000+column*100+held)
    ri=np.stack([rng.choice(len(train),5,replace=False) for _ in query])
    shuffled=y[train][rng.permutation(len(train))]
    kp=votes(idx,y[train]);rp=votes(ri,y[train]);sp=votes(idx,shuffled)
    probabilities={'prior':np.full((len(query),4),.25),'logistic':log.predict_proba(f[query]),
                   'rf':forest.predict_proba(f[query]),'tcn':tp,'knn':kp,'dtw':votes(di,y[train])}
    for backbone in ('rf','tcn'):
        for name,other in [('knn',kp),('random',rp),('shuffled',sp)]:
            probabilities[backbone+'-'+name]=(probabilities[backbone]+other)/2
    assert list(probabilities)==METHODS
    for prob in probabilities.values():
        assert np.isfinite(prob).all() and np.allclose(prob.sum(1),1.)
    knn_ids=train[idx];random_ids=train[ri];dtw_ids=train[di]
    assert np.isin(knn_ids,train).all() and np.isin(random_ids,train).all()
    assert (profile[knn_ids,0]!=held).all() and (profile[dtw_ids,0]!=held).all()
    stem=f'{target}-cooler{held}-n{budget}-s{seed}'
    np.savez_compressed(out/(stem+'.npz'),train_ids=train,query_ids=query,query_blocks=blocks[query],
            y_true=y[query],probabilities=np.stack(list(probabilities.values())),knn_ids=knn_ids,
            knn_distances=np.take_along_axis(distances,idx,axis=1),dtw_ids=dtw_ids,
            dtw_cost=np.take_along_axis(dt,di,axis=1),random_ids=random_ids,shuffled_gallery_labels=shuffled,
            feature_mean=fmu,feature_std=fsd,temporal_mean=tmu,temporal_std=tsd)
    torch.save(state,out/(stem+'.pt'))
    metrics={name:evaluate(p,y[query],blocks[query]) for name,p in probabilities.items()}
    result={'target':target,'held_cooler':held,'labels_per_class':budget,'seed':seed,'class_values':labels.tolist(),
            'train_cycle_ids':train.tolist(),'test_cycles':len(query),'test_blocks':len(np.unique(blocks[query])),
            'knn_label_purity':float((y[knn_ids]==y[query,None]).mean()),
            'random_label_purity':float((y[random_ids]==y[query,None]).mean()),
            'dtw_label_purity':float((y[dtw_ids[:,0]]==y[query]).mean()),
            'seconds':time.perf_counter()-begin,'tcn_training_loss':losses,'metrics':metrics}
    save_json(out/(stem+'.json'),result)
    print(json.dumps({'case':stem,'seconds':result['seconds'],
           'block_macro_f1':{k:round(v['block_macro_f1'],4) for k,v in metrics.items()}}),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run'])
    p.add_argument('--archive',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--lib',type=Path,default=Path('/tmp/wrl3-dtw.dylib'))
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    if args.mode=='prepare':
        assert not (args.out/'features.npz').exists(),'Do not overwrite derived data'
        prepare(args.archive,args.out);return
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    base=Path(__file__).parent
    manifest={'archive_sha256':sha(args.archive),'harness_sha256':sha(__file__),
              'protocol_sha256':sha(base/'HYDRAULIC_PROTOCOL.md'),'dtw_source_sha256':sha(base/'hydraulic_dtw.cpp'),
              'dtw_binary_sha256':sha(args.lib),'features_sha256':sha(args.out/'features.npz'),
              'numpy':np.__version__,'sklearn':sklearn.__version__,'torch':torch.__version__,
              'platform':platform.platform(),'compiler':subprocess.check_output(['c++','--version'],text=True)}
    assert manifest['archive_sha256']==ARCHIVE_SHA
    mp=args.out/'manifest.json'
    if mp.exists():assert json.loads(mp.read_text())==manifest
    else:save_json(mp,manifest)
    lib=ctypes.CDLL(str(args.lib));a=np.load(args.out/'features.npz')
    for target in TARGETS:
        for budget in (2,8):
            for held in COOLERS:
                for seed in range(5):
                    dest=args.out/f'{target}-cooler{held}-n{budget}-s{seed}.json'
                    if not dest.exists():run_case(a,target,held,budget,seed,lib,args.out)


if __name__=='__main__':main()
