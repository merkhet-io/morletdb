"""Measured WRL5 curves; categorical support-duration axis."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).parent/'results'
s=json.loads((root/'bearing_summary.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(11,4.6),sharey=True)
styles={'source-encoder':('Frozen neural classifier','#888888'),
        'embedding-knn':('Learned-embedding retrieval','#167c95'),
        'spectral-knn':('Spectral-feature retrieval','#8057b1'),
        'balanced-RF':('Adapted weighted forest','#277e38'),
        'balanced-SVM':('Adapted weighted RBF SVM','#c97d1a')}
for ax,t in zip(axes,('6207','6208')):
    for m,(label,color) in styles.items():
        ax.plot(range(4),[s['per_target'][str(n)][t][m] for n in (0,1,2,8)],marker='o',label=label,color=color)
    ax.set_title('Held-out bearing type '+t);ax.set_xticks(range(4),['0','0.5','1','4'])
    ax.set_xlabel('Support seconds per class (categorical spacing)');ax.set_ylim(0,1.02);ax.grid(alpha=.2)
axes[0].set_ylabel('Recording macro-F1 (higher is better)');axes[1].legend(fontsize=7.5,loc='best')
fig.suptitle('WRL5: fresh HUST bearing-type transfer',fontsize=13)
fig.text(.5,.01,'Five seeds; one zero-load support recording per class. Queries are separate 200/400 W recordings.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.04,1,.94));fig.savefig(root/'bearing_memory_growth.png',dpi=180)
