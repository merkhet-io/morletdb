"""WRL5 fresh bearing-type transfer. Protocol is authoritative."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import platform
import re
import time
import numpy as np
import scipy
from scipy.io import loadmat
from scipy.signal import welch,hilbert
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import f1_score,confusion_matrix
import torch
from torch import nn
from hydraulic import save_json,sha,nearest

CLASSES=('N','I','O','IO','OB')
RATE=51200
WINDOW=25600
BUDGETS=(0,1,2,8)
METHODS=('source-encoder','spectral-knn','embedding-knn','random-knn','shuffled-knn',
         'adapted-logistic','adapted-RF','balanced-RF','balanced-SVM')


def parse_name(name):
    m=re.fullmatch(r'(N|I|O|IO|OB)([4-8])0([024])\.mat',name)
    if m is None:raise ValueError(name)
    return CLASSES.index(m[1]),6200+int(m[2]),int(m[3])*100


def band_sums(power,n):
    edges=np.linspace(0,len(power),n+1).astype(int)
    assert np.all(np.diff(edges)>0)
    return np.array([power[l:r].sum()*25. for l,r in zip(edges[:-1],edges[1:])])


def features(raw):
    raw=np.asarray(raw,dtype='f8');assert raw.shape==(WINDOW,) and np.isfinite(raw).all()
    centered=raw-raw.mean();sd=raw.std();rms=np.sqrt(np.mean(raw*raw));peak=np.max(abs(raw))
    denom=max(sd,1e-12)
    stats=np.array([raw.mean(),np.log1p(sd),np.log1p(rms),np.log1p(peak),
                   np.log1p(peak/max(rms,1e-12)),np.log1p(abs(raw).mean()),
                   np.mean((centered/denom)**3),np.log1p(np.mean((centered/denom)**4))])
    _,psd=welch(centered,fs=RATE,window='hann',nperseg=2048,noverlap=1024,detrend='constant',scaling='density')
    envelope=abs(hilbert(centered));envelope-=envelope.mean()
    freq,ep=welch(envelope,fs=RATE,window='hann',nperseg=2048,noverlap=1024,detrend='constant',scaling='density')
    result=np.r_[np.log10(np.maximum(band_sums(psd,128),1e-20)),
                 np.log10(np.maximum(band_sums(ep[freq<=3200],64),1e-20)),stats]
    assert result.shape==(200,) and np.isfinite(result).all()
    return result


def window_bounds(length):
    if length<WINDOW:raise ValueError('Recording shorter than one complete window')
    return [(left,left+WINDOW) for left in range(0,length-WINDOW+1,WINDOW)]


def prepare(rawdir,out):
    metadata=json.loads((out/'source_metadata.json').read_text())
    wanted={f['filename']:f for f in metadata if re.fullmatch(r'(N|I|O|IO|OB)[4-8]0[024]\.mat',f['filename'])}
    assert len(wanted)==75
    xs=[];ys=[];types=[];loads=[];record=[];bounds=[];manifest=[]
    for ri,name in enumerate(sorted(wanted)):
        p=rawdir/name;expected=wanted[name]['content_details']['sha256_hash']
        assert sha(p)==expected
        mat=loadmat(p);raw=np.asarray(mat['data']).reshape(-1)
        assert len(raw)>=WINDOW and raw.dtype==np.float64 and np.isfinite(raw).all()
        y,t,load=parse_name(name)
        for left,right in window_bounds(len(raw)):
            xs.append(features(raw[left:right]));ys.append(y);types.append(t);loads.append(load)
            record.append(ri);bounds.append([left,right])
        manifest.append({'recording_id':ri,'filename':name,'sha256':expected,'samples':len(raw),
            'complete_windows':len(raw)//WINDOW,'unused_trailing_samples':len(raw)%WINDOW,
            'sample_rate_hz':RATE,'shaft_frequency_hz':float(mat['fs'].reshape(-1)[0]),
            'unit':'unspecified in MAT; calibration not inferred','class':CLASSES[y],
            'bearing_type':t,'load_watts':load,'publisher_file_id':wanted[name]['id']})
        print('prepared',name,flush=True)
    np.savez_compressed(out/'features.npz',x=np.array(xs),y=np.array(ys),types=np.array(types),
                        loads=np.array(loads),record=np.array(record),bounds=np.array(bounds))
    save_json(out/'recordings.json',manifest)


def ids_for(a,types,loads=(0,200,400)):
    return np.flatnonzero(np.isin(a['types'],types)&np.isin(a['loads'],loads))


def support_for(a,target,budget):
    ids=ids_for(a,[target],[0]);result=[]
    for label in range(5):
        candidates=ids[a['y'][ids]==label]
        result.extend(candidates[:budget])
    return np.array(result,dtype=int)


def scale(x,ids):
    mu=x[ids].mean(0);sd=x[ids].std(0);sd=np.where(sd>=1e-6,sd,1.)
    return (x-mu)/sd,mu,sd


def scores(prob,truth,record):
    rec=np.unique(record);p=np.array([prob[record==r].mean(0) for r in rec])
    y=np.array([truth[record==r][0] for r in rec])
    assert all(len(np.unique(truth[record==r]))==1 for r in rec)
    return {'macro_f1':float(f1_score(y,p.argmax(1),labels=np.arange(5),average='macro',zero_division=0)),
        'recording_ids':rec.tolist(),'truth':y.tolist(),'probabilities':p.tolist(),
        'predicted':p.argmax(1).tolist(),'confusion':confusion_matrix(y,p.argmax(1),labels=np.arange(5)).tolist()}


class Encoder(nn.Module):
    def __init__(self):
        super().__init__();self.net=nn.Sequential(nn.Linear(200,256),nn.LayerNorm(256),nn.GELU(),
            nn.Linear(256,128),nn.LayerNorm(128),nn.GELU(),nn.Linear(128,64));self.head=nn.Linear(64,5)
    def embed(self,x):return nn.functional.normalize(self.net(x),dim=1)
    def forward(self,x):return 10*self.head(self.embed(x))


def contrastive(z,y):
    sim=z@z.T/.1;eye=torch.eye(len(z),dtype=torch.bool,device=z.device)
    sim=sim.masked_fill(eye,-1e9);logp=sim-torch.logsumexp(sim,dim=1,keepdim=True)
    positive=(y[:,None]==y[None,:])&~eye;counts=positive.sum(1);eligible=counts>0
    if not eligible.any():return z.sum()*0
    return -(logp*positive).sum(1)[eligible].div(counts[eligible]).mean()


def fit_encoder(x,y,train,val,seed,family,epochs=100):
    torch.manual_seed(seed);model=Encoder();opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.001)
    xt=torch.tensor(x,dtype=torch.float32);yt=torch.tensor(y);rng=np.random.default_rng(seed)
    best=float('inf');chosen=epochs-1;state=None;losses=[]
    for epoch in range(epochs):
        order=rng.permutation(train);model.train();total=0.
        for start in range(0,len(order),128):
            idx=order[start:start+128];opt.zero_grad();z=model.embed(xt[idx]);ce=nn.functional.cross_entropy(10*model.head(z),yt[idx])
            loss=ce+(.1*contrastive(z,yt[idx]) if family=='contrastive' else 0.)
            assert torch.isfinite(loss);loss.backward();opt.step();total+=loss.item()*len(idx)
        model.eval()
        if val is not None:
            with torch.no_grad():vl=nn.functional.cross_entropy(model(xt[val]),yt[val]).item()
            if vl<best:best=vl;chosen=epoch;state=copy.deepcopy(model.state_dict())
        else:vl=None
        losses.append([total/len(train),vl])
    if state is not None:model.load_state_dict(state)
    model.eval();return model,losses,chosen


def infer(model,x):
    with torch.no_grad():
        xt=torch.tensor(x,dtype=torch.float32)
        return model.embed(xt).numpy(),model(xt).softmax(1).numpy()


def svc_prob(model,x):
    logits=model.decision_function(x);p=np.exp(logits-logits.max(1,keepdims=True));return p/p.sum(1,keepdims=True)


def retrieval(x,q,g,y,rng,mode='nearest'):
    diff=x[q,None,:].astype(float)-x[g][None,:,:].astype(float)
    d=np.einsum('qnd,qnd->qn',diff,diff,optimize=False)
    idx=nearest(d,g,5) if mode!='random' else np.array([rng.choice(len(g),5,replace=False) for _ in q])
    labels=y[g].copy()
    if mode=='shuffled':labels=labels[rng.permutation(len(g))]
    return np.eye(5)[labels[idx]].mean(1),g[idx],np.take_along_axis(d,idx,axis=1),labels


def source_selection(a,out):
    train=ids_for(a,[6204,6205]);val=ids_for(a,[6206]);x,mu,sd=scale(a['x'],train);y=a['y']
    selections={};details={}
    for family in ('ce','contrastive'):
        rows=[]
        for seed in range(5):
            model,losses,epoch=fit_encoder(x,y,train,val,seed,family)
            _,p=infer(model,x[val]);metric=scores(p,y[val],a['record'][val])
            torch.save(model.state_dict(),out/f'dev-{family}-s{seed}.pt')
            rows.append({'seed':seed,'epoch_count':epoch+1,'losses':losses,'validation':metric})
            print('development',family,seed,'epoch',epoch+1,'record_F1',metric['macro_f1'],flush=True)
        details[family]=rows
    family=max(('ce','contrastive'),key=lambda f:np.mean([r['validation']['macro_f1'] for r in details[f]]))
    comparisons={}
    for method in ('logistic','svm'):
        candidates=[]
        for c in (.1,1.,10.,100.):
            model=LogisticRegression(C=c,max_iter=2000).fit(x[train],y[train]) if method=='logistic' else SVC(C=c,gamma='scale').fit(x[train],y[train])
            p=model.predict_proba(x[val]) if method=='logistic' else svc_prob(model,x[val])
            candidates.append({'C':c,'validation':scores(p,y[val],a['record'][val])})
        best=max(candidates,key=lambda r:r['validation']['macro_f1']);selections[method+'_C']=best['C'];comparisons[method]=candidates
    rf=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,n_jobs=1,random_state=0).fit(x[train],y[train])
    comparisons['rf']=scores(rf.predict_proba(x[val]),y[val],a['record'][val])
    selections.update({'family':family,'epochs':[r['epoch_count'] for r in details[family]],
        'development':details,'baselines':comparisons,'train_ids':train.tolist(),'validation_ids':val.tolist()})
    np.savez_compressed(out/'development_scale.npz',mean=mu,std=sd)
    save_json(out/'selection.json',selections);return selections


def confirm(a,selection,out):
    y=a['y'];source=ids_for(a,[6204,6205,6206]);x,mu,sd=scale(a['x'],source)
    for seed in range(5):
        started=time.perf_counter();model,losses,_=fit_encoder(x,y,source,None,seed,selection['family'],selection['epochs'][seed])
        z,base=infer(model,x);torch.save(model.state_dict(),out/f'final-s{seed}.pt')
        for target in (6207,6208):
            q=ids_for(a,[target],[200,400]);allp=[];results=[]
            arrays={'source_ids':source,'query_ids':q,'query_recordings':a['record'][q],'truth':y[q],
                    'mean':mu,'std':sd,'embeddings':z,'base_probabilities':base}
            for n in BUDGETS:
                support=support_for(a,target,n);g=np.r_[source,support]
                assert set(a['record'][g]).isdisjoint(a['record'][q])
                rng=np.random.default_rng(550000+seed*100+target+n)
                begin=time.perf_counter();mp,ids,d,_=retrieval(z,q,g,y,rng);elapsed=time.perf_counter()-begin
                fp,fids,fd,_=retrieval(x,q,g,y,rng);rp,rids,rd,_=retrieval(z,q,g,y,rng,'random')
                sp,_,_,sl=retrieval(z,q,g,y,rng,'shuffled')
                weights=np.ones(len(g));weights[len(source):]=len(source)/len(support) if len(support) else 1.
                log=LogisticRegression(C=selection['logistic_C'],max_iter=2000).fit(x[g],y[g])
                rf=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,n_jobs=1,random_state=seed).fit(x[g],y[g])
                brf=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,n_jobs=1,random_state=seed).fit(x[g],y[g],sample_weight=weights)
                svm=SVC(C=selection['svm_C'],gamma='scale').fit(x[g],y[g],sample_weight=weights)
                prob={'source-encoder':base[q],'spectral-knn':fp,'embedding-knn':mp,'random-knn':rp,'shuffled-knn':sp,
                    'adapted-logistic':log.predict_proba(x[q]),'adapted-RF':rf.predict_proba(x[q]),
                    'balanced-RF':brf.predict_proba(x[q]),'balanced-SVM':svc_prob(svm,x[q])}
                assert tuple(prob)==METHODS
                for pp in prob.values():assert np.isfinite(pp).all() and np.allclose(pp.sum(1),1.,atol=1e-6)
                metrics={name:scores(pp,y[q],a['record'][q]) for name,pp in prob.items()}
                load_metrics={str(load):{name:scores(pp[a['loads'][q]==load],y[q][a['loads'][q]==load],a['record'][q][a['loads'][q]==load]) for name,pp in prob.items()} for load in (200,400)}
                allp.append(np.stack(list(prob.values())))
                arrays.update({f'n{n}_gallery':g,f'n{n}_nearest_ids':ids,f'n{n}_distances':d,
                    f'n{n}_random_ids':rids,f'n{n}_shuffled_labels':sl,f'n{n}_spectral_ids':fids,
                    f'n{n}_logistic_coef':log.coef_,f'n{n}_logistic_intercept':log.intercept_})
                results.append({'support_windows_per_class':n,'support_seconds_per_class':n*.5,
                    'gallery_windows':len(g),'metrics':metrics,'per_load':load_metrics,
                    'purity':float((y[ids]==y[q,None]).mean()),'random_purity':float((y[rids]==y[q,None]).mean()),
                    'target_support_share':float(np.isin(ids,support).mean()),'retrieval_batch_seconds':elapsed,
                    'retrieval_ms_per_window':1000*elapsed/len(q)})
            arrays['probabilities']=np.stack(allp);stem=f'target{target}-s{seed}'
            np.savez_compressed(out/(stem+'.npz'),**arrays)
            save_json(out/(stem+'.json'),{'target_type':target,'seed':seed,'family':selection['family'],
                'epochs':selection['epochs'][seed],'losses':losses,'methods':METHODS,'budgets':BUDGETS,'results':results})
            print('confirmation',stem,{m:round(v['macro_f1'],4) for m,v in results[-1]['metrics'].items()},flush=True)
        print('seed_seconds',seed,time.perf_counter()-started,flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=('prepare','select','confirm'));ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();out=args.out;torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    if args.mode=='prepare':
        assert not (out/'features.npz').exists();prepare(out/'raw',out);return
    a=np.load(out/'features.npz')
    if args.mode=='select':
        assert not (out/'selection.json').exists()
        save_json(out/'run.json',{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
            'sklearn':sklearn.__version__,'torch':torch.__version__,'input_sha256':sha(out/'features.npz'),
            'harness_sha256':sha(__file__),'protocol_sha256':sha(Path(__file__).with_name('BEARING_PROTOCOL.md'))})
        source_selection(a,out)
    else:
        assert not list(out.glob('target*.json'))
        confirm(a,json.loads((out/'selection.json').read_text()),out)


if __name__=='__main__':main()
