# WRL5: fresh bearing-type transfer with spectral and learned representations

Protocol frozen before downloading/scoring evaluation recordings, 2026-11-23.
Motivated by WRL4; this is a new external dataset, not a rerun of hydraulic tests.
Results cannot establish a universal brain/JEPA mechanism or a database moat.

## Original source and discovery
HUST bearing (Hanoi), Nguyen Duc Thuan and Hoang Si Hong, Mendeley Data V3,
DOI10.17632/cbv7jyx4p9.3, CC BY4.0. Paper:
https://link.springer.com/article/10.1186/s13104-023-06400-4
Original metadata:
https://data.mendeley.com/public-api/datasets/cbv7jyx4p9/files?folder_id=72793f17-cac2-4cc6-ac18-2b047e0d45f8&version=3&$limit=1000
99MAT files, five bearing types6204..6208, three loads0/200/400W, seeded faults.
Use the five classes available for ALL types: N (healthy), I (inner), O (outer),
IO (inner+outer), OB (outer+ball). B/IB excluded because6204 lacks them, not based
on performance. Hence75 files. Paper says both99 records and27 defective/3 healthy
bearings; physical-specimen counting is insufficiently clear. Group by bearing type
and acquisition, never claim that75 files are75 independent bearings or machines.
Only N400.mat was downloaded at discovery to inspect schema: data(512000,1) float64,
fs(1,1) shaft frequency24.93Hz, ru_raw(350000,1). Vibration SAMPLE rate is51200Hz
from original paper, not the MATLAB `fs` field. Do not use run-up arrays. Exact
calibration/unit is not established from the MAT file; record as unspecified,
do not invent physical units. Raw files remain unchanged and checksum-verified.
Repository search found no prior HUST experiment; all target assets are new here.

## Frozen split and label availability
Development training: types6204/6205, all three loads (30 recordings).
Validation:6206, all three loads (15 recordings). Only these select encoder family,
checkpoint epoch, SVM C and logistic C. Final source set includes6204..6206 (45).
Confirmation targets:6207 AND6208; no target data in preprocessing, validation,
architecture selection, early stopping or feature design.
For each target type:0W recordings supply calibration memory;200/400W recordings
are queries (10 separate recordings). Both support and queries are new assets to
source training, but support/query share target type and fault specimen across loads:
this is few-shot calibration, not recognition of entirely unseen target specimens.

Split each recording into all complete nonoverlapping half-second windows
(25600 samples), normally20; see the pre-training schema amendment below.
Training uses all windows of source recordings, inheriting their file label.
Nested target support budgets0/1/2/8 WINDOWS per class use the first windows of the
0W file. These correspond0/.5/1/4 seconds of one labelled acquisition per class,
NOT independent labelled episodes or bearings. Fixed query set: all complete windows of
each200/400W file. Source+support gallery and ordinary adaptation see the SAME data.
No target query label is available to any model. Offline cross-load comparison,
not chronological replay; loaded files can precede support in actual collection.

## Frozen derived representations
Per-window demeaned raw Welch PSD: scipy.signal.welch fs51200,nperseg2048,
noverlap1024,Hann,detrend constant,density. Sum contiguous bins using128 integer
index partitions of the1025 bins; multiply sums by bin width25Hz. Log10 floor1e-20.
Envelope: abs(Hilbert(demeaned raw)); subtract mean; Welch identical parameters;
retain0..3200Hz inclusive (129 bins), sum into64 partitions, log10 same floor.
Eight time statistics: signed mean, std, RMS, absolute peak, peak/RMS,
mean(abs), standardized third moment, standardized fourth moment; denominator
floor1e-12. Log1p of nonnegative std,RMS,peak,crest,meanabs,kurtosis; signed
mean and skew untransformed. Total200 features (128+64+8).
Full spectral energy and amplitude information retained in these model views;
no resampling, per-record amplitude normalization, clipping or raw replacement.
Source-only feature mean/std (scale<1e-6 replaced by1). Development scaler fits
6204/6205 only, final scaler6204..6206 only. Every sample interval has file SHA,
recording name, sample rate and zero-based half-open bounds.

## Learned representation and source-only model selection
Compare two candidate encoders on source validation, not target:
MLP200->256,LayerNorm,GELU,Linear256->128,LayerNorm,GELU,Linear128->64,
L2-normalized embedding. Linear64->5 classifier, logits multiplied by10.
A: cross entropy; B: cross entropy +.1 supervised contrastive loss at temperature.1.
Contrastive denominator includes other samples in batch, excludes self; positives
are other examples of the same class, skip anchors with no positives. This does
not treat windows as independent specimens; it is a representation-training loss.
AdamW lr.001,weight_decay.001,batch128,100epochs,seeded shuffle,CPU2threads,
float32,deterministic Torch. Seeds0..4. Select earliest min validation cross entropy
checkpoint per candidate/seed. Select family by mean validation RECORDING macro-F1
across5 seeds, tie choosesA. Save both candidates' complete curves/checkpoints.
Then retrain selected family from scratch on all45 source recordings, using each
seed's selected development epoch count. No final-source validation or test tuning.
Family B is a supervised metric-learning candidate, NOT JEPA or a reproduced paper.
Its strength is measured, never presumed from architecture size.

RBF SVC C in(.1,1,10,100),gamma='scale'; logistic C in(.1,1,10,100),max_iter2000.
Select C by recording macro-F1 on6206 after fitting6204/6205; ties smallerC.
SVC uses softmax of one-vs-rest decision scores (uncalibrated scores), NOT SVC's
internal window-level probability calibration. RF200 trees,max_features='sqrt',
min_samples_leaf1,seeded,n_jobs1, no parameter search.

## Fixed confirmation arms
- source-encoder: frozen selected encoder and classification head, no support update.
- spectral-knn: top5 uniform votes, standardized200 features, exact squared L2.
- embedding-knn (PRIMARY): top5 uniform votes, unit learned embeddings, squared L2.
- random-knn:5 uniformly random eligible episodes per query, same labelled gallery.
- shuffled-knn: genuine nearest IDs, fixed random permutation of gallery labels.
- adapted-logistic: refit on standardized spectral features, selectedC, all source
  and available target support, uniform example weights.
- adapted-RF: same source/support, uniform weights.
- balanced-RF: target support total weight equals source total when support exists;
  source each1, each support=number_source/number_support. Otherwise all1.
- balanced-SVM: RBF model on standardized spectral features, selectedC, same weights.

Fit conventional methods for each support budget and seed; every method receives
all source labels and same support. Encoder is frozen when memory grows. No learned
gate in this study: WRL4's gate obscured retrieval benefit. No target context labels
or filenames enter features. Deterministic ties by lexicographic file/window ID.

## Metrics, decisions and audits
Primary recording macro-F1: average window probabilities/scores by acquisition,
argmax, five classes. Report per target/load, both target aggregates, all budgets,
all seeds. Primary success at8 support windows/class: embedding-knn must exceed
source-encoder, random/shuffled controls, spectral-knn AND EACH ordinary adaptation
baseline by >=.03 pooled absolute recording macro-F1, and beat source-encoder and
all ordinary baselines on EACH target type's seed-mean aggregate. If any comparator
fails, overall gate fails. No selection of the best budget/target after scoring.
Report differences, label purity, source vs target support selection share, gallery
sizes, inference time with exclusions, and prediction examples. Also report whether
the selected encoder beats ordinary classifiers on source validation, to expose a
weak representation. A lower-than-baseline model is not evidence of strong encoding.

Only two held-out bearing types, five class specimens per type, two loads each:
no window bootstrap, seed-based significance or population CI. Exact per-recording
predictions and paired disagreements are more honest than precision from pseudoreplication.
Record raw publisher SHA256 checks, complete source manifests, source-only fitting,
selected hyperparameters, saved checkpoints and all predictions/references. Tests
on synthetic/source-only data before freezing; no target scoring until code+protocol
commit succeeds. Audit all references and disjoint file identities, independent
metric/ranking reconstruction and checkpoint replay. Preserve numerical warnings
and failed/negative results. No silent reruns or changes after confirmation.

No new extension, production code, website, network service, GPU or dependencies.
Use existing pinned research venv. Stop after this finite matrix and audit.

## Pre-training schema amendment (2026-11-23)
Initial prepare stopped at IO400.mat: actual512001 rather than512000 samples.
No model was trained and no validation/target prediction or score was produced.
A shape-only MAT inventory found65 files of512000 samples, six of512001
(IO400/402/404 and OB500/502/504), OB400465242, OB402121082, OB404283728,
and OB804256000 samples. The raw files match original publisher hashes.
Use floor(length/25600) full windows; preserve and report trailing samples in each
manifest. This yields1463 windows:873 final-source,200 target6207 query,190
target6208 query, and200 target support-pool windows. Source training573 windows,
validation300. Source OB class has fewer windows; no balancing rule is introduced
after discovery. Recording-level scoring retains equal acquisition weight.
The first prepare failure log is preserved as prepare-initial-failed.log.
This schema correction is committed before any model fitting; architecture,
feature definitions, split, support budgets and success criteria stay fixed.
