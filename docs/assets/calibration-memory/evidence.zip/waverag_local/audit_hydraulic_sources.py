"""Resolve every example citation to original ZIP rows and verify derived samples."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile
import numpy as np
from hydraulic import ARCHIVE_SHA,SENSORS,sha,save_json


def main():
    archive,root,citations,out=map(Path,sys.argv[1:])
    assert sha(archive)==ARCHIVE_SHA
    examples=json.loads(citations.read_text())
    ids=set()
    for example in examples['examples']:
        ids.add(example['query_cycle_id_zero_based'])
        ids.update(ref['cycle_id_zero_based'] for ref in example['references'])
    features=np.load(root/'features.npz');checked=0;max_error=0.
    with zipfile.ZipFile(archive) as z:
        for c,sensor in enumerate(SENSORS):
            spec=examples['source_spec']['sensors'][c]
            assert hashlib.sha256(z.read(spec['member'])).hexdigest()==spec['member_sha256']
            seen=set()
            with z.open(spec['member']) as f:
                for i,line in enumerate(f):
                    if i not in ids:continue
                    a=np.fromstring(line.decode(),sep='\t');seen.add(i)
                    assert len(a)==spec['sample_interval'][1] and len(a)==60*spec['sample_rate_hz']
                    temporal=a.reshape(60,spec['sample_rate_hz']).mean(1)
                    error=float(abs(temporal-features['temporal'][i,:,c]).max())
                    assert error<1e-12,error
                    max_error=max(max_error,error);checked+=1
            assert seen==ids
    save_json(out,{'scope':'Original ZIP readback of deterministic examples, not a DB benchmark',
                   'archive_sha256':ARCHIVE_SHA,'example_queries':len(examples['examples']),
                   'unique_cycles':len(ids),'sensor_recordings_checked':checked,
                   'maximum_derived_sample_error':max_error,'all_member_hashes_match':True})
    print('Verified original sensor recordings:',checked,'max derived error',max_error)


if __name__=='__main__':main()
