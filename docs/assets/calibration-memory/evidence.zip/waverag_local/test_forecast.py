import unittest
import numpy as np
from forecast import split_starts, eligible, standardize, windows, L, H


class Contracts(unittest.TestCase):
    def test_target_boundaries(self):
        for name,(lo,hi) in zip(('train','valid','test'),((0,8640),(8640,11520),(11520,14400))):
            ids=split_starts()[name]
            self.assertGreaterEqual(ids[0]+L,lo)
            self.assertEqual(ids[-1]+L+H,hi)
        self.assertEqual(len(split_starts()['test']),2785)

    def test_half_open_overlap(self):
        selected=eligible(3000,1000,True)
        self.assertIn(1000+L+H,selected)
        self.assertIn(1000-L-H,selected)
        self.assertNotIn(1000+L+H-1,selected)
        self.assertNotIn(1000,selected)

    def test_scaling_cannot_see_future(self):
        a=np.arange(14400*7,dtype='f8').reshape(14400,7)
        b=a.copy(); b[8640:]*=100
        aa,mu,sd=standardize(a); bb,mu2,sd2=standardize(b)
        np.testing.assert_array_equal(mu,mu2)
        np.testing.assert_array_equal(sd,sd2)
        np.testing.assert_array_equal(aa[:8640],bb[:8640])

    def test_reference_identity(self):
        a=np.arange(2000,dtype='f4').reshape(1000,2)
        x,y=windows(a,[0,30],l=12,h=4)
        np.testing.assert_array_equal(x[1],a[30:42])
        np.testing.assert_array_equal(y[1],a[42:46])


if __name__=='__main__': unittest.main()
