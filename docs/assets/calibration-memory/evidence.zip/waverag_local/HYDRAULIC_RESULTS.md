# WRL3: naive historical retrieval does not help across cooler-state shifts

The [UCI hydraulic dataset](https://archive.ics.uci.edu/dataset/447/condition+monitoring+of+hydraulic+systems)
is the source. The frozen [protocol](HYDRAULIC_PROTOCOL.md) was committed as `3b0e58f` before
feature extraction, fitting or scoring. We completed 60 cases: two diagnostic
targets, two label budgets, three cooler-state holdouts and five seeds. Twelve
methods/controls produce 720 evaluated prediction sets. This is one hydraulic rig,
with offline cross-state transfer; it is not a fleet, online replay or LLM study.

## Results

Primary metric is macro-F1 on whole condition blocks, averaged equally over the
five seeds and three cooler holdouts. Higher is better. Each test holdout has
48 blocks, 12 per class; repeated cycles within a block are averaged before scoring.
Eight or 32 labelled cycles are the complete training AND reference budget.

| Method | Valve, 8 labels | Valve, 32 labels | Accumulator, 8 labels | Accumulator, 32 labels |
|---|---:|---:|---:|---:|
| Logistic regression | .2703 | .2727 | **.1655** | **.1812** |
| Random forest | **.2830** | **.5769** | .1568 | .1537 |
| Small temporal CNN | .1280 | .1294 | .1079 | .1153 |
| Five-neighbour retrieval | .2089 | .2375 | .1034 | .1417 |
| DTW nearest neighbour | .1000 | .1458 | .1024 | .1234 |
| Random forest + retrieval | .2436 | .4083 | .1254 | .1172 |
| Random forest + random references | .2914 | .5652 | .1723 | .1494 |

Bold identifies the strongest non-retrieval comparator, not necessarily the largest
number in each column. The [full table](results/hydraulic_table.md) includes CNN
fusion and shuffled-label controls. The constant-class baseline has macro-F1 .1000;
do not confuse this with the .25 expected label agreement of random references.

**None of the 16 predeclared gates passes** (four retrieval methods/fusions across
four target/budget settings). No retrieval method beats the strongest ordinary
classifier on the pooled primary metric. For valve diagnosis with 32 labels,
adding neighbours reduces random-forest macro-F1 from .5769 to .4083, a decline
of 16.86 percentage points. A random-reference mixture is substantially better
than the genuine-neighbour mixture there. More accurate source IDs cannot by
themselves make these references diagnostically useful.

Small improvements over the weak CNN or in individual cooler holdouts do occur.
All are retained in [hydraulic_summary.json](results/hydraulic_summary.json), rather
than selecting a favourable subgroup. Accumulator diagnosis is difficult for all
tested methods; these low scores cannot establish the best achievable performance
of supervised learning on this dataset.

## What failed

Nearest-reference label agreement is only 24.3–28.3%, depending on target/budget;
random references achieve 24.7–24.9%. DTW on the one-second temporal view is also
weak. Label agreement is a relevance check, not a measure of causal explanation.

Post-run inspection of the existing distances shows a strong representation issue:
when cooler state 100 is held out, PS4 contributes an average 98.26% of nearest-match
squared distance. Some held-out statistical features exceed 1.5 million training
standard deviations because their variation in the tiny source training set is
very small. The fixed training-only standardization is numerically finite, but it
does not provide a robust similarity measure across this shift.

This supports an inference: the current metric can be dominated by a changed
component condition, rather than selecting episodes useful for the requested
diagnosis. It does not prove that PS4 is causally irrelevant, nor that removing it
will solve the problem. We did not remove channels, clip features, retune distances
or rerun the experiment after observing test outcomes.

## References and source integrity

[hydraulic_citations.json](results/hydraulic_citations.json) contains 24 deterministic
example queries and their five references: seed 0, the larger budget, the first
stable cycle for each target class in each held-out cooler state. The examples
include successes and failures by construction. They are data references, not
generated maintenance explanations.

Every reference is checked to be one of the labelled source cycles, outside the
held-out cooler state and outside the query's condition block. The manifest maps
each cycle ID to its original sensor-file row, zero-based half-open sample interval,
sampling rate, member hash and archive hash. Ground-truth query labels are marked
as evaluator information and were not inputs to retrieval.
All example references and queries were resolved back to the original archive:
882 sensor recordings across 63 distinct cycles reproduce their stored temporal
summaries exactly. See [source readback audit](results/hydraulic_source_audit.json).

The original ZIP is authoritative and unchanged. All14 physical sensors retain
their original 1/10/100Hz specifications. The model uses explicitly derived summaries:
280 statistical features and 60 one-second means per channel. No raw recording was
silently resampled, interpolated, recalibrated or replaced. Virtual CE/CP/SE sensors
are excluded. DTW here is on the derived temporal view, not full-rate samples.

## Verification and limitations

- Six new contract tests cover blocks, nested budgets, holdout disjointness,
  source-only scaling, deterministic ties, block metrics and independent DTW
  recurrence (some tests cover multiple contracts). The complete local research
  suite has 15 passing tests.
- All720 metric sets are recomputed from stored predictions. The first summary
  check exposed dtype promotion in the mixed prediction stack; restoring the CNN's
  original float32 reduction reproduced its original metrics exactly. No training
  run or reported result was replaced.
- NumPy/scikit-learn emitted divide/overflow/invalid warnings in matrix operations.
  We preserved the logs and audited every case. An independent non-BLAS logistic
  forward calculation differs by at most 1.99e-14; the independently computed
  regularized objective gradient is at most 9.99e-5. Random-forest refits and CNN
  checkpoint replay match all stored per-cycle probabilities exactly. Real-pair
  DTW agrees with a separate Python recurrence to relative error 2.10e-16. See
  [hydraulic_numerical_audit.json](results/hydraulic_numerical_audit.json).
- Stable-cycle filtering and balanced label acquisition use the dataset's known
  labels. Detecting stability and discovering labels in production cost additional
  work. No claim is made about that annotation workflow.
- There is no operating-metadata-only classifier: the profile fields are component
  condition labels used to define this evaluation, not independently supplied
  operational metadata. The no-feature comparator is the uniform class prior.
- The cooler states are co-occurring component conditions on one rig. Source cycles
  can occur later in acquisition order than the held-out state: this is an offline
  experiment, not a causal historical replay. We do not have independent test assets.
- The fixed small CNN is not an xLSTM or published TCN reproduction. No model or
  hyperparameter search was performed. These results are not a universal limit on
  learned retrieval, waveform representations or machine diagnosis.
- No MorletDB search, storage performance, access-control workflow, LLM explanation
  quality or database extension was evaluated. Prior WRL1/WRL2 evidence is unchanged.

## Technical implications and next hypothesis

Do not treat a nearest waveform match as an automatically useful lesson. A shared
archive should expose the candidate's operating context, representation version,
label provenance and coverage, and allow the consumer to decline unsupported
comparisons. That is a proposed application requirement, not a validated new feature.

The next hypothesis should distinguish compatible-context retrieval from
out-of-context retrieval and test an abstention rule fitted only on source data.
Compare a task-trained or nuisance-resistant representation against plain distance,
with the same label budget and a strong tree baseline. If using the PS4 observation
to design that representation, treat these hydraulic results as development data
and obtain an independent holdout for confirmation. Existing raw-signal provenance
remains useful infrastructure, but this study does not establish a new database moat.

## Reproduce

The original ZIP remains in ignored `data/wrl2-20261123/inputs/`; full WRL3 outputs,
checkpoints, numerical logs and the compiled DTW kernel are retained in ignored
`data/wrl3-20261123/`. Code, protocol, summaries, examples and checksums are committed
on the isolated local research branch. No production file, website or migration changed.

```sh
c++ -O3 -std=c++17 -dynamiclib research/waverag_local/hydraulic_dtw.cpp -o /tmp/wrl3-dtw.dylib
PYTHONPATH=/tmp/wrl-anchor-deps /Users/zin/sophia/morletdb/.venv-research/bin/python \
  -m unittest discover -s research/waverag_local -p 'test_hydraulic.py' -v
export OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
WRL_ARCHIVE=/Users/zin/sophia/morletdb/data/wrl2-20261123/inputs/wrl2-hydraulic.zip
/Users/zin/sophia/morletdb/.venv-research/bin/python research/waverag_local/hydraulic.py prepare --archive "$WRL_ARCHIVE" --out /tmp/wrl3-reproduction
/Users/zin/sophia/morletdb/.venv-research/bin/python research/waverag_local/hydraulic.py run --archive "$WRL_ARCHIVE" --out /tmp/wrl3-reproduction
/Users/zin/sophia/morletdb/.venv-research/bin/python research/waverag_local/summarize_hydraulic.py /tmp/wrl3-reproduction /tmp/wrl3-summary
/Users/zin/sophia/morletdb/.venv-research/bin/python research/waverag_local/audit_hydraulic.py /tmp/wrl3-reproduction /tmp/wrl3-summary/audit.json
```

These commands were tested on macOS arm64; Linux needs its equivalent shared-library
compiler flags/path. Exact compiler, package versions, source and artifact hashes
are in the result manifest. Reproduction is not additional independent evidence.
