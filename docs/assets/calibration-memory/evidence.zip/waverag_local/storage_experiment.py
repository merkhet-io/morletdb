"""Conditional WRL2-S. Requires its own disposable PostgreSQL database."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from forecast import L,H,C,PERIODS,digest,standardize,split_starts,windows,make_model,json_write


def transform(raw, weights, mu, sd):
    normalized=torch.tensor(((raw-mu)/sd).astype('f4'))
    outputs=[]
    for i,g in enumerate(PERIODS):
        values=normalized[i].reshape(20,H//g,g,C).mean(2).repeat_interleave(g,dim=1)
        values=values-values[:,-1:,:]
        outputs.append((values*weights[i,:,None,None]).sum(0))
    return torch.stack(outputs)


def main():
    import psycopg
    p=argparse.ArgumentParser()
    p.add_argument('--results',type=Path,required=True)
    p.add_argument('--summary',type=Path,required=True)
    p.add_argument('--csv',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--dsn',required=True)
    args=p.parse_args()
    assert json.loads(args.summary.read_text())['conditional_storage_gate_passed']
    assert not args.out.exists(),'Use a fresh output directory; never overwrite prior results'
    args.out.mkdir(parents=True)
    sys.path.insert(0,'/tmp/waverag-anchor-raft')
    from layers.Retrieval import RetrievalTool
    import morletdb
    torch.set_num_threads(2)
    raw=np.loadtxt(args.csv,delimiter=',',skiprows=1,usecols=range(1,8))[:14400]
    a,mu,sd=standardize(raw)
    raw=np.asarray(raw[:8640],dtype='<f8')
    starts=split_starts()
    query_ids=np.linspace(0,len(starts['test'])-1,64,dtype='i8')
    queries,_=windows(a,starts['test'][query_ids])
    rt=RetrievalTool(L,H,C,n_period=3,topm=20)
    gallery,_=windows(a,starts['train'])
    mg,_=rt.decompose_mg(gallery)
    keys=mg.flatten(start_dim=2)
    keys=F.normalize(keys-keys.mean(2,keepdim=True),dim=2)
    qm,_=rt.decompose_mg(queries)
    qf=qm.flatten(start_dim=2)
    qf=F.normalize(qf-qf.mean(2,keepdim=True),dim=2)
    scores,selected=torch.bmm(qf,keys.transpose(1,2)).topk(20,dim=2)
    weights=(scores/.1).softmax(2)
    ids=selected.numpy()
    assert (ids>=0).all() and (ids+L+H<=8640).all()
    json_write(args.out/'references.json',{'query_ids':query_ids.tolist(),
                'gallery_starts':ids.tolist(),'weights':weights.tolist(),
                'source_sha256':digest(args.csv),'representation':'RAFT periods4,2,1 normalized f32'})
    cache=torch.load(args.results/'retrieval.pt',weights_only=True)
    expected=cache['raft']['test'][:,query_ids]
    forecast=make_model('raft',cache)
    forecast.load_state_dict(torch.load(args.results/'raft-0.pt',weights_only=True))
    forecast.eval()
    with torch.no_grad():
        before=forecast(queries,torch.tensor(query_ids),'test')
    # Free search workspaces; the search representation remains a separate cost.
    key_bytes=keys.numel()*keys.element_size()
    del keys,mg,qf,qm,gallery,rt
    build={}
    t=time.perf_counter()
    expanded=np.stack([raw[i+L:i+L+H] for i in starts['train']])
    expanded_path=args.out/'expanded.npy'
    np.save(expanded_path,expanded)
    with expanded_path.open('rb') as f: os.fsync(f.fileno())
    build['materialized']=time.perf_counter()-t
    t=time.perf_counter()
    raw_path=args.out/'raw.bin'
    with raw_path.open('wb') as f:
        f.write(raw.tobytes()); f.flush(); os.fsync(f.fileno())
    mapped=np.memmap(raw_path,dtype='<f8',mode='r',shape=raw.shape)
    build['memmap']=time.perf_counter()-t
    t=time.perf_counter()
    db_path=args.out/'signals.morlet'
    db=morletdb.open(db_path)
    for channel in range(C):
        db.ingest(str(channel),raw[:,channel],sample_rate_hz=1/3600,
                  channel=str(channel),unit='source_units_unspecified',
                  metadata={'source_sha256':digest(args.csv),'first_row':0,'last_row_exclusive':8640})
        recovered=db.read(str(channel),0,8640).samples
        np.testing.assert_array_equal(recovered.view('u8'),raw[:,channel].copy().view('u8'))
    build['morlet_sqlite']=time.perf_counter()-t
    conn=psycopg.connect(args.dsn,autocommit=True)
    t=time.perf_counter()
    conn.execute('CREATE TABLE recording (id int PRIMARY KEY, end_sample int NOT NULL, samples bytea NOT NULL)')
    conn.execute('INSERT INTO recording VALUES (1,8640,%s)',(raw.tobytes(),))
    build['postgres_bytea']=time.perf_counter()-t
    postgres_version=conn.execute('SELECT version()').fetchone()[0]
    pg_read='''SELECT requested.ordinality, substring(samples FROM (requested.start+720)*56+1 FOR 5376)
        FROM recording, unnest(%s::integer[]) WITH ORDINALITY AS requested(start,ordinality)
        WHERE id=1 AND requested.start>=0 AND requested.start+816<=end_sample
        ORDER BY requested.ordinality'''
    def read(name,chosen):
        flat=chosen.reshape(-1)
        if name=='materialized':
            return expanded[chosen]
        if name=='memmap':
            return np.stack([mapped[i+L:i+L+H] for i in flat]).reshape(3,20,H,C)
        if name=='postgres_bytea':
            records=conn.execute(pg_read,(flat.tolist(),)).fetchall()
            assert [r[0] for r in records]==list(range(1,61))
            return np.stack([np.frombuffer(r[1],dtype='<f8').reshape(H,C) for r in records]).reshape(3,20,H,C)
        return np.stack([np.column_stack([db.read(str(c),int(i+L),int(i+L+H)).samples
                                        for c in range(C)]) for i in flat]).reshape(3,20,H,C)
    names=list(build)
    latencies={k:[] for k in names}
    max_error={k:0. for k in names}
    tensors={k:[] for k in names}
    for name in names:
        transform(read(name,ids[:,0]),weights[:,0],mu,sd)
    for repeat in range(3):
        for q in range(64):
            rotated=names[(q+repeat)%4:]+names[:(q+repeat)%4]
            for name in rotated:
                t=time.perf_counter()
                v=read(name,ids[:,q])
                value=transform(v,weights[:,q],mu,sd)
                latencies[name].append((time.perf_counter()-t)*1000)
                np.testing.assert_array_equal(v.view('u8'),expanded[ids[:,q]].view('u8'))
                error=(value-expected[:,q]).abs().max().item()
                assert error<2e-5,(name,q,error)
                max_error[name]=max(max_error[name],error)
                if repeat==0: tensors[name].append(value)
    prediction_errors={}
    for name in names:
        forecast.retrieval_dict={'test':torch.stack(tensors[name],dim=1)}
        with torch.no_grad(): after=forecast(queries,torch.arange(64),'test')
        error=(before-after).abs().max().item()
        assert error<2e-5,(name,error)
        prediction_errors[name]=error
    def sizes():
        return {'materialized':expanded_path.stat().st_size,'memmap':raw_path.stat().st_size,
                'postgres_bytea':conn.execute("SELECT pg_total_relation_size('recording')").fetchone()[0],
                'morlet_sqlite':sum(f.stat().st_size for f in args.out.glob('signals.morlet*'))}
    size_before=sizes()
    suffix=np.repeat(raw[-1:],96,axis=0)
    t=time.perf_counter()
    with raw_path.open('ab') as f:
        f.write(suffix.tobytes()); f.flush(); os.fsync(f.fileno())
    updates={'memmap':time.perf_counter()-t,'materialized':None}
    t=time.perf_counter()
    conn.execute('UPDATE recording SET samples=samples||%s,end_sample=end_sample+96 WHERE id=1',(suffix.tobytes(),))
    updates['postgres_bytea']=time.perf_counter()-t
    t=time.perf_counter()
    for c in range(C): db.append(str(c),8640,suffix[:,c])
    updates['morlet_sqlite']=time.perf_counter()-t
    full=np.concatenate((raw,suffix))
    np.testing.assert_array_equal(np.fromfile(raw_path,dtype='<f8').view('u8'),full.ravel().view('u8'))
    pgfull=conn.execute('SELECT samples FROM recording').fetchone()[0]
    np.testing.assert_array_equal(np.frombuffer(pgfull,dtype='<f8').view('u8'),full.ravel().view('u8'))
    for c in range(C):
        np.testing.assert_array_equal(db.read(str(c),0,8736).samples.view('u8'),full[:,c].copy().view('u8'))
    size_after=sizes()
    db.close(); conn.close()
    result={'scope':'warm local continuation fetch plus transform; NOT retrieval-search or pg_morlet benchmark',
        'protocol_sha256':digest(Path(__file__).with_name('STORAGE_PROTOCOL.md')),
        'harness_sha256':digest(__file__),'source_sha256':digest(args.csv),
        'native_library_sha256':digest(os.environ['MORLETDB_SQLITE_LIB']),
        'native_library_provenance':'Existing local build; source revision not independently established',
        'postgres_version':postgres_version,'build_seconds':build,'physical_bytes_before_append':size_before,
        'physical_bytes_after_append':size_after,'append96_seconds':updates,
        'append_atomicity':'Morlet seven channel transactions; PG one; memmap file fsync. Not equivalent.',
        'raw_bit_parity':True,'continuation_max_abs_error':max_error,'forecast_max_abs_error':prediction_errors,
        'latencies_ms':latencies,'latency_summary_ms':{k:{'p50':float(np.median(v)),
             'p95':float(np.percentile(v,95))} for k,v in latencies.items()},
        'search_keys_still_required_bytes':key_bytes,'reference_manifest_bytes':(args.out/'references.json').stat().st_size,
        'concurrency_note':'Forecast training processes may still run; timing is exploratory, not isolated hardware.'}
    json_write(args.out/'storage_results.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='latencies_ms'},indent=2))


if __name__=='__main__':main()
