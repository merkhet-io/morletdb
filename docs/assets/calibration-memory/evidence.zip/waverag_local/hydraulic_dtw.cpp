#include <algorithm>
#include <cmath>
#include <vector>
extern "C" void hydraulic_dtw(const double* q, const double* g, int nq, int ng,
                             int t, int c, int band, double* out) {
  std::vector<double> previous(t+1), current(t+1);
  for (int a=0; a<nq; ++a) for (int b=0; b<ng; ++b) {
    std::fill(previous.begin(),previous.end(),INFINITY); previous[0]=0;
    for (int i=1;i<=t;++i) {
      std::fill(current.begin(),current.end(),INFINITY);
      for (int j=std::max(1,i-band);j<=std::min(t,i+band);++j) {
        double cost=0;
        for(int k=0;k<c;++k) {
          double d=q[(a*t+i-1)*c+k]-g[(b*t+j-1)*c+k]; cost+=d*d;
        }
        current[j]=cost+std::min({previous[j],current[j-1],previous[j-1]});
      }
      previous.swap(current);
    }
    out[a*ng+b]=previous[t];
  }
}
