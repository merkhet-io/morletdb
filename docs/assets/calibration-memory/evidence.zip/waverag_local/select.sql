SELECT e.cut,
       sqrt((SELECT sum((f.value - q.value) * (f.value - q.value))
             FROM unnest(e.features) WITH ORDINALITY AS f(value, n)
             JOIN unnest(%s::double precision[]) WITH ORDINALITY AS q(value, n)
               USING (n))) AS distance,
       e.source_sha256,
       CASE WHEN e.source_available THEN 'available' ELSE 'missing_source' END AS evidence_state
FROM episodes e
WHERE e.tool = %s AND e.label_available_at <= %s
  AND cardinality(e.features) = %s
ORDER BY distance, e.cut
LIMIT 5
