"""WRL3 complete-results aggregation, eligibility checks, and deterministic citations."""
import json
from pathlib import Path
import sys
import numpy as np
from hydraulic import METHODS,TARGETS,COOLERS,evaluate,sha,save_json


def main():
    root,out=map(Path,sys.argv[1:]);out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((root/'manifest.json').read_text())
    base=Path(__file__).parent
    assert manifest['harness_sha256']==sha(base/'hydraulic.py')
    assert manifest['protocol_sha256']==sha(base/'HYDRAULIC_PROTOCOL.md')
    a=np.load(root/'features.npz');profile=a['profile'];blocks=a['blocks']
    source=json.loads((root/'source.json').read_text())
    results={};citations=[];case_rows=[]
    for target,column in TARGETS.items():
        for budget in (2,8):
            rows=[]
            for held in COOLERS:
                for seed in range(5):
                    stem=f'{target}-cooler{held}-n{budget}-s{seed}'
                    r=json.loads((root/(stem+'.json')).read_text());raw=np.load(root/(stem+'.npz'))
                    train,query=raw['train_ids'],raw['query_ids']
                    assert len(train)==4*budget and len(set(blocks[train]))==len(train)
                    assert (profile[train,0]!=held).all() and (profile[query,0]==held).all()
                    assert set(blocks[train]).isdisjoint(blocks[query])
                    for k in ('knn_ids','random_ids','dtw_ids'):
                        assert np.isin(raw[k],train).all()
                    for m,p in zip(METHODS,raw['probabilities']):
                        # np.stack promotes the mixed model outputs to f64. Restore
                        # the CNN's original f32 reduction before exact replay.
                        if m=='tcn':p=p.astype('f4')
                        checked=evaluate(p,raw['y_true'],raw['query_blocks'])
                        assert checked==r['metrics'][m],(stem,m)
                    rows.append(r)
                    case_rows.append({k:v for k,v in r.items() if k not in ('metrics','tcn_training_loss')}
                                     | {'block_macro_f1':{k:v['block_macro_f1'] for k,v in r['metrics'].items()}})
                    if seed==0 and budget==8:
                        for label in range(4):
                            i=int(np.flatnonzero(raw['y_true']==label)[0]);q=int(query[i])
                            refs=[{'cycle_id_zero_based':int(ref),'block_id':int(blocks[ref]),
                                   'cooler_state':int(profile[ref,0]),'historical_target_label':int(profile[ref,column]),
                                   'distance':float(distance)} for ref,distance in zip(raw['knn_ids'][i],raw['knn_distances'][i])]
                            citations.append({'case':stem,'query_cycle_id_zero_based':q,
                                 'evaluation_truth':int(profile[q,column]),
                                 'query_cooler_state':held,'references':refs,
                                 'all_sensor_intervals':'Use sensor member and interval in source_spec; CSV row=cycle_id+1 (no header).',
                                 'inference':'Label agreement is reference relevance, not causal explanation.'})
            models={}
            for method in METHODS:
                domains={str(c):float(np.mean([r['metrics'][method]['block_macro_f1'] for r in rows if r['held_cooler']==c])) for c in COOLERS}
                models[method]={'mean_block_macro_f1':float(np.mean(list(domains.values()))),
                                'domain_mean_block_macro_f1':domains,
                                'mean_cycle_macro_f1':float(np.mean([r['metrics'][method]['cycle_macro_f1'] for r in rows])),
                                'mean_block_balanced_accuracy':float(np.mean([r['metrics'][method]['block_balanced_accuracy'] for r in rows]))}
            baselines=('logistic','rf','tcn')
            strongest=max(models[m]['mean_block_macro_f1'] for m in baselines)
            domain_strongest={str(c):max(models[m]['domain_mean_block_macro_f1'][str(c)] for m in baselines) for c in COOLERS}
            gates={}
            for method in ('knn','dtw','rf-knn','tcn-knn'):
                score=models[method]['mean_block_macro_f1']
                delta=score-strongest
                per_domain={str(c):models[method]['domain_mean_block_macro_f1'][str(c)]-domain_strongest[str(c)] for c in COOLERS}
                controls={}
                if '-' in method:
                    backbone=method.split('-')[0]
                    controls={m:score-models[backbone+'-'+m]['mean_block_macro_f1'] for m in ('random','shuffled')}
                gates[method]={'gain_over_best_nonretrieval':delta,'domain_gains_over_domain_best':per_domain,
                               'gain_over_controls':controls,
                               'pass':delta>=.02 and all(v>0 for v in per_domain.values()) and all(v>=.02 for v in controls.values())}
            results[f'{target}-{budget}']={'target':target,'labels_per_class':budget,'models':models,'gates':gates,
                  'mean_reference_purity':{k:float(np.mean([r[k] for r in rows])) for k in ('knn_label_purity','random_label_purity','dtw_label_purity')}}
    assert len(case_rows)==60 and len(citations)==24
    artifacts={str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(root.iterdir()) if p.is_file()}
    summary={'scope':'Offline small-label diagnosis on one rig; no LLM or DB search evaluated',
             'manifest':manifest,'source':source,'settings':results,'cases':case_rows,'artifacts':artifacts,
             'any_gate_passed':any(g['pass'] for r in results.values() for g in r['gates'].values()),
             'verification':{'cases':60,'scored_predictions':60*len(METHODS),
                             'all_metrics_recomputed':True,'reference_eligibility_checked':True}}
    save_json(out/'hydraulic_summary.json',summary)
    save_json(out/'hydraulic_citations.json',{'source_spec':source,'examples':citations})
    lines=['| Model | Valve:8 labels | Valve:32 labels | Accumulator:8 labels | Accumulator:32 labels |',
           '|---|---:|---:|---:|---:|']
    for method in METHODS:
        lines.append('| '+method+' | '+' | '.join(f"{results[key]['models'][method]['mean_block_macro_f1']:.4f}" for key in ('valve-2','valve-8','accumulator-2','accumulator-8'))+' |')
    (out/'hydraulic_table.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines));print('Any predefined gate passed:',summary['any_gate_passed'])


if __name__=='__main__':main()
