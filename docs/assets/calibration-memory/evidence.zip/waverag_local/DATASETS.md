# Datasets for the next Wave-RAG investigation

Discovery audit on 2026-11-23. At discovery, only ETTh1/ETTh2 had been benchmarked in
WRL2. The subsequent [WRL3 hydraulic experiment](HYDRAULIC_RESULTS.md) is now complete;
none of its retrieval improvement gates passed. The other entries remain candidates,
not evidence of retrieval benefit. Archive
hashes and structural measurements are in `results/dataset_audit.json`; Kaggle
versions/licenses and ETT timestamp checks are in `results/forecast_artifact_audit.json`.

## Recommended sequence

| Priority | Dataset and source | Useful question | Required split/control | Local status |
|---|---|---|---|---|
| 1 | [UCI hydraulic systems](https://archive.ics.uci.edu/dataset/447/condition+monitoring+of+hydraulic+systems) | Can prior labelled machine cycles improve diagnosis under a changed operating condition or a small label budget? | Split contiguous experimental condition blocks before extracting windows; compare operating-condition-only, engineered-feature tree model, nearest neighbour, DTW and a learned temporal model with/without references. Do not randomly split subwindows of one cycle. | Downloaded and structurally audited: 2,205 cycles, 17 sensor matrices, no nonfinite numeric sensor entries. |
| 2 | [Preventive to Predictive Maintenance, Kaggle](https://www.kaggle.com/datasets/prognosticshse/preventive-to-predicitve-maintenance) | Can shared history improve forecasts when earlier maintenance histories are censored and a new asset has few labels? | Hold out complete service lives and dust/feed conditions; use censor-aware baselines and only outcomes available at the decision time. Exclude bundled uncensored training file. Resolve time-reset issue first. | Downloaded version 8, CC BY 4.0; audited 50 training IDs and 39,420 training rows. No model scores. |
| 3 | [CNC Mill Tool Wear, Kaggle](https://www.kaggle.com/datasets/shasun/tool-wear-detection-in-cnc-mill) | Can an agent retrieve comparable machining stages and correctly explain worn vs unworn tools? | Hold out entire experiments and matched feed/clamp conditions. Compare metadata-only and simple feature classifiers before deep models. Evaluate explanation references against experiment labels. | Downloaded version 4, CC0; 18 experiments (8 unworn/10 worn), 48 columns per recording. Good demo, too few independent runs for a broad fleet claim. |
| 4 | [MetroPT-3, UCI](https://archive.ics.uci.edu/dataset/791/metropt+3+dataset) | Does memory of prior compressor episodes improve fault anticipation or reduce false alarms over months? | Chronological replay with episode exclusion and maintenance-report availability times. Evaluate event recall, lead time and false alarms per day. | Source inspected; archive not downloaded. Real operational data plus reported failure intervals. Timestamp/sampling audit required. |
| 5 | [NASA milling / IMS bearings / C-MAPSS](https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/) | Tool-wear transfer, bearing degradation, and cross-asset RUL respectively. | Hold out full tool/bearing/engine identities. Compare last observation, age/operating-condition baseline, feature regression and xLSTM/TCN with/without retrieval. | Source inspected only. C-MAPSS is simulated; keep that separate from measured machinery data. |
| 6 | [LANL earthquake prediction, Kaggle](https://www.kaggle.com/c/LANL-Earthquake-Prediction/data) | Can similar acoustic histories improve time-to-failure estimates? | Split by complete laboratory failure cycles and acquisition regime; purge overlap. Do not use random overlapping segments or imply field earthquake prediction. | Source inspected only; competition access/rules need checking before download. |

ETTh1 and ETTh2 remain the small, reproducible positive-control attempt; they are
hourly transformer series, not a substitute for a factory diagnosis benchmark.
They come from the [original ETT repository](https://github.com/zhouhaoyi/ETDataset).

## Findings that change implementation

**Hydraulics:** archive inspection confirms 17 channels at three sampling rates:
seven matrices with 6,000 samples/cycle, two with 600, eight with 60. Each cycle is
60 seconds according to the dataset documentation. Keep separate channel sampling
specifications; do not silently resample them into a single tensor. `profile.txt`
contains four condition labels plus a stability flag. These are outcomes/selection
metadata, not sensor inputs. Adjacent repeated condition blocks are a leakage risk.
The original file is preferable to a Kaggle mirror whose preprocessing is unknown.

**Filtration:** the original creators explicitly target incomplete service lives;
see their [dataset paper](https://www.papers.phmsociety.org/index.php/ijphm/article/download/3087/1835).
The downloaded archive contains censored training CSV, test CSV with RUL, original
MATLAB tables, and `Train_Data_Uncensored.mat`. The uncensored values were not read.
Training CSV ID 28 resets from time 157.2 to 0.2 (data-row position 21,196, CSV line 21,197).
Do not sort away or interpolate that discontinuity: compare against the MATLAB
source and documentation, then record an explicit segment/split decision in the
next protocol. The audit only inspected the test header; a preliminary manual
preview also exposed its first row. No test metrics or label-driven choices were made.
Known file identity and time discontinuities are useful tests for MorletDB provenance.

**CNC:** the bundled creator README confirms 18 machining experiments on wax blocks
at Michigan SMART Lab, varying tool condition, feed and clamp pressure. Four visual
inspection labels are blank. The recordings have no explicit timestamp column;
acquisition timing must be established from source documentation before assigning
a sample rate. `Machining_Process` can support stage matching; experiment outcome
columns must not leak into model inputs. This dataset is distinct from NASA milling.

**MetroPT:** the source page describes both 1 Hz logging and 0.1Hz data. Verify actual
timestamps and the dataset version before selecting a window duration. It supplies
failure reports rather than clean per-sample ground truth; availability time and
annotation ambiguity matter for an agent-memory evaluation.

**Do not use [AI4I2020](https://archive.ics.uci.edu/dataset/601/ai4i+2020+predictive+maintenance+dataset)
as primary waveform evidence.** Its creator describes synthetic observations and
constructed failure rules. A high classifier score there would not establish
retrieval value for real archived recordings.

## Proposal at discovery, subsequently tested in WRL3

The following motivated the now-completed [hydraulic study](HYDRAULIC_RESULTS.md).
Its frozen protocol and results supersede this preliminary proposal.

Start with hydraulic cycle diagnosis after mapping contiguous condition runs.
Use an explicit small-label regime, a held-out condition combination, and a fixed
reference budget. Ask whether retrieved historical cycles improve a strong
non-retrieval predictor and whether an agent's cited source intervals actually
support its diagnosis. Separate classification quality, reference relevance and
storage/access cost. For high-rate signals, add the existing Paderborn/PHM evidence
as a separate protocol; do not relabel previously used data as a fresh holdout.

Before commissioning another extension, require positive incremental value on at
least one independently held-out industrial task, with provenance and eligibility
enforced, then reproduce on another asset or condition. This is a proposed evidence
standard, not a claim that current studies have met it.

## Reproduce structural audit

```sh
curl -fL 'https://archive.ics.uci.edu/static/public/447/condition+monitoring+of+hydraulic+systems.zip' -o /tmp/wrl2-hydraulic.zip
curl -fL 'https://www.kaggle.com/api/v1/datasets/download/prognosticshse/preventive-to-predicitve-maintenance' -o /tmp/wrl2-p2p.zip
curl -fL 'https://www.kaggle.com/api/v1/datasets/download/shasun/tool-wear-detection-in-cnc-mill' -o /tmp/wrl2-cnc.zip
/Users/zin/sophia/morletdb/.venv-research/bin/python research/waverag_local/audit_datasets.py /tmp/dataset-audit.json
```

Kaggle default downloads can change versions. Compare archive hashes with the saved
audit; do not silently treat changed bytes as the same dataset. Local archived
copies are retained with the WRL2 inputs.
