-- Disposable feasibility schema. No extension required. No production migration.
CREATE ROLE wrl_reader;
CREATE ROLE wrl_other;
CREATE TABLE episodes (
  tenant name NOT NULL,
  tool integer NOT NULL,
  cut integer NOT NULL,
  label_available_at integer,
  features double precision[] NOT NULL,
  source_sha256 text NOT NULL CHECK (length(source_sha256) = 64),
  source_available boolean NOT NULL DEFAULT true,
  PRIMARY KEY (tenant, tool, cut)
);
ALTER TABLE episodes ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_read ON episodes FOR SELECT USING (tenant = current_user);
GRANT SELECT ON episodes TO wrl_reader, wrl_other;

-- A production implementation also needs immutable revision identifiers, actual
-- timestamps, artifact resolution and tenant/role provisioning. Cut time here is
-- a deliberately explicit simulation clock, NOT a real acquisition timestamp.
