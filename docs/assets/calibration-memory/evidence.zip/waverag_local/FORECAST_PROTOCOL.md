# WRL2: retrieval forecasting and xLSTM comparison

Frozen before fitting or validation/test scoring, 2026-11-23. Exploratory,
controlled-budget experiment, not an exact reproduction of either paper's scores.
Upstream RAFT architecture/retriever are reused; xLSTM-Mixer uses its official
architecture with the vanilla float32 sLSTM backend instead of CUDA.

## Inputs and splits

- ETTh1 SHA256 f18de3ad269cef59bb07b5438d79bb3042d3be49bdeecf01c1cd6d29695ee066.
- ETTh2 SHA256 a3dc2c597b9218c7ce1cd55eb77b283fd459a1d09d753063f944967dd6b9218b.
- ETDataset revision 1d16c8f4f943005d613b5bc962e9eeb06058cf07.
- RAFT revision bfe2320f5d719d1e2a024330de3410b370bbb2a9.
- xLSTM-Mixer revision 730b0531aa9456e498765028f3c22ca3677de42e.
- Seven channels, original hourly values. Train [0,8640), validation [8640,11520),
  test [11520,14400). Fit population mean/std on training rows only; score standardized
  values. Reject nonfinite/constant channels. Ignore later rows, following ETT convention.
- Context L=720, horizon H=96, stride 1. Validation/test context may precede their
  boundaries, but forecast targets must lie wholly inside their own partitions.
- Retrieval gallery contains only complete training context+future pairs. During
  training exclude all pairs whose complete [start,start+L+H) overlaps the query.
  Offline training can use later nonoverlapping training examples. This is not an
  online replay claim. Validation/test gallery stays fixed at training data.

## Models and controls

All trainable models: seeds 0,1,2, Adam lr .001, batch 32, exactly 10 epochs,
cosine lr .001/2*(1+cos(pi*epoch/10)), MSE loss, no weight decay, no clipping,
no early stopping; retain lowest validation-MSE epoch. Identical per-seed training
batch permutations. Include final partial batch. CPU float32, two torch threads.
Do not use test for selection or adjust settings after results. No HPO.

1. NLinear: one shared 720->96 linear map on last-value-centered input.
2. RAFT: official model, periods 4/2/1, top20, temperature .1.
3. RAFT-zero: identical parameter count and initialization, retrieval values zero.
4. RAFT-random: 20 uniformly sampled eligible pairs without replacement at each
   scale, equally weighted. Gallery fixed across model seeds (retrieval seed 20261123).
   This deliberately destroys similarity selection; weighting differs from RAFT.
5. RAFT-shuffled: original similarity weights, but each chosen continuation is
   replaced by an independently sampled eligible training continuation. This
   destroys context-to-future correspondence without introducing overlapping labels.
6. xLSTM-Mixer: upstream FULL model, dimension256, heads8, one block,
   memory tokens2, dropout .25, conv0, backcast true, packing1. Same720 context.
7. xLSTM+retrieval: same xLSTM plus sum of three learned per-scale linear
   projections of RAFT retrieved continuations (compressed repetitions as RAFT).
   Residual projections initially zero. This adds parameters; compare next control.
8. xLSTM+random: identical residual adapter and initialization using random retrieval.

Nontrained: persistence, repeat final24h, repeat final168h. Predictions always use
only the query context. Score all test windows (2,785 per dataset), MSE/MAE across
all seven channels and96 forecast steps. Save per-query errors, checkpoints,
validation histories, all seeds, parameter counts, wall times and process peak RSS.
RSS is cumulative process peak, not isolated model allocation. Record retrieval
precomputation separately. Precomputed retrieval is reused across seeds.

## Decision and interpretation

RAFT gate per dataset: median MSE >=2% lower than RAFT-zero and RAFT-random,
each seed improves over both, and median lower than RAFT-shuffled. Do not conflate
this with outperforming xLSTM. xLSTM augmentation gate: >=2% median MSE improvement
over both plain xLSTM and xLSTM+random, with direction consistent for every seed.
Report differences in paired168-query blocks, not IID sample confidence intervals.
Adjacent windows and weekly blocks remain dependent (96h horizon and720h context).
Two transformers from one dataset family cannot establish fleet generalization.

Published xLSTM ETTh1 settings use512 context, L1 loss and40 epochs with a different
scheduler. Here10 epochs/MSE/shared settings isolate a bounded comparison; it is
not a best-tuned xLSTM leaderboard result. RAFT also uses a different default
learning-rate schedule. Report every deviation, including failed runs.

If a retrieval gate passes, measure reference-store parity/storage on the same
algorithm before database proposals. If neither passes, stop the conditional DB
experiment and report the negative result. Dataset discovery proceeds independently;
new industrial datasets need a new frozen protocol, not opportunistic test selection.

## Preflight

Training-only smoke was already run at L96/H24; xLSTM synthetic32x720x7 forward and
backward passed on CPU (~.22 seconds for three batches). No held-out metrics used.
Before full run test boundary identities, overlap exclusion, source-only scaling,
and reference retrieval parity. Save protocol and harness hashes with results.
