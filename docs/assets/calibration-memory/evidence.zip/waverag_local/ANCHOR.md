# Next anchor: reproduce RAFT on ETTh1 before changing its storage

Decision date: 2026-11-23. Artifact audit and training-only smoke complete.
**No downstream forecasting benefit has been reproduced yet.** This is the next
investigation design, not a positive result, product feature or frozen training protocol.

## Why this anchor

Use **RAFT (Han et al., ICML 2025), ETTh1 multivariate forecasting**, with the original
learned predictor. The paper's Table 8 reports MSE 0.367 for RAFT, 0.379 without retrieval
and 0.382 with random retrieval on ETTh1: approximately 3.2% and 3.9% reductions.
These are modest, attributable comparisons rather than the headline 86% win ratio.
The same table shows a counterexample on Exchange Rate (0.091 with RAFT versus 0.089
without retrieval), so benefit is not universal. Appendix B supplies the ETTh1 horizon-96
settings: lookback 720, learning rate 0.001, 20 references, three periods and temperature
0.1. This gives us a concrete result and configuration to investigate.

Sources: [paper](https://proceedings.mlr.press/v267/han25d.html),
[methods and Tables 6/8](https://arxiv.org/html/2505.04163v1),
[official code](https://github.com/archon159/RAFT).

The dataset is hourly transformer load and oil-temperature data, seven numeric channels.
It is **not high-rate vibration**. Its role is a positive-control research task; a success
would not establish usefulness for machining or a storage advantage for MorletDB.
[Dataset source](https://github.com/zhouhaoyi/ETDataset).

## Verified artifacts

| Artifact | Pinned identity / observation |
|---|---|
| RAFT code | `bfe2320f5d719d1e2a024330de3410b370bbb2a9`, MIT |
| ETDataset repository revision | `1d16c8f4f943005d613b5bc962e9eeb06058cf07` |
| Downloaded ETTh1.csv SHA-256 | `f18de3ad269cef59bb07b5438d79bb3042d3be49bdeecf01c1cd6d29695ee066` |
| TS-RAG code audited | `73ac807789d2e61b8a3dfc8514e3fc947fe185cc` |
| RAG4CTS linked IoTDB branch | `d9b692bcca7e974b0aed74507d2af183c31ed8d1` |

Actual upstream RAFT code inspection:
- `layers/Retrieval.py` materializes training input windows, their future windows and
  multiscale tensors. It computes correlation and weighted continuation retrieval.
- `models/RAFT.py` trains projections over query and retrieved continuation features.
  It hard-codes a CUDA device, although the command-line wrapper detects CPU-only hosts.
- Training retrieval masks overlapping input-plus-target windows. It may use later,
  nonoverlapping training windows: this is offline supervised training, not an online
  historical replay. Validation/test use the training gallery.
- `data_provider/data_loader.py` fits normalization on the training region and uses the
  standard 8640/11520/14400 row boundaries. Reference continuations must remain wholly
  inside the training region; retain explicit interval IDs when reproducing this.
- Upstream shape assertions use tuple syntax and therefore do not enforce their intended
  checks. Our smoke check independently asserts output shape and finite values.

## What ran locally

`anchor_smoke.py` imports the unmodified upstream retrieval and model classes. It parses
only the first 2048 training rows, builds 1929 windows (96 input, 24 output), and queries
32 training examples with overlap exclusion. An independently written NumPy implementation
checks the retrieved multiscale continuations: maximum absolute difference **8.70e-6**,
within the declared 1e-5 tolerance. An unfitted upstream model then completes a CPU
forward pass with finite output shape **32 x 24 x 7**.

This is execution and numerical-feasibility evidence only. No validation/test values were
parsed, no model was fitted, and no forecast-quality score was computed. Dataset hashing
reads all file bytes but does not evaluate held-out data.

The first smoke attempt stopped on a missing `tqdm` import. Installed `tqdm==4.67.1`
under `/tmp/wrl-anchor-deps` only; no project environment changed. Second attempt passed.
CPU adaptation sets the model's device attribute and calls retrieval directly instead
of its multiprocess loader. No upstream files were edited.

## Why the other anchors are secondary

**RAG4CTS:** closest industrial/storage concept, but not our first reproducibility anchor.
The linked branch exists; a complete Git-tree path audit did not identify paths containing
`rag4cts` or `prsov`. This does not prove the implementation is absent under other names.
I have not obtained a public download of the airline measurements. The paper also gives
inconsistent context/horizon settings (12/6 in the main experiment, 6/12 in Appendix A).
Resolve these before claiming reproduction.
[Paper](https://arxiv.org/html/2603.04951v1).

**TS-RAG:** credible follow-on, but more moving parts. `retrieve.py` stores raw arrays,
timestamps, embeddings and metadata in pickle files, and builds a FAISS `IndexFlatL2`.
The supplied zero-shot script expects an external trained mixer checkpoint. Public
[issue 4](https://github.com/UConn-DSIS/TS-RAG/issues/4) requests the missing pretraining-pair
generation workflow for alternative retrieval methods; that is an unresolved reporter
request, not proof the published results are invalid. Prefer the simpler RAFT positive
control before investigating these dependencies.

## Next bounded experiment

Before running: write and commit the complete training protocol and harness; test source
interval identities, source-only scaling and overlap rules on synthetic fixtures.

1. ETTh1, seven channels, input 720, forecast 96, periods 1/2/4, k=20, temperature 0.1,
   learning rate 0.001. Use published split boundaries. Record CPU adaptations and exact
   dependency versions; benchmark one training batch before committing the runtime budget.
2. Compare original RAFT, the paper's linear no-retrieval baseline, same-capacity model
   with retrieval inputs zeroed, random eligible references, and shuffled continuations.
   Include persistence and daily/weekly seasonal-naive forecasts for context.
3. Train controls separately with the same optimization budget. Use seeds 0/1/2, validation
   only for checkpoint selection, and no hyperparameter search on test. Freeze epoch limit,
   batch size, scheduler and stopping policy before the run.
4. Report MSE/MAE and every seed, paired weekly error blocks, peak memory and runtime.
   Preserve failed runs. A small result on one series is not an industrial generalization.
5. Provisional advance rule to freeze with implementation: median MSE at least 2% lower
   than both same-capacity no-retrieval and random retrieval, direction consistent across
   all three seeds; outperform shuffled continuations. Report the original paper baseline
   separately, even if the stricter capacity control fails.

## Storage experiment only after a positive model result

Keep the model and returned reference tensors fixed. Replace materialized overlapping
windows with source recordings plus `(recording, context_start, context_end, future_end,
representation_version)` references. Verify reference identity and tensor parity before
measuring memory, retrieval latency and update cost against the original array path.

Compare an ordinary NumPy/memmap implementation as well as PostgreSQL/MorletDB. Simply
replacing inefficient materialization with slicing may solve the problem without a DB.
Do not substitute MorletDB envelope distance for RAFT correlation during this comparison;
that would change the retrieval algorithm and confound the storage result.

The concrete storage hypothesis is that a persistent archive can serve useful context and
continuation pairs without repeatedly materializing highly overlapping windows, while
preserving provenance and availability. Upstream [RAFT issue 9](https://github.com/archon159/RAFT/issues/9)
reports out-of-memory problems on Traffic/Electricity even with 96 GB allocated. This is
a user's report, not our measurement or evidence that MorletDB solves it.

**Research question:** Can we preserve a reproduced retrieval gain while making its
historical reference store cheaper to maintain and easier to verify?

## Reproduce the smoke check

```sh
git clone https://github.com/archon159/RAFT.git /tmp/waverag-anchor-raft
git -C /tmp/waverag-anchor-raft checkout bfe2320f5d719d1e2a024330de3410b370bbb2a9
curl -fL https://raw.githubusercontent.com/zhouhaoyi/ETDataset/1d16c8f4f943005d613b5bc962e9eeb06058cf07/ETT-small/ETTh1.csv -o /tmp/waverag-anchor-ETTh1.csv
uv pip install --target /tmp/wrl-anchor-deps 'tqdm==4.67.1'
PYTHONPATH=/tmp/wrl-anchor-deps OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  /Users/zin/sophia/morletdb/.venv-research/bin/python \
  research/waverag_local/anchor_smoke.py /tmp/waverag-anchor-raft \
  /tmp/waverag-anchor-ETTh1.csv /tmp/anchor-smoke-reproduction.json
```

See `results/anchor_smoke.json` for the recorded run and numerical-reference selections.
