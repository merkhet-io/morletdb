# WRL1 — separate local Wave-RAG evidence study

Follow-up: [WRL2 forecasting results](FORECAST_RESULTS.md) compare RAFT retrieval,
capacity/random/shuffled controls and xLSTM-Mixer on ETTh1/ETTh2. See the
[frozen forecasting protocol](FORECAST_PROTOCOL.md), [anchor audit](ANCHOR.md) and
[audited industrial/Kaggle dataset shortlist](DATASETS.md). WRL1 results below are
preserved separately. WRL2 large artifacts are in ignored `data/wrl2-20261123/`.

The subsequent [WRL3 hydraulic diagnosis study](HYDRAULIC_RESULTS.md) tests small
label budgets and held-out cooler states, with nearest-neighbour/DTW and fusion
controls. Its [protocol](HYDRAULIC_PROTOCOL.md) was frozen before scoring; full
artifacts are in ignored `data/wrl3-20261123/`.

Read [RESULTS.md](RESULTS.md) for conclusions and limits, [PROTOCOL.md](PROTOCOL.md) for
the frozen choices. No production changes, database migration, publication or PR.

Artifacts: `results/results.json`, `predictions.json`, `manifests.json`, `inputs.json`,
`sql_results.json`, `numerical_audit.json`. The NPZ caches are local under the main
checkout's ignored `data/wrl1-20261123/`; raw signals remain in `data/phm2010/` and are
not copied into this worktree or committed. Preserve the supplied dataset terms.

Environment used: existing `.venv-research` (Python 3.12, NumPy 2.2.6, SciPy 1.16.3,
scikit-learn 1.7.2); `.venv-seismic` for NumPy and psycopg 3.2.10. Exact Python version
is in results. PostgreSQL 17.7 from Homebrew. No package changes were required.

From this worktree, with `SOURCE` set to the main checkout, and a NEW `OUT` directory:

```sh
SOURCE=/Users/zin/sophia/morletdb
OUT=/tmp/wrl1-reproduction
export OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1
"$SOURCE/.venv-research/bin/python" -m unittest discover -s research/waverag_local
"$SOURCE/.venv-research/bin/python" research/waverag_local/run.py prepare "$OUT" \
  --root "$SOURCE/data/phm2010" \
  --hashes "$SOURCE/evaluation/context/c8/results/phm_inputs_SHA256SUMS"
"$SOURCE/.venv-research/bin/python" research/waverag_local/run.py evaluate "$OUT"
"$SOURCE/.venv-research/bin/python" research/waverag_local/audit_numerics.py "$OUT"
# Against a fresh disposable database ONLY (creates tables and roles):
"$SOURCE/.venv-seismic/bin/python" research/waverag_local/check_sql.py "$OUT" "$WRL_DSN"
```

Evaluation refuses to overwrite `results.json`. Reproduction is not additional
confirmation evidence. The numerical audit avoids BLAS matmul to investigate observed
Accelerate warnings without changing the original experiment.

The study's disposable server used `/tmp/morlet-wrl1-pg`, localhost port 28983,
database `postgres`; it was stopped after the checks. No existing server was modified.
