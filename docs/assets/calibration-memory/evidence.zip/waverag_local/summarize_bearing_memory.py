"""Summarize all WRL5 holdouts and budgets, without selecting favourable outcomes."""
import argparse
import json
from pathlib import Path
import numpy as np
from bearing_memory import METHODS,BUDGETS
from hydraulic import save_json


def main(out,destination):
    cases=[json.loads(p.read_text()) for p in sorted(out.glob('target*.json'))];assert len(cases)==10
    means={};targets={};diagnostics={};load_scores={}
    for n in BUDGETS:
        bi=BUDGETS.index(n)
        means[n]={m:float(np.mean([c['results'][bi]['metrics'][m]['macro_f1'] for c in cases])) for m in METHODS}
        targets[n]={str(t):{m:float(np.mean([c['results'][bi]['metrics'][m]['macro_f1'] for c in cases if c['target_type']==t])) for m in METHODS} for t in (6207,6208)}
        diagnostics[n]={k:float(np.mean([c['results'][bi][k] for c in cases])) for k in ('purity','random_purity','target_support_share','retrieval_ms_per_window')}
        load_scores[n]={str(t):{str(load):{m:float(np.mean([c['results'][bi]['per_load'][str(load)][m]['macro_f1'] for c in cases if c['target_type']==t])) for m in METHODS} for load in (200,400)} for t in (6207,6208)}
    comparators=[m for m in METHODS if m!='embedding-knn']
    differences={m:means[8]['embedding-knn']-means[8][m] for m in comparators}
    primary_pass=all(d>=.03 for d in differences.values()) and all(
        targets[8][str(t)]['embedding-knn']>targets[8][str(t)][m] for t in (6207,6208)
        for m in ('source-encoder','adapted-logistic','adapted-RF','balanced-RF','balanced-SVM'))
    disagreement={}
    for method in comparators:
        wins=losses=equal=0
        for c in cases:
            mm=c['results'][-1]['metrics'];truth=np.array(mm['embedding-knn']['truth'])
            mine=np.array(mm['embedding-knn']['predicted'])==truth;other=np.array(mm[method]['predicted'])==truth
            wins+=int((mine&~other).sum());losses+=int((~mine&other).sum());equal+=int((mine==other).sum())
        disagreement[method]={'retrieval_correct_other_wrong':wins,'retrieval_wrong_other_correct':losses,'same_correctness':equal,'recording_seed_observations':100}
    selection=json.loads((out/'selection.json').read_text())
    source_validation={f:float(np.mean([r['validation']['macro_f1'] for r in selection['development'][f]])) for f in ('ce','contrastive')}
    source_validation['rf']=selection['baselines']['rf']['macro_f1']
    for method in ('logistic','svm'):
        source_validation[method]=next(r['validation']['macro_f1'] for r in selection['baselines'][method] if r['C']==selection[method+'_C'])
    summary={'means':means,'per_target':targets,'per_target_load':load_scores,'diagnostics':diagnostics,
        'n8_differences':differences,'primary_advance_passed':bool(primary_pass),'paired_disagreements':disagreement,
        'source_validation':source_validation,'selected_family':selection['family'],'selected_epoch_counts':selection['epochs'],
        'logistic_C':selection['logistic_C'],'svm_C':selection['svm_C']}
    destination.mkdir(parents=True,exist_ok=True);save_json(destination/'bearing_summary.json',summary)
    lines=['# WRL5 complete results','','Recording macro-F1; mean across five seeds and two target bearing types.',
           'Support windows are correlated half-second excerpts from ONE zero-load acquisition per class.','',
           '| Method | 0 sec/class | 0.5 sec/class | 1 sec/class | 4 sec/class |','|---|---:|---:|---:|---:|']
    for m in METHODS:lines.append('| '+m+' | '+' | '.join(f'{means[n][m]:.4f}' for n in BUDGETS)+' |')
    lines.extend(['',f'Primary advance criterion passed: **{primary_pass}**.','',
        '## At four seconds per class, by target bearing type','','| Method | 6207 | 6208 |','|---|---:|---:|'])
    for m in METHODS:lines.append('| '+m+' | '+' | '.join(f'{targets[8][str(t)][m]:.4f}' for t in (6207,6208))+' |')
    lines.extend(['','## Source-only validation','','| Candidate | Recording macro-F1 |','|---|---:|'])
    for m,v in source_validation.items():lines.append(f'| {m} | {v:.4f} |')
    lines.append('');lines.append(f"Selected encoder: {selection['family']}; epochs: {selection['epochs']}; logistic C={selection['logistic_C']}; SVM C={selection['svm_C']}.")
    (destination/'bearing_table.md').write_text('\n'.join(lines).rstrip()+'\n');print('\n'.join(lines))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--destination',type=Path,required=True)
    args=ap.parse_args();main(args.out,args.destination)
