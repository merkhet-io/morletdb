"""WRL5 independent numerical, source, eligibility and checkpoint audit."""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
import torch
from bearing_memory import Encoder,METHODS,BUDGETS,RATE,WINDOW
from hydraulic import sha,save_json


def f1(y,pred):
    result=[]
    for c in range(5):
        tp=np.sum((y==c)&(pred==c));fp=np.sum((y!=c)&(pred==c));fn=np.sum((y==c)&(pred!=c))
        den=2*tp+fp+fn;result.append(2*tp/den if den else 0.)
    return float(np.mean(result))


def independent_psd(v):
    n=2048;h=.5-.5*np.cos(2*np.pi*np.arange(n)/n)
    frames=np.stack([v[start:start+n] for start in range(0,len(v)-n+1,1024)])
    frames=frames-frames.mean(1,keepdims=True)
    power=abs(np.fft.rfft(frames*h,axis=1))**2/(RATE*np.sum(h*h))
    power[:,1:-1]*=2
    return power.mean(0)


def independent_features(raw):
    centered=raw-np.mean(raw);power=independent_psd(centered)
    ft=np.fft.fft(centered);mult=np.zeros(len(raw));mult[0]=mult[len(raw)//2]=1;mult[1:len(raw)//2]=2
    env=abs(np.fft.ifft(ft*mult));ep=independent_psd(env-env.mean())[:129]
    def bands(v,n):
        boundaries=[int(i*len(v)/n) for i in range(n+1)]
        return [np.log10(max(sum(v[l:r])*25.,1e-20)) for l,r in zip(boundaries[:-1],boundaries[1:])]
    variance=np.mean(centered**2);sd=np.sqrt(variance);rms=np.sqrt(np.mean(raw**2));peak=np.max(abs(raw))
    standardized=centered/max(sd,1e-12)
    st=[np.mean(raw),np.log1p(sd),np.log1p(rms),np.log1p(peak),np.log1p(peak/max(rms,1e-12)),
        np.log1p(np.mean(abs(raw))),np.mean(standardized**3),np.log1p(np.mean(standardized**4))]
    return np.array(bands(power,128)+bands(ep,64)+st)


def main(out):
    torch.set_num_threads(2);a=np.load(out/'features.npz');run=json.loads((out/'run.json').read_text())
    root=Path(__file__).parent
    assert sha(out/'features.npz')==run['input_sha256']
    assert sha(root/'bearing_memory.py')==run['harness_sha256']
    assert sha(root/'BEARING_PROTOCOL.md')==run['protocol_sha256']
    records=json.loads((out/'recordings.json').read_text());sourcecheck=[]
    for rec in records:
        p=out/'raw'/rec['filename'];assert sha(p)==rec['sha256']
        raw=loadmat(p)['data'].reshape(-1);ids=np.flatnonzero(a['record']==rec['recording_id']);error=0.
        assert len(ids)==len(raw)//WINDOW
        for i in ids:
            left,right=a['bounds'][i];assert right-left==WINDOW and left>=0 and right<=len(raw)
            feat=independent_features(raw[left:right]);diff=float(np.max(abs(feat-a['x'][i])));error=max(error,diff)
            np.testing.assert_allclose(feat,a['x'][i],rtol=1e-10,atol=1e-10)
        sourcecheck.append({'file':rec['filename'],'windows':len(ids),'max_feature_abs_error':error})
    print('raw feature audit complete',flush=True)
    selection=json.loads((out/'selection.json').read_text());devtrain=np.flatnonzero(np.isin(a['types'],[6204,6205]));val=np.flatnonzero(a['types']==6206)
    mu=a['x'][devtrain].mean(0);sd=a['x'][devtrain].std(0);sd=np.where(sd>=1e-6,sd,1.)
    devx=(a['x']-mu)/sd;devchecks=[]
    for family in ('ce','contrastive'):
        for row in selection['development'][family]:
            assert row['epoch_count']==1+int(np.argmin(np.array(row['losses'])[:,1]))
            model=Encoder();model.load_state_dict(torch.load(out/f"dev-{family}-s{row['seed']}.pt",weights_only=True));model.eval()
            with torch.no_grad():p=model(torch.tensor(devx[val],dtype=torch.float32)).softmax(1).numpy()
            ub=np.unique(a['record'][val]);bp=np.array([p[a['record'][val]==b].mean(0) for b in ub]);truth=np.array([a['y'][val][a['record'][val]==b][0] for b in ub])
            np.testing.assert_array_equal(bp,np.array(row['validation']['probabilities'],dtype='f4'))
            assert abs(f1(truth,bp.argmax(1))-row['validation']['macro_f1'])<1e-14
            devchecks.append({'family':family,'seed':row['seed'],'recording_metrics_exact':True})
    chosen=max(('ce','contrastive'),key=lambda f:np.mean([r['validation']['macro_f1'] for r in selection['development'][f]]))
    assert selection['family']==chosen
    source=np.flatnonzero(np.isin(a['types'],[6204,6205,6206]));mu=a['x'][source].mean(0);sd=a['x'][source].std(0);sd=np.where(sd>=1e-6,sd,1.)
    x=(a['x']-mu)/sd;cases=[]
    for path in sorted(out.glob('target*.json')):
        result=json.loads(path.read_text());ar=np.load(path.with_suffix('.npz'));seed=result['seed'];target=result['target_type']
        q=ar['query_ids'];expectedq=np.flatnonzero((a['types']==target)&np.isin(a['loads'],[200,400]))
        np.testing.assert_array_equal(q,expectedq);np.testing.assert_array_equal(ar['source_ids'],source)
        np.testing.assert_array_equal(ar['mean'],mu);np.testing.assert_array_equal(ar['std'],sd)
        model=Encoder();model.load_state_dict(torch.load(out/f'final-s{seed}.pt',weights_only=True));model.eval()
        with torch.no_grad():z=model.embed(torch.tensor(x,dtype=torch.float32)).numpy();base=model(torch.tensor(x,dtype=torch.float32)).softmax(1).numpy()
        np.testing.assert_array_equal(z,ar['embeddings']);np.testing.assert_array_equal(base,ar['base_probabilities'])
        assert len(result['losses'])==selection['epochs'][seed]
        maxlog=0.;maxgrad=0.;metrics=0;maxforest=0.;maxsvm=0.
        for bi,n in enumerate(BUDGETS):
            support=np.concatenate([np.flatnonzero((a['types']==target)&(a['loads']==0)&(a['y']==c))[:n] for c in range(5)])
            g=ar[f'n{n}_gallery'];np.testing.assert_array_equal(g,np.r_[source,support])
            assert set(a['record'][g]).isdisjoint(a['record'][q])
            for representation,key in [(z,'nearest'),(x,'spectral')]:
                # Independent coordinate accumulation and stable tuple ordering.
                d=np.zeros((len(q),len(g)))
                for dim in range(representation.shape[1]):d+=(representation[q,dim,None].astype(float)-representation[g,dim][None,:].astype(float))**2
                expected=np.array([[g[j] for j in sorted(range(len(g)),key=lambda j:(row[j],g[j]))[:5]] for row in d])
                np.testing.assert_array_equal(expected,ar[f'n{n}_{key}_ids'])
            ids=ar[f'n{n}_nearest_ids'];rids=ar[f'n{n}_random_ids'];assert np.isin(rids,g).all()
            yy=a['y'];shuf=dict(zip(g,ar[f'n{n}_shuffled_labels']))
            for method,refs,lookup in [('embedding-knn',ids,dict(enumerate(yy))),('spectral-knn',ar[f'n{n}_spectral_ids'],dict(enumerate(yy))),
                ('random-knn',rids,dict(enumerate(yy))),('shuffled-knn',ids,shuf)]:
                pred=np.array([[sum(lookup[r]==c for r in row)/5 for c in range(5)] for row in refs])
                np.testing.assert_array_equal(pred,ar['probabilities'][bi,METHODS.index(method)])
            coef=ar[f'n{n}_logistic_coef'];intercept=ar[f'n{n}_logistic_intercept']
            logits=np.einsum('ij,kj->ik',x[q],coef,optimize=False)+intercept;ep=np.exp(logits-logits.max(1,keepdims=True));pred=ep/ep.sum(1,keepdims=True)
            error=float(abs(pred-ar['probabilities'][bi,METHODS.index('adapted-logistic')]).max());maxlog=max(maxlog,error);assert error<1e-10
            tl=np.einsum('ij,kj->ik',x[g],coef,optimize=False)+intercept;ep=np.exp(tl-tl.max(1,keepdims=True));res=ep/ep.sum(1,keepdims=True)-np.eye(5)[yy[g]]
            grad=np.einsum('ik,ij->kj',res,x[g],optimize=False)/len(g)+coef/(selection['logistic_C']*len(g))
            maxgrad=max(maxgrad,float(abs(grad).max()),float(abs(res.mean(0)).max()))
            weights=np.ones(len(g));weights[len(source):]=len(source)/len(support) if len(support) else 1.
            for method,weight in [('adapted-RF',None),('balanced-RF',weights)]:
                modelrf=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,n_jobs=1,random_state=seed).fit(x[g],yy[g],sample_weight=weight)
                error=float(abs(modelrf.predict_proba(x[q])-ar['probabilities'][bi,METHODS.index(method)]).max());maxforest=max(maxforest,error);assert error==0
            svm=SVC(C=selection['svm_C'],gamma='scale').fit(x[g],yy[g],sample_weight=weights)
            logits=svm.decision_function(x[q]);ep=np.exp(logits-logits.max(1,keepdims=True));pred=ep/ep.sum(1,keepdims=True)
            error=float(abs(pred-ar['probabilities'][bi,METHODS.index('balanced-SVM')]).max());maxsvm=max(maxsvm,error);assert error==0
            for mi,method in enumerate(METHODS):
                prob=ar['probabilities'][bi,mi]
                if method=='source-encoder':prob=prob.astype('f4')
                ub=np.unique(a['record'][q]);bp=np.array([prob[a['record'][q]==b].mean(0) for b in ub]);truth=np.array([yy[q][a['record'][q]==b][0] for b in ub])
                expected=result['results'][bi]['metrics'][method]
                np.testing.assert_array_equal(bp,np.array(expected['probabilities'],dtype=bp.dtype))
                assert abs(f1(truth,bp.argmax(1))-expected['macro_f1'])<1e-14
                for load in (200,400):
                    ix=np.array([records[b]['load_watts']==load for b in ub])
                    assert abs(f1(truth[ix],bp[ix].argmax(1))-result['results'][bi]['per_load'][str(load)][method]['macro_f1'])<1e-14
                metrics+=1
        cases.append({'case':path.stem,'metric_sets':metrics,'checkpoints_exact':True,'rankings_exact':True,
            'logistic_max_abs_error':maxlog,'logistic_max_gradient':maxgrad,'forest_max_error':maxforest,'svm_max_error':maxsvm})
        print('audited',path.stem,flush=True)
    assert len(cases)==10
    save_json(out/'audit.json',{'source_checks':sourcecheck,'development_checks':devchecks,'cases':cases,
        'frozen_files_match':True,'source_windows':len(a['x'])})

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();main(args.out)
