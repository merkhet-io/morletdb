# WRL1: useful local feedback, no demonstrated benefit from similarity selection

2026-11-23. **Exploratory, local, no product change.** Protocol and numerical harness
frozen at `1bd93e5`; SQL harness recorded at `e430721` before database evaluation.
The experiment ran once, without tuning after evaluation. Machine-readable evidence
is in `results/`, including every prediction and reference manifest.

## Decision

**Do not build a separate PostgreSQL extension on this evidence.** Ordinary PostgreSQL
reproduced the measured reference-selection contract. Similarity-selected references
did not improve wear estimation over strong simple alternatives. A modular reference
workflow inside MorletDB remains possible, but this experiment does not establish a
reason to expand it into a new product or to promise model-quality gains.

This is not a rejection of all Wave-RAG: there is no language generator here, and we
did not test neural consumption of retrieved raw waveforms, few-shot foundation models,
DTW, rare-fault diagnosis, or engineering investigation time.

## Experiment

PHM 2010: 945 cuts from labelled cutters c1, c4 and c6, seven waveform channels per cut.
All 945 source files matched the pre-existing C8 SHA-256 manifest. Label-file hashes
and source identities are retained in `results/inputs.json`.

Hold out each cutter in turn; train a ridge model on the other two. Predict mean
three-flute wear for target cuts 31..315: **855 predictions, 285 per cutter**. Reveal
one local wear label every ten cuts, only after that cut completes. These labels
are a simulated feedback schedule over the published measurements, not a demonstrated
automatic online measurement facility. Source cutters are assumed historical.

The similarity arm retrieves up to five eligible local cuts using standardized waveform
statistics and Welch band powers, then corrects the frozen model with their observed
prediction residuals. Comparator arms receive the same eligible local labels.

## Model results

Mean absolute error in micrometres; lower is better. Aggregate is the equal-cutter mean.

| Method | c1 | c4 | c6 | Mean MAE |
|---|---:|---:|---:|---:|
| Frozen source signal model | 9.244 | 10.640 | 119.744 | 46.543 |
| Source model using cut index and its square | 12.505 | 18.281 | 27.154 | 19.314 |
| **Latest available measured wear** | **1.688** | **2.614** | **2.553** | **2.285** |
| Correction from five recent observations | 4.473 | 6.237 | 47.040 | 19.250 |
| **Correction from five similar observations** | **4.627** | **6.155** | **46.981** | **19.254** |
| Correction from random eligible observations (five-seed mean) | 6.989 | 8.609 | 87.081 | 34.227 |
| Extrapolated recent residual trend | 3.273 | 3.184 | 20.141 | 8.866 |
| Ridge refitted using local feedback | 3.160 | 4.242 | 4.634 | 4.012 |

The frozen rule required at least 10% lower mean MAE against every listed comparator
and improvement on at least two cutters against each. **Not supported.**

Local feedback helps relative to the frozen source model, especially on c6, where it
transfers poorly. But similarity correction and simple recency correction are virtually
identical, and both lose badly to the latest wear observation. This does not attribute
the improvement to waveform retrieval. Local refitting is also far better than the
selected retrieval rule, although it still loses to the latest observation.

Do not interpret the 855 predictions as independent trials. There are only three
independent cutters. No window-level confidence intervals or significance claims are
reported. These data were already consumed in earlier repository studies.

## Ordinary PostgreSQL feasibility

PostgreSQL 17.7, disposable localhost instance, no extensions. Arrays store derived
features; ordinary tables store source hashes and simulated label-availability times.

- **855/855** reference lists matched Python in IDs and order.
- Maximum absolute distance difference: **5.69e-14**.
- Synthetic checks passed: late labels excluded, deterministic distance ties,
  incompatible feature dimensions excluded, missing source explicitly reported,
  direct SELECT isolation for two non-owner roles, writes denied to the reader,
  and rollback preserving source-availability state.
- Observed local query times: p50 **0.54 ms**, p95 **0.81 ms**. These concern a tiny
  gallery (at most 31 eligible reference episodes), not archive-scale performance.

This establishes only that the selection slice needs no native extension. It does not
implement general versioned annotations, arbitrary tenant roles, object storage,
raw-sample ingestion/readback, automatic retention reconciliation, persistent model
serving, or a production security design. MorletDB was not benchmarked here; there is
no measured storage, ingestion or implementation-cost comparison against MorletDB.

## Numerical validation and deviations

Apple Accelerate emitted divide/overflow/invalid warnings during scikit-learn matrix
products. The run completed and original output was preserved. A **post-run audit**
independently reconstructed every prediction using explicit einsum contractions,
an independent positive-definite ridge solve and a closed-form residual trend.
All reconstructed predictions were finite; all agreed within **5.26e-11 micrometres**
(tolerance 1e-6). `audit_numerics.py` is an added validation step, not a retuned arm or
second evaluation. Original results were not replaced. No other protocol deviations.

## Implications and limits

1. A new extension is not justified by this small selection workload.
2. Integrate any next pilot with existing MorletDB/SQL/Python facilities; keep boundaries
   modular, but do not invent a second storage engine.
3. Frequent measured wear makes persistence very strong. This scenario does not settle
   commissioning with only a handful of early labels, delayed feedback, abrupt faults,
   or qualitative engineering case retrieval.
4. Large c6 source errors show the difficulty of transfer, not proof that more elaborate
   retrieval solves it. Try a different task only with an explicit customer need and a
   new frozen protocol, not to search these same data for a favorable result.
5. Before promising waveform context gains, separately establish whether retrieved
   measurements add value beyond their associated labels, operating context and recency.

**Enough evidence for the current architecture decision; insufficient evidence to reject
or validate Wave-RAG as an entire product category.**
