"""WRL1 frozen local experiment. No database or production mutations.

Run with OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
from pathlib import Path
import platform
import time

import numpy as np
import scipy
from scipy.signal import welch
import sklearn
from sklearn.linear_model import Ridge

TOOLS = (1, 4, 6)
SEEDS = (7, 17, 27, 37, 47)
VERSION = "wrl1-welch8-stats5-v1"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n")


def eligible(cuts, query):
    return np.flatnonzero((cuts % 10 == 0) & (cuts < query))


def nearest(features, cuts, available, query, k=5):
    distances = np.sqrt(np.sum((features[available] - query) ** 2, axis=1))
    order = np.lexsort((cuts[available], distances))[:k]
    return available[order], distances[order]


def corrected(prediction, predictions_at_refs, observed):
    return max(0.0, float(prediction + np.mean(observed - predictions_at_refs)))


def extract_one(task):
    root, tool, cut, expected = task
    rel = f"c{tool}/c{tool}/c_{tool}_{cut:03d}.csv"
    blob = (root / rel).read_bytes()
    actual = digest(blob)
    if expected[rel] != actual:
        raise ValueError(f"Hash mismatch: {rel}")
    x = np.loadtxt(io.BytesIO(blob), delimiter=",")
    if x.ndim != 2 or x.shape[1] != 7 or not np.isfinite(x).all():
        raise ValueError(f"Invalid recording: {rel}")
    mean = x.mean(axis=0)
    centered = x - mean
    var = (centered ** 2).mean(axis=0)
    rms = np.sqrt((x ** 2).mean(axis=0))
    peak = np.max(np.abs(x), axis=0)
    crest = np.divide(peak, rms, out=np.zeros(7), where=rms != 0)
    kurt = np.divide((centered ** 4).mean(axis=0), var ** 2,
                     out=np.zeros(7), where=var != 0)
    freq, power = welch(x, fs=50000, nperseg=2048, axis=0)
    bands = np.minimum((freq / 25000 * 8).astype(int), 7)
    powers = np.array([power[bands == b].sum(axis=0) * (freq[1] - freq[0])
                       for b in range(8)])
    nonnegative = np.vstack([np.sqrt(var), rms, crest, kurt, powers])
    feat = np.vstack([mean, np.log1p(nonnegative)]).T.ravel()
    return feat, {"tool": tool, "cut": cut, "path": rel, "sha256": actual,
                  "samples": len(x), "channels": 7}


def prepare(root, hashes, out):
    expected = {}
    for line in hashes.read_text().splitlines():
        h, rel = line.split(maxsplit=1)
        # Existing C8 manifest may use a source-root prefix.
        parts = rel.strip().split("/")
        expected["/".join(parts[-3:])] = h
    tasks = [(root, t, c, expected) for t in TOOLS for c in range(1, 316)]
    features, records = [], []
    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=3) as pool:
        for i, (f, rec) in enumerate(pool.map(extract_one, tasks), 1):
            features.append(f)
            records.append(rec)
            if i % 50 == 0:
                print(f"Extracted {i}/945", flush=True)
    labels, label_hashes = [], {}
    for t in TOOLS:
        blob = (root / f"c{t}/c{t}_wear.csv").read_bytes()
        label_hashes[f"c{t}"] = digest(blob)
        a = np.loadtxt(io.BytesIO(blob), delimiter=",", skiprows=1)
        if a.shape != (315, 4) or not np.array_equal(a[:, 0], np.arange(1, 316)):
            raise ValueError("Unexpected label layout")
        labels.extend(a[:, 1:].mean(axis=1))
    np.savez(out / "features.npz", X=np.asarray(features), y=np.array(labels),
             tool=np.array([r["tool"] for r in records]),
             cut=np.array([r["cut"] for r in records]))
    save(out / "inputs.json", {"records": records, "label_hashes": label_hashes,
                              "feature_version": VERSION,
                              "extraction_seconds": time.perf_counter() - start})


def evaluate(out):
    if (out / "results.json").exists():
        raise RuntimeError("Refusing to overwrite evaluated results")
    data = np.load(out / "features.npz", allow_pickle=False)
    X, y, tools, cuts = (data[k] for k in ("X", "y", "tool", "cut"))
    rows, manifests, folds = [], [], []
    for tool in TOOLS:
        tr, te = tools != tool, tools == tool
        mu, sd = X[tr].mean(0), np.maximum(X[tr].std(0), 1e-8)
        a, b = (X[tr] - mu) / sd, (X[te] - mu) / sd
        yt, ct = y[te], cuts[te]
        model = Ridge(alpha=10).fit(a, y[tr])
        source = model.predict(b)
        model_id = digest(model.coef_.tobytes() + np.asarray(model.intercept_).tobytes()
                          + mu.tobytes() + sd.tobytes())
        cx = np.c_[cuts, cuts ** 2].astype(float)
        cm, cs = cx[tr].mean(0), cx[tr].std(0)
        cutpred = Ridge(alpha=10).fit((cx[tr]-cm)/cs, y[tr]).predict((cx[te]-cm)/cs)
        folds.append({"tool": tool, "model_id": model_id,
                      "source_tools": [t for t in TOOLS if t != tool]})
        # Preserve the actual standardized inputs used by the SQL feasibility check.
        np.savez(out / f"fold_{tool}.npz", X=b, cut=ct)
        for i in np.flatnonzero(ct >= 31):
            avail = eligible(ct, ct[i])
            recent = avail[-5:]
            near, distances = nearest(b, ct, avail, b[i])
            p = {"source_ridge": max(0., float(source[i])),
                 "cut_ridge": max(0., float(cutpred[i])),
                 "latest_wear": float(yt[avail[-1]])}
            for name, refs in (("recent_residual", recent), ("similar_residual", near)):
                p[name] = corrected(source[i], source[refs], yt[refs])
            for seed in SEEDS:
                rng = np.random.default_rng(np.random.SeedSequence([seed, tool, int(ct[i])]))
                refs = rng.choice(avail, size=min(5, len(avail)), replace=False)
                p[f"random_{seed}"] = corrected(source[i], source[refs], yt[refs])
            slope, intercept = np.polyfit(ct[recent], yt[recent] - source[recent], 1)
            p["local_trend"] = max(0., float(source[i] + slope * ct[i] + intercept))
            fitX = np.vstack([a, b[avail]])
            fity = np.r_[y[tr], yt[avail]]
            weights = np.r_[np.ones(len(a)), np.full(len(avail), len(a)/len(avail))]
            p["refit_ridge"] = max(0., float(Ridge(alpha=10).fit(
                fitX, fity, sample_weight=weights).predict(b[i:i+1])[0]))
            rows.append({"tool": tool, "cut": int(ct[i]), "actual": float(yt[i]),
                         "predictions": p})
            manifests.append({"tool": tool, "query_cut": int(ct[i]),
                              "available_label_cuts": ct[avail].tolist(),
                              "reference_cuts": ct[near].tolist(),
                              "distances": distances.tolist(), "model_id": model_id,
                              "feature_version": VERSION})
        print(f"Evaluated held-out cutter {tool}", flush=True)
    metrics = {}
    for arm in rows[0]["predictions"]:
        per = {}
        for t in TOOLS:
            errors = np.array([r["predictions"][arm]-r["actual"] for r in rows if r["tool"] == t])
            per[str(t)] = {"mae": float(np.abs(errors).mean()),
                           "rmse": float(np.sqrt(np.mean(errors**2)))}
        metrics[arm] = {"per_tool": per, "mean_mae": float(np.mean([p["mae"] for p in per.values()]))}
    random = [metrics[f"random_{s}"] for s in SEEDS]
    metrics["random_residual"] = {"per_tool": {str(t): {
        k: float(np.mean([r["per_tool"][str(t)][k] for r in random])) for k in ("mae", "rmse")}
        for t in TOOLS}, "mean_mae": float(np.mean([r["mean_mae"] for r in random])),
        "seed_mean_mae_range": [min(r["mean_mae"] for r in random), max(r["mean_mae"] for r in random)]}
    comparisons = {}
    primary = metrics["similar_residual"]
    for arm in ("source_ridge", "cut_ridge", "latest_wear", "recent_residual",
                "random_residual", "local_trend", "refit_ridge"):
        other = metrics[arm]
        ratio = primary["mean_mae"] / other["mean_mae"]
        wins = sum(primary["per_tool"][str(t)]["mae"] < other["per_tool"][str(t)]["mae"] for t in TOOLS)
        comparisons[arm] = {"mae_ratio": ratio, "tools_better": wins,
                            "passes": ratio <= .9 and wins >= 2}
    save(out / "predictions.json", rows)
    save(out / "manifests.json", manifests)
    save(out / "results.json", {"exploratory": True, "queries": len(rows), "folds": folds,
         "metrics": metrics, "comparisons": comparisons,
         "decision": "promising" if all(c["passes"] for c in comparisons.values()) else "not supported",
         "environment": {"python": platform.python_version(), "numpy": np.__version__,
                         "scipy": scipy.__version__, "sklearn": sklearn.__version__},
         "harness_sha256": digest(Path(__file__).read_bytes()),
         "protocol_sha256": digest(Path(__file__).with_name("PROTOCOL.md").read_bytes()),
         "feature_archive_sha256": digest((out / "features.npz").read_bytes())})


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=("prepare", "evaluate"))
    p.add_argument("out", type=Path)
    p.add_argument("--root", type=Path)
    p.add_argument("--hashes", type=Path)
    args = p.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if args.stage == "prepare":
        prepare(args.root, args.hashes, args.out)
    else:
        evaluate(args.out)
