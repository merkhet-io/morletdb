"""Run against a disposable PostgreSQL database, never a user's existing database."""
import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import psycopg


def main():
    p = argparse.ArgumentParser()
    p.add_argument("out", type=Path)
    p.add_argument("dsn")
    args = p.parse_args()
    base = Path(__file__).parent
    query = (base / "select.sql").read_text()
    data = json.loads((args.out / "inputs.json").read_text())
    hashes = {(r["tool"], r["cut"]): r["sha256"] for r in data["records"]}
    expected = json.loads((args.out / "manifests.json").read_text())
    with psycopg.connect(args.dsn, autocommit=True) as conn:
        conn.execute((base / "schema.sql").read_text())
        rows, folds = [], {}
        for tool in (1, 4, 6):
            a = np.load(args.out / f"fold_{tool}.npz")
            folds[tool] = a["X"]
            for cut, x in zip(a["cut"], a["X"]):
                cut = int(cut)
                rows.append(("wrl_reader", tool, cut, cut+1 if cut % 10 == 0 else None,
                             x.tolist(), hashes[(tool, cut)], True))
        # Synthetic fixtures: known 3-4-5 distances, late label, other tenant,
        # dimension mismatch and a missing underlying artifact.
        rows.extend([
            ("wrl_reader", 99, 10, 11, [3., 4.], "a"*64, True),
            ("wrl_reader", 99, 20, 21, [0., 5.], "b"*64, False),
            ("wrl_reader", 99, 30, 90, [0., 0.], "c"*64, True),
            ("wrl_other", 99, 1, 2, [0., 0.], "d"*64, True),
            ("wrl_reader", 99, 2, 3, [0.], "e"*64, True),
        ])
        with conn.cursor() as cur:
            cur.executemany("INSERT INTO episodes VALUES (%s,%s,%s,%s,%s,%s,%s)", rows)
        version = conn.execute("SELECT version()").fetchone()[0]
        conn.execute("SET ROLE wrl_reader")
        fixture = conn.execute(query, ([0., 0.], 99, 50, 2)).fetchall()
        assert [r[0] for r in fixture] == [10, 20], fixture
        assert [r[1] for r in fixture] == [5., 5.]
        assert fixture[1][3] == "missing_source"
        assert conn.execute("SELECT count(*) FROM episodes WHERE tenant='wrl_other'").fetchone()[0] == 0
        try:
            conn.execute("UPDATE episodes SET source_available=false")
        except psycopg.errors.InsufficientPrivilege:
            write_denied = True
        else:
            raise AssertionError("Read-only role could update episodes")
        matches, max_error, elapsed = 0, 0., []
        for row in expected:
            tool, cut = row["tool"], row["query_cut"]
            x = folds[tool][cut-1].tolist()
            start = time.perf_counter()
            result = conn.execute(query, (x, tool, cut, len(x))).fetchall()
            elapsed.append((time.perf_counter()-start)*1000)
            assert [r[0] for r in result] == row["reference_cuts"], (tool, cut)
            err = float(np.max(np.abs(np.array([r[1] for r in result])-row["distances"])))
            assert err < 1e-9, err
            assert all(r[2] == hashes[(tool, r[0])] for r in result)
            max_error = max(max_error, err)
            matches += 1
        conn.execute("RESET ROLE")
        conn.execute("SET ROLE wrl_other")
        assert conn.execute("SELECT count(*) FROM episodes").fetchone()[0] == 1
        conn.execute("RESET ROLE")
        # Transaction rollback must not silently change the source-availability manifest.
        with conn.transaction(force_rollback=True):
            conn.execute("UPDATE episodes SET source_available=false WHERE tool=1 AND cut=10")
        assert conn.execute("SELECT source_available FROM episodes WHERE tool=1 AND cut=10").fetchone()[0]
        result = {"postgres": version, "extensions_required": [], "real_queries_checked": matches,
                  "max_absolute_distance_error": max_error,
                  "synthetic_checks": {"late_label_excluded": True, "tie_order": True,
                    "dimension_mismatch_excluded": True, "missing_source_explicit": True,
                    "nonowner_rls_both_roles": True, "write_denied": write_denied,
                    "rollback_preserves_source_availability": True},
                  "observed_local_ms": {"p50": float(np.median(elapsed)),
                                        "p95": float(np.percentile(elapsed, 95))},
                  "timing_scope": "Small local feasibility run; not a throughput or comparative benchmark",
                  "sql_sha256": hashlib.sha256(query.encode()).hexdigest()}
        (args.out / "sql_results.json").write_text(json.dumps(result, indent=2)+"\n")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
