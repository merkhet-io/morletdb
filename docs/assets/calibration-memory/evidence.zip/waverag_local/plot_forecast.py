"""Static research figure; every point is one completed seed, not a confidence interval."""
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def main():
    source,out=map(Path,sys.argv[1:])
    result=json.loads(source.read_text())
    names=['nlinear','raft','raft-zero','raft-random','raft-shuffled',
           'xlstm','xlstm-retrieval','xlstm-random']
    labels=['NLinear','RAFT','RAFT · zero references','RAFT · random references',
            'RAFT · shuffled continuations','xLSTM-Mixer','xLSTM + retrieval','xLSTM + random']
    fig,axes=plt.subplots(1,2,figsize=(12,5),sharey=True,layout='constrained')
    for ax,ds in zip(axes,('ETTh1','ETTh2')):
        models=result['datasets'][ds]['models']
        for i,name in enumerate(names):
            color='#246c9c' if 'raft' in name else '#8b4d9b'
            if name=='nlinear':color='#586069'
            xs=models[name]['seed_mse']
            ax.scatter(xs,i+np.asarray([-.09,0,.09]),s=28,color=color,alpha=.75)
            ax.plot(models[name]['median_mse'],i,'|',color='black',ms=14,mew=2)
        ax.set_title(ds)
        ax.set_xlabel('Test MSE · lower is better')
        ax.grid(axis='x',alpha=.2)
        ax.set_yticks(range(len(names)),labels)
    axes[0].invert_yaxis()
    fig.suptitle('Retrieval forecasting: controlled 10-epoch comparison\n720-hour context → 96-hour forecast · 3 seeds · validation-selected checkpoints')
    fig.savefig(out,dpi=170)
    plt.close(fig)


if __name__=='__main__':main()
