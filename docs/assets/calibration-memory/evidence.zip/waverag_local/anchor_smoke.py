"""Training-only RAFT artifact audit. No held-out forecasting scores or fitting.

Arguments: upstream checkout, ETTh1 CSV, output JSON. Uses upstream MIT code via imports;
does not vendor or modify it. Independent NumPy reference checks the retrieval output.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import numpy as np
import torch


def multiscale(a):
    result = []
    for g in (4, 2, 1):
        b = a.reshape(len(a), a.shape[1]//g, g, a.shape[2]).mean(axis=2)
        b = np.repeat(b, g, axis=1)
        result.append(b-b[:, -1:, :])
    return np.asarray(result)


def main():
    repo, csv, out = map(Path, sys.argv[1:])
    spec = importlib.util.spec_from_file_location('upstream_retrieval', repo/'layers/Retrieval.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Only the first 2048 TRAINING rows are parsed; validation and test are not read as values.
    a = np.loadtxt(csv, delimiter=',', skiprows=1, max_rows=2048, usecols=range(1,8))
    a = (a-a.mean(0))/a.std(0)
    L, H, K = 96, 24, 5
    x = np.array([a[i:i+L] for i in range(len(a)-L-H+1)])
    y = np.array([a[i+L:i+L+H] for i in range(len(x))])
    class Data:
        pred_len = H
        label_len = 0
        def __len__(self): return len(x)
        def __getitem__(self, i): return i, x[i], y[i], np.empty(0), np.empty(0)
    rt = module.RetrievalTool(L,H,7,n_period=3,topm=K)
    rt.prepare_dataset(Data())
    ids = np.arange(900,932)
    torch.set_num_threads(2)
    q = torch.tensor(x[ids], dtype=torch.float32)
    actual = rt.retrieve(q, torch.tensor(ids), train=True).numpy()
    # Quantize inputs identically, then use float64 independent arithmetic.
    xm, ym = multiscale(x.astype('f4').astype('f8')), multiscale(y.astype('f4').astype('f8'))
    expected, selections = [], []
    for period in range(3):
        keys = xm[period].reshape(len(x),-1)
        keys -= keys.mean(1,keepdims=True)
        keys /= np.maximum(np.linalg.norm(keys,axis=1,keepdims=True),1e-12)
        values = []
        for i in ids:
            sims = np.sum(keys*keys[i],axis=1)
            disallowed = np.abs(np.arange(len(x))-i) < L+H
            sims[disallowed] = -np.inf
            chosen = np.argsort(-sims,kind='stable')[:K]
            assert not disallowed[chosen].any()
            weights = np.exp((sims[chosen]-sims[chosen].max())/.1)
            weights /= weights.sum()
            values.append(np.sum(ym[period,chosen]*weights[:,None,None],axis=0))
            selections.append({'period':(4,2,1)[period],'query':int(i),'references':chosen.tolist()})
        expected.append(values)
    error = float(np.max(np.abs(actual-np.array(expected))))
    assert error < 1e-5, error
    # CPU placement adaptation, no upstream algorithm change or fitting.
    sys.path.insert(0,str(repo))
    from models.RAFT import Model
    torch.manual_seed(7)
    model = Model(SimpleNamespace(gpu=0,task_name='long_term_forecast',seq_len=L,
                                 pred_len=H,enc_in=7,n_period=3,topm=K))
    model.device = torch.device('cpu')
    model.retrieval_dict = {'train':torch.tensor(actual)}
    with torch.no_grad():
        prediction = model(q,torch.arange(len(ids)))
    assert prediction.shape == (32,H,7) and torch.isfinite(prediction).all()
    result = {'scope':'training-only smoke; no downstream quality evaluation',
        'upstream_commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
        'dataset_sha256':hashlib.sha256(csv.read_bytes()).hexdigest(),
        'training_rows_used':len(a),'gallery_windows':len(x),'queries':len(ids),
        'independent_max_absolute_error':error,'tolerance':1e-5,
        'forward_shape':list(prediction.shape),'torch':torch.__version__,
        'adaptation':'Override model.device to cpu; bypass upstream multiprocess loader with direct retrieve',
        'references':selections}
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='references'},indent=2))


if __name__=='__main__': main()
