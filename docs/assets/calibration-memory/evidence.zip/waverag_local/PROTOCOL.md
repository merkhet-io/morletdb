# WRL1: local evidence for tool-wear estimation

Status: protocol frozen before feature extraction or outcome computation. Local exploratory
research, not a product feature, independent confirmation, or deployment claim.

## Questions and boundaries

1. Does selecting similar, already labelled local episodes improve a frozen model on a
   different cutter, beyond recent observations and simple local refitting?
2. Can ordinary PostgreSQL provide deterministic, point-in-time reference selection and
   an inspectable manifest without another native extension?

These are distinct questions. No inference about database speed follows from model accuracy.
This is numerical retrieval augmentation, not language generation. It tests derived
waveform features, not whether passing neighbours' raw waveforms to a neural model helps.
No new extension and no production MorletDB changes will be made.

## Data and prior exposure

Use the existing PHM 2010 files for labelled cutters c1, c4, c6 (315 cuts each).
These data have been used in repository studies; all results are exploratory. We have
inspected the schema and previous reports, not computed this experiment's outcomes.
Verify each signal file against evaluation/context/c8/results/phm_inputs_SHA256SUMS.
Record hashes of label files, harness, protocol and environment. Target: mean of the
three measured flute-wear values, in the dataset's micrometre units. No thresholding
into replacement decisions and no remaining-life claim.

Each cutter is held out in turn. The other two cutters are the historical source archive,
assumed fully available before target commissioning (scenario assumption, not actual
cross-cutter calendar chronology). Evaluate target cuts 31..315, identical for all arms.
Only target cuts divisible by 10 and strictly before the query have available labels.
One cut of reporting delay is thus enforced; delayed or missing real-world feedback is
not evaluated. No target query label is used in fitting, normalization or retrieval.

## Frozen representation and methods

For each of seven channels: mean, standard deviation, RMS, peak/RMS and population
kurtosis; eight equal-width integrated Welch power bands over 0..25 kHz (50 kHz rate,
nperseg=2048, default Hann window). Log1p all nonnegative features; signed mean unchanged.
Scale features using source-only means/std, with std floor 1e-8. Preserve raw files.
No feature selection or tuning. All ridge models use alpha=10 with an intercept.

Arms:
- source_ridge: frozen ridge on signal features, source cutters only.
- cut_ridge: source-only ridge on cut index and its square, standardized source-only.
- latest_wear: most recent available target label.
- recent_residual: source_ridge plus mean target residual of latest five labelled cuts.
- random_residual: same correction from five uniformly selected available local cuts;
  seeds 7,17,27,37,47. Report average error across seeds, not prediction averaging.
- similar_residual (primary): same correction from five nearest available local cuts in
  standardized feature Euclidean distance; ties by cut ID ascending.
- local_trend: source_ridge plus least-squares linear extrapolation of residual versus
  cut index from the latest five available target labels (unclipped).
- refit_ridge: refit on source plus all available local labels, with local rows weighted
  so their total weight equals the source rows' total weight. Same scaler and alpha.

All reference sets use min(5, available). Clip final wear predictions below zero for all
arms, not above. Every primary prediction records query, reference IDs, distances,
available label cuts, source model identity and feature version.

## Outcomes and decision rule

Primary metric: MAE per cutter, then equal-cutter mean. Report RMSE and per-cutter results.
With only three independent cutters, do not bootstrap windows or claim population
significance. Report random arm mean and range across seeds.

Advance retrieval as a promising result only if similar_residual lowers mean MAE by
at least 10% versus EACH of source_ridge, latest_wear, recent_residual, random_residual,
local_trend, refit_ridge, and cut_ridge, and beats each comparator on at least two of
three cutters. Otherwise report not supported under this rule, with full results.
No follow-up tuning or selecting the most favorable cutter after seeing results.

## Database feasibility experiment

Use an isolated native PostgreSQL 17 instance and ordinary SQL tables with float8 arrays,
episode IDs, label-available-at and source hashes. Reproduce all primary reference sets
with exact SQL Euclidean ranking and strict availability predicates. Compare IDs, order
and distances to Python. Include a synthetic late-label test, deterministic tie,
tenant isolation under a non-owner RLS role, and missing-source manifest status.
Report this as feasibility only: no pgvector, no MorletDB performance comparison, no
claim of production readiness or benchmark over a large archive. Preserve the SQL.

## Integrity and stopping

Run synthetic leakage/ranking/residual tests before the real evaluation. Freeze protocol
and harness in a local git commit. Evaluate once; code corrections must be recorded as
deviations and old output preserved. Stop after this matrix and database check. A failure
to show retrieval benefit is sufficient evidence to defer a separate extension.
