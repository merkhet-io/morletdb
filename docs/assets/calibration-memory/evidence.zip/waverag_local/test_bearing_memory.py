import unittest
import numpy as np
import torch
from bearing_memory import parse_name,features,band_sums,ids_for,support_for,scale,contrastive,scores,retrieval,WINDOW,window_bounds

class BearingContracts(unittest.TestCase):
    def test_short_recording_and_preserved_tail(self):
        b=window_bounds(121082)
        self.assertEqual(len(b),4)
        self.assertEqual(b[-1],(76800,102400))
        self.assertEqual(121082-b[-1][1],18682)
        self.assertEqual(len(window_bounds(512001)),20)
        with self.assertRaises(ValueError):window_bounds(25599)

    def test_filename_and_shaft_distinction(self):
        self.assertEqual(parse_name('IO702.mat'),(3,6207,200))
        self.assertEqual(parse_name('N800.mat'),(0,6208,0))
        with self.assertRaises(ValueError):parse_name('B400.mat')

    def test_feature_constant_and_energy_partition(self):
        f=features(np.full(WINDOW,2.))
        np.testing.assert_array_equal(f[:192],np.full(192,-20.))
        self.assertEqual(f[192],2.)
        self.assertAlmostEqual(f[194],np.log1p(2.))
        p=np.arange(1025,dtype=float);self.assertAlmostEqual(band_sums(p,128).sum(),p.sum()*25.)

    def test_whole_recording_split_and_support(self):
        rows=[(t,l,c,w) for t in range(6204,6209) for l in (0,200,400) for c in range(5) for w in range(20)]
        a={'types':np.array([r[0] for r in rows]),'loads':np.array([r[1] for r in rows]),'y':np.array([r[2] for r in rows])}
        source=ids_for(a,[6204,6205,6206]);self.assertEqual(len(source),900)
        for t in (6207,6208):
            q=ids_for(a,[t],[200,400]);self.assertEqual(len(q),200)
            previous=set()
            for n in (0,1,2,8):
                support=support_for(a,t,n)
                self.assertEqual(len(support),5*n);self.assertTrue(previous<=set(support));previous=set(support)
                self.assertTrue(set(q//20).isdisjoint(support//20));self.assertTrue(set(q//20).isdisjoint(source//20))

    def test_scaling_excludes_targets(self):
        x=np.arange(1200.).reshape(6,200);other=x.copy();other[3:]*=10000
        _,m,s=scale(x,[0,1,2]);_,mm,ss=scale(other,[0,1,2])
        np.testing.assert_array_equal(m,mm);np.testing.assert_array_equal(s,ss)

    def test_contrastive_hand_computed(self):
        z=torch.tensor([[1.,0.],[1.,0.],[0.,1.],[0.,1.]])
        y=torch.tensor([0,0,1,1]);expected=np.log(1+2*np.exp(-10))
        self.assertAlmostEqual(contrastive(z,y).item(),expected,places=6)
        self.assertEqual(contrastive(z,torch.arange(4)).item(),0.)

    def test_recording_weight_not_window_weight(self):
        truth=np.array([0,0,1,2,3,4]);record=np.array([0,0,1,2,3,4])
        p=np.eye(5)[[0,0,0,2,3,4]]
        self.assertAlmostEqual(scores(p,truth,record)['macro_f1'],(2/3+0+1+1+1)/5)

    def test_reference_ties_and_query_label_exclusion(self):
        x=np.zeros((7,3));q=np.array([6]);g=np.array([5,4,3,2,1,0]);y=np.arange(7)%5
        p,ids,_,_=retrieval(x,q,g,y,np.random.default_rng(1));np.testing.assert_array_equal(ids,[[0,1,2,3,4]])
        yy=y.copy();yy[6]=4
        pp,ii,_,_=retrieval(x,q,g,yy,np.random.default_rng(1));np.testing.assert_array_equal(p,pp);np.testing.assert_array_equal(ids,ii)

if __name__=='__main__':unittest.main()
