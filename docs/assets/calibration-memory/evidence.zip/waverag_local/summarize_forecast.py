"""Summarize all frozen WRL2 runs, fail on incomplete or inconsistent evidence."""
import json
from pathlib import Path
import sys

import numpy as np

from forecast import METHODS, digest


def main():
    root, out = map(Path,sys.argv[1:])
    out.mkdir(parents=True,exist_ok=True)
    summary = {'scope':'Controlled-budget forecasting; not best-tuned SOTA or industrial validation',
               'datasets':{}, 'artifacts':{}}
    for ds in ('ETTh1','ETTh2'):
        folder=root/ds
        manifest=json.loads((folder/'manifest.json').read_text())
        assert manifest['harness_sha256']==digest(Path(__file__).with_name('forecast.py'))
        assert manifest['protocol_sha256']==digest(Path(__file__).with_name('FORECAST_PROTOCOL.md'))
        results={}
        for method in (*METHODS,'persistence','daily','weekly'):
            seeds=range(3) if method in METHODS else (None,)
            runs=[]
            for seed in seeds:
                stem=method+(f'-{seed}' if seed is not None else '')
                path=folder/(stem+'.json')
                r=json.loads(path.read_text())
                err=np.load(folder/(stem+'-errors.npy'))
                assert err.shape==(2785,2) and np.isfinite(err).all()
                np.testing.assert_allclose(err.mean(0),[r['mse'],r['mae']],rtol=1e-12)
                runs.append(r)
            results[method]={'median_mse':float(np.median([r['mse'] for r in runs])),
                             'median_mae':float(np.median([r['mae'] for r in runs])),
                             'seed_mse':[r['mse'] for r in runs],
                             'runs':runs}
        gates={}
        for name,method,controls in [('raft','raft',('raft-zero','raft-random')),
                                    ('xlstm_augmentation','xlstm-retrieval',('xlstm','xlstm-random'))]:
            checks={}
            for control in controls:
                gain=1-results[method]['median_mse']/results[control]['median_mse']
                consistent=all(a<b for a,b in zip(results[method]['seed_mse'],results[control]['seed_mse']))
                # Each block compared after averaging seeds, preserve every block.
                ae=np.mean([np.load(folder/f'{method}-{s}-errors.npy')[:,0] for s in range(3)],axis=0)
                be=np.mean([np.load(folder/f'{control}-{s}-errors.npy')[:,0] for s in range(3)],axis=0)
                delta=[float((ae-be)[i:i+168].mean()) for i in range(0,len(ae),168)]
                checks[control]={'median_relative_mse_reduction':gain,'all_seeds_better':consistent,
                                 'paired_weekly_mse_delta':delta,'blocks_better':sum(x<0 for x in delta),
                                 'blocks_total':len(delta),'pass':gain>=.02 and consistent}
            passed=all(c['pass'] for c in checks.values())
            if name=='raft':
                shuffled=results['raft']['median_mse']<results['raft-shuffled']['median_mse']
                passed=passed and shuffled
            gates[name]={'pass':passed,'comparisons':checks}
        summary['datasets'][ds]={'manifest':manifest,'models':results,'gates':gates,
                                'retrieval':json.loads((folder/'retrieval.json').read_text())}
        for p in sorted(folder.iterdir()):
            if p.suffix in ('.json','.npy','.pt'):
                summary['artifacts'][str(p.relative_to(root))]={'sha256':digest(p),'bytes':p.stat().st_size}
    summary['conditional_storage_gate_passed']=any(g['pass'] for d in summary['datasets'].values() for g in d['gates'].values())
    (out/'forecast_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    lines=['| Model | ETTh1 median MSE | ETTh2 median MSE |','|---|---:|---:|']
    for name in (*METHODS,'persistence','daily','weekly'):
        lines.append('| '+name+' | '+' | '.join(f"{summary['datasets'][d]['models'][name]['median_mse']:.5f}" for d in ('ETTh1','ETTh2'))+' |')
    (out/'forecast_table.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))
    print('Conditional storage gate:',summary['conditional_storage_gate_passed'])


if __name__=='__main__': main()
