# WRL3: hydraulic diagnosis with a small labelled reference archive

Frozen before feature extraction, fitting or prediction scoring, 2026-11-23.
Exploratory offline experiment on one hydraulic test rig, not fleet generalization,
online chronological replay, an LLM evaluation or a MorletDB search benchmark.
Discovery inspected profile labels, block sizes and original documentation only.

## Source and evaluation units

UCI archive SHA256:
24128aad2ee45eea7e6b63ebbd9992cdf25d0483a2cebefbfc13bc69079af1f2.
Preserve the original ZIP. A recording is one sensor's complete 60-second cycle.
Use only stable cycles (profile column5=0): 1,449 cycles. This is an oracle
stability filter; results do not cover detecting stability in deployment.
Define a block by each change in the first four profile columns in acquisition
order, before filtering. There are194 full blocks,144 with stable samples.

Tasks: four-class valve state (73/80/90/100) and four-class accumulator state
(90/100/115/130). The source documentation calls valve an easy task and accumulator
a harder task; both are included before scoring. For each task, hold out each
cooler state (3,20,100) in turn. All cycles of that cooler state are excluded from
training, scaling and retrieval. No target-cooler calibration or validation labels.
Cooler, pump, accumulator/valve labels, stability, row number and block ID are not
model features. Cooler state here is another component's condition, not a new asset.

Primary metric: macro-F1 on blocks, averaging predicted class probabilities over
all stable cycles within each test block, then taking argmax. Each held-out cooler
has48 test blocks,12 per target class. Report cycle macro-F1, balanced accuracy,
confusion matrices and reference-label purity separately. Never count subwindows
as independent test observations. Same rig and repeated factorial conditions limit
external validity; training seeds are not independent machines.

## Labels and representation

Budgets:2 and8 labelled cycles per class (8 and32 labels total). Seeds0..4. Select
one cycle per distinct block, balanced over the two source cooler states. Draw an
ordered four-block sample per class/source state, then one random cycle per block;
the smaller budget takes the first block per state, making budgets nested.
All methods, including retrieval, see exactly these labels. No additional labelled
validation set, no tuning, no early stopping, no target-domain adaptation.
Sampling uses known class/block/cooler labels to construct balanced experimental
budgets; discovering those labels in a real annotation workflow has additional cost.

Use14 physical sensors: PS1..6, EPS1, FS1..2, TS1..4, VS1. Exclude virtual CE,CP,SE.
Preserve every original sample and its sampling specification. Derived model
features are explicitly lossy, versioned views; they do not replace recordings:

- Per sensor: mean,std,min,max,RMS,p10,p90,last-first, plus12 consecutive5-second
  means, giving280 features per cycle. Population std and NumPy linear quantiles.
- Temporal view:60 one-second means per sensor, giving60x14. A100Hz channel is
  averaged in groups100,10Hz in groups10,1Hz is unchanged. No interpolation.
- Standardize each statistical feature using labelled training cycles only;
  constant dimensions use scale1. Standardize temporal channels using only labelled
  training cycles and their60 time bins. All normalization uses population std.

## Fixed models and controls

Uniform class prior (argmax tie chooses first class); multinomial logistic
regression C=1,max_iter=2000; RandomForest200 trees,max_features=sqrt,
min_samples_leaf=1,class_weight=balanced,n_jobs=1; compact temporal CNN:
Conv1d14->16,kernel5,padding2,ReLU,Conv16->32,kernel5,padding2,ReLU,
AdaptiveAvgPool1d10,flatten,Linear320->4. TCN trains exactly100 epochs with Adam
lr.001,cross entropy,batch8,seeded shuffled batches,no dropout or weight decay.
CPU float32, two Torch threads. Final epoch; no checkpoint selection.
The internal method key `tcn` denotes this small two-layer temporal CNN, not a
reproduction of a published dilated/causal TCN or an xLSTM classifier.

Retrieval: five nearest labelled cycles in standardized280-feature Euclidean
distance, deterministic distance/cycle-ID tie ordering, uniform class vote.
DTW baseline:1-nearest labelled cycle in standardized60x14 temporal view,
sum of squared multichannel local costs, Sakoe-Chiba band3 bins, standard three
predecessor recurrence. Equal sequence lengths; no path-length normalization.
This is DTW on a derived one-second view, not full-rate waveform DTW.

Augment RF and TCN separately by averaging model and kNN probabilities50:50.
Controls use the identical fusion weight: (a) five uniformly random eligible
references without replacement per query, and (b) genuine nearest IDs with a fixed
permutation of gallery labels. Random references/permutations are frozen by seed
and shared across fusion backbones. The label-shuffle is an evaluator ablation,
never an actual database update. No learned retriever, feature selection or HPO.

## Decision rule and evidence

Report all2 targets x2 budgets x3 cooler holdouts x5 seeds (60 cases), including
negative results. For each task/budget, average seeds then cooler holdouts equally.
For each fusion separately, require >=.02 absolute macro-F1 improvement over the
strongest non-retrieval comparator (logistic/RF/TCN), and over both of its random
and shuffled controls, plus improvement over the strongest comparator in every
cooler holdout. Strongest comparator is an evaluation hurdle, not a model selected
for deployment using test data. Report all four task/budget settings; no selecting
only favourable conditions. Evaluate pure kNN and DTW against the same strongest
comparator and directional requirement separately.

Save every per-cycle prediction, block prediction, training cycle ID, retrieved ID,
distance and shuffled/random selection. Assert references are labelled, from source
coolers and disjoint from query blocks. Reference purity is agreement with evaluator
labels; it is not proof of causal explanation or correct maintenance advice.
Provide deterministic examples: first stable cycle of first block per target class
in each holdout, seed0, larger budget. Link each citation to sensor member/cycle row,
sample interval, acquisition rate and archive hash. No LLM explanation score.

Before scoring: test block boundaries, disjoint holdouts, nested budgets, source-only
normalization, tie ordering, macro-F1 fixture, and compiled DTW vs independent Python
recurrence. Record compiler, dependency, harness and protocol hashes. Keep all prior
WRL1/WRL2 results intact. Any storage or product conclusion is conditional on evidence,
and neither a positive classifier result nor its reference purity establishes a DB moat.
