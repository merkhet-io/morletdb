import unittest
from pathlib import Path
import numpy as np
from episodic import split, support_ids, standardize, squared, memory, blend, gate_features

DATA=Path('/Users/zin/sophia/morletdb/data/wrl3-20261123/features.npz')

class EpisodicContracts(unittest.TestCase):
    def test_disjoint_nested_fixed_test(self):
        a=np.load(DATA);p,b=a['profile'],a['blocks']
        for col in (1,3):
            for held in (3,20,100):
                previous=None
                for seed in range(5):
                    s=split(p,b,col,held,seed)
                    self.assertEqual([len(s[k]) for k in ('train','validation','support')],[64,32,32])
                    names=list(s)
                    for i,k in enumerate(names):
                        for j in names[i+1:]:self.assertTrue(set(b[s[k]]).isdisjoint(b[s[j]]))
                    self.assertEqual(len(set(b[s['query']])),16)
                    for n in (0,1,2,8):
                        ids=support_ids(s['support'],n)
                        self.assertEqual(len(ids),4*n)
                        self.assertTrue(set(ids)<=set(s['support']))
                        if n:np.testing.assert_array_equal(np.unique(p[ids,col],return_counts=True)[1],[n]*4)
                    self.assertTrue(set(support_ids(s['support'],1))<=set(support_ids(s['support'],2)))
                    if previous is not None:np.testing.assert_array_equal(previous,s['query'])
                    previous=s['query']
                    self.assertTrue((p[s['train'],0]!=held).all())
                    self.assertTrue((p[s['support'],0]==held).all())

    def test_source_only_scaling(self):
        x=np.arange(120.).reshape(10,3,4);changed=x.copy();changed[3:]*=99999
        _,m,s=standardize(x,[0,1,2],True);_,mm,ss=standardize(changed,[0,1,2],True)
        np.testing.assert_array_equal(m,mm);np.testing.assert_array_equal(s,ss)

    def test_distance_and_ties(self):
        z=np.array([[0.,0.],[1.,0.],[-1.,0.],[0.,2.]])
        np.testing.assert_array_equal(squared(z[:1],z[1:]),[[1.,1.,4.]])
        p,ids,d,_=memory(z,np.array([0]),np.array([2,1,3]),np.array([0,1,2,3]),np.random.default_rng(0))
        np.testing.assert_array_equal(ids,[[1,2,3]])
        np.testing.assert_allclose(p,[[0,1/3,1/3,1/3]])
        np.testing.assert_array_equal(d,[[1,1,4]])

    def test_gate_limits_and_entropy(self):
        base=np.array([[.1,.2,.3,.4]]);mem=np.array([[1.,0.,0.,0.]])
        np.testing.assert_array_equal(blend(base,mem,np.zeros((1,1))),base)
        np.testing.assert_array_equal(blend(base,mem,np.ones((1,1))),mem)
        np.testing.assert_allclose(blend(base,mem,np.full((1,1),.25)).sum(1),1)
        f=gate_features(base,mem,np.ones((1,5)))
        np.testing.assert_allclose(f,[[.4,1.,1.,0.,0.]])

    def test_query_labels_cannot_change_retrieval(self):
        z=np.eye(8);y=np.arange(8)%4;q=np.array([6,7]);g=np.arange(6)
        yy=y.copy();yy[q]=(yy[q]+1)%4
        a=memory(z,q,g,y,np.random.default_rng(4));b=memory(z,q,g,yy,np.random.default_rng(4))
        for left,right in zip(a,b):np.testing.assert_array_equal(left,right)

if __name__=='__main__':unittest.main()
