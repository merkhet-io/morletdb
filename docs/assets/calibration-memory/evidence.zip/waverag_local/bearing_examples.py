"""Deterministic evidence cards: seed0, first200W query window per class/type, budget8."""
import argparse
import json
from pathlib import Path
import numpy as np
from hydraulic import save_json


def main(out,destination):
    a=np.load(out/'features.npz');records=json.loads((out/'recordings.json').read_text());examples=[]
    def ref(i):
        r=records[int(a['record'][i])]
        return {'window_id':int(i),'recording_id':int(a['record'][i]),'filename':r['filename'],
            'sha256':r['sha256'],'sample_interval':a['bounds'][i].tolist(),'sample_rate_hz':r['sample_rate_hz'],
            'bearing_type':r['bearing_type'],'load_watts':r['load_watts']}
    for target in (6207,6208):
        saved=np.load(out/f'target{target}-s0.npz');q=saved['query_ids'];p=saved['probabilities'][-1,2]
        for cls in range(5):
            ix=int(np.flatnonzero((a['y'][q]==cls)&(a['loads'][q]==200))[0]);qi=int(q[ix])
            refs=saved['n8_nearest_ids'][ix]
            examples.append({'query':ref(qi),'query_truth_for_evaluator_only':records[int(a['record'][qi])]['class'],
                'window_predicted_class':('N','I','O','IO','OB')[int(p[ix].argmax())],
                'references':[dict(ref(int(i)),confirmed_class=records[int(a['record'][i])]['class'],
                     squared_embedding_distance=float(d)) for i,d in zip(refs,saved['n8_distances'][ix])]})
    save_json(destination,{'selection_rule':__doc__,'examples':examples,
        'scope':'Window-level evidence, not full-recording predictions or maintenance explanations.'})

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--destination',type=Path,required=True)
    args=ap.parse_args();main(args.out,args.destination)
