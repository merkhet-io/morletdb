import unittest
import numpy as np
import torch
from storage_experiment import transform


class TransformContract(unittest.TestCase):
    def test_known_ramp_offset_and_scale(self):
        raw=np.broadcast_to(np.arange(96,dtype='f8')[None,None,:,None],(3,20,96,7)).copy()
        weights=torch.full((3,20),1/20)
        actual=transform(raw,weights,np.zeros(7),np.ones(7)).numpy()
        for i,g in enumerate((4,2,1)):
            expected=(np.arange(96)//g*g-(96-g))[:,None]*np.ones((1,7))
            np.testing.assert_allclose(actual[i],expected,atol=1e-5,rtol=0)


if __name__=='__main__':unittest.main()
