import ctypes
import io
from pathlib import Path
import unittest
import zipfile
import numpy as np
from hydraulic import block_ids,select_train,scale_from_train,nearest,evaluate,dtw


class Contracts(unittest.TestCase):
    def test_block_boundaries(self):
        p=np.array([[3,73,0,90,1],[3,73,0,90,0],[3,80,0,90,0]])
        np.testing.assert_array_equal(block_ids(p),[0,0,1])

    def test_nested_disjoint_real_profile(self):
        path='/Users/zin/sophia/morletdb/data/wrl2-20261123/inputs/wrl2-hydraulic.zip'
        with zipfile.ZipFile(path) as z:p=np.loadtxt(io.BytesIO(z.read('profile.txt'))).astype(int)
        blocks=block_ids(p)
        for target in (1,3):
            for held in (3,20,100):
                for seed in range(5):
                    small=select_train(p,blocks,target,held,2,seed)
                    big=select_train(p,blocks,target,held,8,seed)
                    self.assertTrue(set(small)<=set(big))
                    self.assertTrue((p[big,0]!=held).all())
                    self.assertEqual(len(set(blocks[big])),32)
                    np.testing.assert_array_equal(np.unique(p[big,target],return_counts=True)[1],[8]*4)

    def test_training_only_scale(self):
        a=np.arange(120,dtype=float).reshape(10,12);b=a.copy();b[3:]+=10000
        _,m,s=scale_from_train(a,[0,1,2]);_,mm,ss=scale_from_train(b,[0,1,2])
        np.testing.assert_array_equal(m,mm);np.testing.assert_array_equal(s,ss)

    def test_tie_order(self):
        np.testing.assert_array_equal(nearest(np.array([[4.,1.,1.]]),np.array([5,9,2]),2),[[2,1]])

    def test_block_metric_equal_weight(self):
        # Four blocks: class0 correct, class1 wrong->0, classes2/3 correct. F1=(2/3+0+1+1)/4.
        p=np.eye(4)[[0,0,0,2,3]];y=np.array([0,0,1,2,3]);b=np.array([0,0,1,2,3])
        self.assertAlmostEqual(evaluate(p,y,b)['block_macro_f1'],2/3)

    def test_dtw_independent_recurrence(self):
        lib=ctypes.CDLL('/tmp/wrl3-dtw.dylib');rng=np.random.default_rng(9)
        q=rng.normal(size=(2,7,3));g=rng.normal(size=(3,7,3))
        expected=np.empty((2,3))
        for a in range(2):
            for b in range(3):
                d=np.full((8,8),np.inf);d[0,0]=0
                for i in range(1,8):
                    for j in range(1,8):
                        if abs(i-j)<=3:d[i,j]=sum((q[a,i-1]-g[b,j-1])**2)+min(d[i-1,j],d[i,j-1],d[i-1,j-1])
                expected[a,b]=d[-1,-1]
        np.testing.assert_allclose(dtw(q,g,lib),expected,rtol=1e-14,atol=1e-14)
        self.assertEqual(dtw(q[:1],q[:1],lib)[0,0],0.)


if __name__=='__main__':unittest.main()
