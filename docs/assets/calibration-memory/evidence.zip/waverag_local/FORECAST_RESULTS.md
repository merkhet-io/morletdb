# WRL2: small retrieval benefit on ETTh1, no robust cross-dataset gain

This local study tests retrieval-augmented numerical forecasting, not an LLM RAG
system, and does not use MorletDB's search algorithm. The frozen choices are in
[FORECAST_PROTOCOL.md](FORECAST_PROTOCOL.md). ETTh1 and ETTh2 use hourly transformer
measurements, seven channels, a 720-hour context and 96-hour horizon. Each trainable
configuration uses three seeds and ten epochs; checkpoint selection uses validation
only. Test metrics are computed over 2,785 windows per dataset, with training-only
scaling and a training-only reference gallery.

## Findings

1. **A modest retrieval effect reproduces on ETTh1.** RAFT median MSE is 0.366745,
   vs NLinear 0.377505 (2.85% reduction). Against the same-capacity RAFT-zero control,
   the reduction is only 1.32%; against random retrieval it is 1.55%. All three seeds
   improve over those RAFT controls, but the predeclared 2% median gate is not met.
   Removing the correspondence between historical context and continuation also
   weakens results. This supports a small useful signal, not a large or universal gain.
2. **The benefit reverses on ETTh2.** RAFT median MSE 0.280761 is 3.98% worse than
   RAFT-zero 0.270003 and 1.58% worse than NLinear 0.276385. All three seeds regress
   against RAFT-zero. A positive ETTh1 result does not establish general usefulness.
3. **Retrieval does not improve the tested xLSTM augmentation reliably.** Median
   MSE worsens by 0.59% on ETTh1 and 2.22% on ETTh2 relative to plain xLSTM-Mixer.
   Neither augmentation gate can pass, regardless of the random-reference control,
   because improvement over plain xLSTM is a necessary condition.
4. **This is not a claim that RAFT beats best-tuned xLSTM.** The official xLSTM
   architecture runs on its vanilla float32 CPU backend. Its [published ETTh1 preset](https://github.com/mauricekraus/xlstm-mixer/blob/730b0531aa9456e498765028f3c22ca3677de42e/scripts/long_term_forecasting/ett/h1.sh)
   uses 512 context, L1 loss and 40 epochs with another scheduler. Our common budget
   uses 720 context, MSE and 10 cosine-scheduled epochs. All plain xLSTM runs select
   epoch 1; declining training error with rising validation error indicates overfitting
   under these settings. Published-preset or validation-tuned rankings may differ.
5. **No database extension is justified by these results alone.** The conditional
   storage gate fails for both model families and datasets. The storage protocol and
   harness are prepared, but the native database comparison is not run. Its numerical
   transform unit check is not an integration or performance result.

The prior PHM2010 [WRL1 negative result](RESULTS.md) remains unchanged. WRL1's wear
calibration task and WRL2's forecasting task are separate experiments; they must not
be combined into an overall retrieval success rate.

## Full results and uncertainty

The generated [table](results/forecast_table.md), [summary](results/forecast_summary.json)
and [figure](results/forecast_comparison.png) contain all model/control medians and
each seed. The summary preserves validation histories, chosen epochs, MAE, parameter
counts, per-run times and paired weekly MSE differences. Points in the figure are
seeds, not confidence intervals. No IID significance test is used: overlapping
windows are strongly dependent and even weekly blocks share context/forecast ranges.
Three seeds vary initialization, not the population of machines.

With seed-averaged paired errors, RAFT improves over RAFT-zero in 12 of 17 weekly
blocks on ETTh1 and only 2 of 17 on ETTh2. The xLSTM augmentation improves over
plain xLSTM in 9 of 17 blocks on ETTh1 and 5 of 17 on ETTh2. These descriptive counts
support the dataset-specific interpretation; they are not independent trials.

Persistence, daily seasonal and weekly seasonal baselines are included. Raw test
errors for every query and all 48 checkpoints are retained in the ignored local
artifact directory. Test results were not used to change hyperparameters, select
additional datasets for this run, or stop unfavourable runs early.

## Implementation and verification

- Reuse original RAFT model and multiscale decomposition. Override CUDA device to CPU.
  Cache normalized keys and accumulate only selected values to avoid repeatedly
  normalizing the gallery. Compare first 64 train/validation/test query outputs on
  both datasets against the original upstream retriever at absolute tolerance 2e-5.
  This is a checked numerical implementation adaptation, not a new retrieval metric.
- RAFT random references are eligible uniform samples with equal weights. Shuffled
  continuations retain similarity weights but replace future windows with random
  eligible training windows. They are explicit local controls, not asserted to match
  every detail of the paper's ablation implementation.
- xLSTM augmentation adds 16,416 parameters in three zero-initialized residual
  projections of retrieved continuations; the random-reference model has the same
  architecture. This simple fusion design is one tested option, not the best possible
  way to augment xLSTM.
- Nine unit checks cover split boundaries, source-only scaling, half-open overlap,
  source interval identity, the continuation transformation, and prior WRL1 contracts.
  The standalone storage test initially failed to import optional psycopg; deferring
  that import to the native-run entry point fixed test isolation. No forecast settings
  changed. Native storage tests are intentionally not counted as passing.
- Independent float64 NLinear arithmetic and persisted-checkpoint replay are recorded
  in [forecast_numerical_audit.json](results/forecast_numerical_audit.json). Summary
  generation checks every saved query-error array against its reported MSE/MAE and
  verifies that the executed harness/protocol hashes still match the frozen files.
- Both ETT files have 14,400 audited timestamps at exactly 3,600-second spacing. Source
  commit IDs, file hashes, licenses, platform and package versions are recorded.
- `tools/precheck.sh` passes; it selects no site/paper/Rust checks for this research-only
  path. No website, production code, schema or migration was changed. `git diff --check`
  and local Markdown link checks are used for the research report.

## Runtime and storage scope

Two dataset processes run concurrently on the same macOS arm64 machine, each with
two PyTorch CPU threads. Wall times are development observations under contention,
not isolated model throughput benchmarks. Peak RSS is cumulative for each process;
it includes retrieval preparation and must not be read as per-model memory usage.

Each training gallery has 7,825 overlapping examples. The original-style raw and
three-scale context/future float32 tensors account for 715,142,400 bytes, whereas
the normalized training source rows contain 241,920 bytes. This large difference
reflects duplication in a representation. It does NOT mean a database would remove
all that memory: search keys, reference manifests and retrieval outputs still cost
space. `retrieval.pt` also contains all three retrieval controls across all splits.
There is no measured PostgreSQL, MorletDB or memmap performance result in WRL2.

## Next investigation

Use [DATASETS.md](DATASETS.md) for the audited shortlist. Prioritize hydraulic
cycle diagnosis, with whole condition blocks held out and a limited-label setting,
then censored filtration histories after resolving their time-reset anomaly.
Evaluate whether references improve a strong predictor and whether cited episodes
support an engineer's or agent's diagnosis. That is closer to shared operational
memory than forecasting one transformer's next96 hours.

A subsequent forecasting comparison should separately pre-register the official
xLSTM preset or a validation-only equal tuning budget, including an independent
holdout since these ETT test results are now known. Do not retune the present run
and call it confirmation. Any storage study should retain algorithm/output parity
and compare ordinary arrays/memmap and plain PostgreSQL before proposing an extension.

## Reproduction

Check out the upstream revisions pinned in the protocol. Use the recorded Python 3.12
environment with torch 2.9.0, numpy 2.2.6, xlstm 1.0.3, einops 0.8.1 and tqdm 4.67.1.
The last three packages were installed only in `/tmp/wrl-anchor-deps`; the main
project environment was not modified. All work is local, without a PR or publication.

```sh
PYTHONPATH=/tmp/wrl-anchor-deps OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  /Users/zin/sophia/morletdb/.venv-research/bin/python research/waverag_local/forecast.py \
  --dataset ETTh1 --data /tmp/waverag-anchor-ETTh1.csv --out /tmp/wrl2-reproduction/ETTh1
PYTHONPATH=/tmp/wrl-anchor-deps OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  /Users/zin/sophia/morletdb/.venv-research/bin/python research/waverag_local/forecast.py \
  --dataset ETTh2 --data /tmp/waverag-anchor-ETTh2.csv --out /tmp/wrl2-reproduction/ETTh2
PYTHONPATH=/tmp/wrl-anchor-deps /Users/zin/sophia/morletdb/.venv-research/bin/python \
  research/waverag_local/summarize_forecast.py /tmp/wrl2-reproduction /tmp/wrl2-reproduction-summary
PYTHONPATH=/tmp/wrl-anchor-deps /Users/zin/sophia/morletdb/.venv-research/bin/python \
  research/waverag_local/audit_forecast_numerics.py /tmp/wrl2-reproduction /tmp/wrl2-reproduction-summary/audit.json
MPLCONFIGDIR=/tmp/wrl2-matplotlib /Users/zin/sophia/morletdb/.venv-research/bin/python \
  research/waverag_local/plot_forecast.py /tmp/wrl2-reproduction-summary/forecast_summary.json /tmp/wrl2-reproduction-summary/comparison.png
```

The original inputs and large artifacts are retained at
`/Users/zin/sophia/morletdb/data/wrl2-20261123/` (ignored by Git). Checksum manifests
are committed; checkpoint and retrieval tensor files are not. Reproduction is not
an additional independent confirmation dataset.
