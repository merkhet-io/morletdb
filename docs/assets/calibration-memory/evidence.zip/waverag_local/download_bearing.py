"""Download original WRL5 files; verify publisher SHA256, never execute source content."""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path
import re
import subprocess


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    raw=args.out/'raw';raw.mkdir(parents=True,exist_ok=True)
    files=json.loads((args.out/'source_metadata.json').read_text())
    selected=[f for f in files if re.fullmatch(r'(N|I|O|IO|OB)[4-8]0[024]\.mat',f['filename'])]
    assert len(selected)==75
    def get(f):
        p=raw/f['filename'];d=f['content_details']
        if not p.exists():
            temp=p.with_suffix('.partial')
            subprocess.run(['curl','-fLsS','--retry','3','--max-time','180',d['download_url'],'-o',str(temp)],check=True)
            assert hashlib.sha256(temp.read_bytes()).hexdigest()==d['sha256_hash']
            temp.rename(p)
        assert hashlib.sha256(p.read_bytes()).hexdigest()==d['sha256_hash']
        print('verified',p.name,p.stat().st_size,flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(get,selected))

if __name__=='__main__':main()
