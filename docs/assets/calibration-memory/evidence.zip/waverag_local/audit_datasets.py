"""Structural discovery audit only; no fitting, model selection or test scoring."""
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile

import numpy as np


def main():
    output = {'scope': 'Dataset discovery; these data have not been benchmarked', 'datasets': {}}
    for name in ('hydraulic','p2p','cnc'):
        path = Path('/tmp/wrl2-'+name+'.zip')
        with zipfile.ZipFile(path) as z:
            record = {'zip_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                      'compressed_bytes':path.stat().st_size,
                      'members':[{ 'name':m.filename,'bytes':m.file_size} for m in z.infolist()]}
            if name == 'hydraulic':
                profiles = np.loadtxt(io.BytesIO(z.read('profile.txt')))
                record['profile_shape'] = list(profiles.shape)
                record['condition_levels'] = [np.unique(profiles[:,i]).tolist() for i in range(5)]
                record['sensors'] = {}
                for member in z.namelist():
                    if member in ('profile.txt','description.txt','documentation.txt'):
                        continue
                    rows, width, bad = 0, set(), 0
                    with z.open(member) as f:
                        for line in f:
                            a = np.fromstring(line.decode(),sep='\t')
                            rows += 1; width.add(len(a)); bad += int((~np.isfinite(a)).sum())
                    assert rows == 2205 and len(width)==1 and bad==0
                    record['sensors'][member] = {'cycles':rows,'samples_per_cycle':width.pop(),'nonfinite':bad}
            elif name == 'p2p':
                by_id = {}
                with io.TextIOWrapper(z.open('Train_Data_CSV.csv')) as f:
                    reader = csv.DictReader(f)
                    record['training_columns']=reader.fieldnames
                    for row in reader:
                        by_id.setdefault(row['Data_No'],[]).append(float(row['Time']))
                record['training_trajectories']=len(by_id)
                record['training_lengths']={k:len(v) for k,v in by_id.items()}
                record['training_time_strictly_increases']=all(np.all(np.diff(v)>0) for v in by_id.values())
                record['training_time_resets']=[{'series':k,'position_zero_based':int(i+1),
                    'previous':v[i],'next':v[i+1]} for k,v in by_id.items()
                    for i in np.flatnonzero(np.diff(v)<=0)]
                record['training_step_values_rounded_6dp']=np.unique(np.round(np.concatenate([np.diff(v) for v in by_id.values()]),6)).tolist()
                with io.TextIOWrapper(z.open('Test_Data_CSV.csv')) as f:
                    record['test_header_only']=next(csv.reader(f))
                record['uncensored_training_file_present']='Train_Data_Uncensored.mat' in z.namelist()
                record['uncensored_values_read']=False
                record['inspection_note']='Pre-audit manually previewed the first test CSV row; no test scores or label-driven selection.'
            else:
                with io.TextIOWrapper(z.open('train.csv')) as f:
                    labels=list(csv.DictReader(f))
                record['experiments']=len(labels)
                record['tool_condition_counts']={label:sum(x['tool_condition']==label for x in labels) for label in ('worn','unworn')}
                record['blank_visual_inspection_labels']=sum(not x['passed_visual_inspection'] for x in labels)
                record['recordings']={}
                for member in z.namelist():
                    if not member.startswith('experiment_'): continue
                    with io.TextIOWrapper(z.open(member)) as f:
                        reader=csv.reader(f); header=next(reader)
                        rows=sum(1 for _ in reader)
                    record['recordings'][member]={'rows':rows,'columns':len(header)}
                record['header']=header
                record['timing_note']='No explicit timestamp column; sample interval must come from acquisition documentation.'
            output['datasets'][name]=record
    Path(sys.argv[1]).write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:{key:v for key,v in r.items() if key not in ('members','header','sensors','recordings','training_lengths')} for k,r in output['datasets'].items()},indent=2))


if __name__=='__main__': main()
