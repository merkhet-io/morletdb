# WRL2-S: conditional continuation-store experiment

Written before storage measurements; run only if a WRL2 retrieval gate passes.
This is an exploratory warm-cache local readback microbenchmark, not a DB
throughput, online-update, indexing or concurrency benchmark.

Use ETTh1 training rows [0,8640), stored as source float64 samples, preserving
all seven channels. Select64 uniformly spaced test query starts from the frozen
WRL2 set. Retrieve top20 at each of4/2/1 scales with the same source-only normalized
RAFT correlation and training gallery. Freeze/save IDs and weights. No model
training, hyperparameter choice or test-quality selection occurs here.

Read the same96-sample continuations using:

1. Materialized raw float64 future-window array (all7,825 candidate windows).
2. NumPy memmap of the original contiguous recording.
3. Ordinary PostgreSQL17 bytea recording, batch substring reads in one query for
   the60 requested references. No extension or vector index; local Unix socket.
4. Existing MorletDB embedded/SQLite library via Python SDK, seven recordings,
   default4096-sample chunks. This measures the embedded edition, NOT pg_morlet.
   Record binary hash because the existing local build's source provenance is not
   guaranteed by the research worktree revision. Verify bit-exact readback first.

Normalize recovered values with frozen training mean/std, cast tofloat32, apply
the same scale means/offset removal and similarity weights. Require raw bit parity
and continuation-tensor absolute error<2e-5 vs frozen original retrieval cache.
Require forecast parity<2e-5 through a frozen RAFT checkpoint as an additional
check; no quality comparison is inferred from this numerical tolerance.

Measure build wall time, physical artifact bytes (including PostgreSQL relation
and TOAST size, SQLite WAL when open), and per-query value-fetch plus transformation
latency. One untimed warm-up and three repeats, rotating backend order per query.
Store every latency, report median/p95. Include reference/index metadata size
separately; similarity key matrices and retrieval search are not eliminated by
changing the value store. Original materialized gallery and cached normalized
features must not be advertised as wholly removable by this result.

For update cost, append96 deterministic synthetic rows (repeat final training row)
to each raw recording after readback. Measure durable append latency and size
delta, and check old data plus suffix bit-exact. Memmap flush+fsync; PostgreSQL
one bytea append/transaction; MorletDB seven per-channel SDK transactions. These
have different atomicity and are not equivalent multi-channel transactions.
The materialized future-window store is immutable in this prototype; report its
update as not implemented. Updates do not enter forecasting or reference selection.

Use a new disposable PostgreSQL cluster and close it afterwards. No production
database, application schema, website or library changes. Public code/data versions
and result checksums remain with the research artifacts. Small-data outcomes do
not establish a MorletDB advantage or justify a new extension.
