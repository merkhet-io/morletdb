"""Independent result checks; no tuning or training the neural model."""
import argparse
import io
import json
from pathlib import Path
import time
import zipfile
import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from episodic import Encoder, METHODS, BUDGETS, split, support_ids
from hydraulic import save_json, sha


def manual_f1(truth,pred):
    scores=[]
    for c in range(4):
        tp=((truth==c)&(pred==c)).sum();fp=((truth!=c)&(pred==c)).sum();fn=((truth==c)&(pred!=c)).sum()
        den=2*tp+fp+fn;scores.append(2*tp/den if den else 0.)
    return float(np.mean(scores))


def independent_gate(base,mem,dist,state):
    entropy=np.array([-sum(float(v)*np.log(float(v)) for v in row if v>0)/np.log(4) for row in mem])
    features=np.column_stack([base.max(1),mem.max(1),dist.mean(1),base.argmax(1)==mem.argmax(1),entropy])
    logits=np.array([sum(float(a)*float(b) for a,b in zip(row,state['weight'].numpy()[0]))+
                     float(state['bias'].numpy()[0]) for row in features])
    w=(1/(1+np.exp(-logits)))[:,None]
    return (1-w)*base+w*mem,w


def audit(out,data,archive):
    a=np.load(data);profile=a['profile'];blocks=a['blocks'];summary=[];torch.set_num_threads(2)
    run=json.loads((out/'run.json').read_text())
    assert run['input_sha256']==sha(data)
    root=Path(__file__).parent
    assert run['harness_sha256']==sha(root/'episodic.py')
    assert run['protocol_sha256']==sha(root/'EPISODIC_PROTOCOL.md')
    sources=json.loads((data.parent/'source.json').read_text())
    assert sha(archive)==sources['archive_sha256']
    all_refs=set();case_count=0
    for path in sorted(out.glob('*-cooler*.json')):
        result=json.loads(path.read_text());arr=np.load(path.with_suffix('.npz'))
        state=torch.load(path.with_suffix('.pt'),weights_only=True);model=Encoder()
        model.load_state_dict(state['encoder']);model.eval()
        q=arr['query_ids'];train=arr['train_ids'];val=arr['validation_ids'];truth=arr['truth']
        col=1 if result['target']=='valve' else 3
        labels=np.searchsorted(np.unique(profile[:,col]),profile[:,col])
        expected_split=split(profile,blocks,col,result['held_cooler'],result['seed'])
        for key,name in [('train_ids','train'),('validation_ids','validation'),('query_ids','query'),('support_pool_ids','support')]:
            np.testing.assert_array_equal(arr[key],expected_split[name])
        mean=a['temporal'][train].mean((0,1));std=a['temporal'][train].std((0,1));std=np.where(std>=1e-6,std,1)
        np.testing.assert_array_equal(mean,arr['temporal_mean']);np.testing.assert_array_equal(std,arr['temporal_std'])
        x=torch.tensor(((a['temporal']-mean)/std).transpose(0,2,1),dtype=torch.float32)
        begin=time.perf_counter()
        with torch.no_grad():z=model.embed(x).numpy();base=model(x).softmax(1).numpy()
        encode_time=time.perf_counter()-begin
        np.testing.assert_array_equal(z,arr['embeddings']);np.testing.assert_array_equal(base,arr['base_probabilities'])
        max_gate=0.;max_log=0.;max_rf=0.;max_gradient=0.;metrics_checked=0
        fm=a['features'][train].mean(0);fs=a['features'][train].std(0);fs=np.where(fs>=1e-6,fs,1.)
        np.testing.assert_array_equal(fm,arr['feature_mean']);np.testing.assert_array_equal(fs,arr['feature_std'])
        f=(a['features']-fm)/fs
        for bi,n in enumerate(BUDGETS):
            g=arr[f'n{n}_gallery'];ids=arr[f'n{n}_nearest_ids'];rids=arr[f'n{n}_random_ids']
            expected_g=np.r_[train,val,support_ids(arr['support_pool_ids'],n)]
            np.testing.assert_array_equal(g,expected_g)
            assert set(blocks[g]).isdisjoint(blocks[q]);assert np.isin(ids,g).all() and np.isin(rids,g).all()
            all_refs.update(g.tolist());all_refs.update(q.tolist())
            # Independent coordinate-wise sum and Python tuple ordering.
            dist=np.zeros((len(q),len(g)))
            for dim in range(z.shape[1]):dist+=(z[q,dim,None].astype(float)-z[g,dim][None,:].astype(float))**2
            expected=np.array([[g[j] for j in sorted(range(len(g)),key=lambda j:(row[j],g[j]))[:5]] for row in dist])
            np.testing.assert_array_equal(ids,expected)
            for j,qi in enumerate(q):
                actual=np.array([sum((float(z[qi,k])-float(z[gi,k]))**2 for k in range(64)) for gi in ids[j]])
                np.testing.assert_allclose(actual,arr[f'n{n}_distances'][j],rtol=1e-12,atol=1e-14)
            nearestp=np.array([[sum(labels[gi]==c for gi in row)/5 for c in range(4)] for row in ids])
            randomp=np.array([[sum(labels[gi]==c for gi in row)/5 for c in range(4)] for row in rids])
            shuffled_map=dict(zip(g,arr[f'n{n}_shuffled_labels']))
            shuffledp=np.array([[sum(shuffled_map[gi]==c for gi in row)/5 for c in range(4)] for row in ids])
            stressp=np.eye(4)[base[q].argmin(1)]
            np.testing.assert_array_equal(nearestp,arr['probabilities'][bi,METHODS.index('embedding-knn')])
            for name,mem,dd in [('gated-memory',nearestp,arr[f'n{n}_distances']),
                ('gated-random',randomp,arr[f'n{n}_random_distances']),
                ('gated-shuffled',shuffledp,arr[f'n{n}_distances']),
                ('gated-adversarial',stressp,arr[f'n{n}_random_distances'])]:
                pp,_=independent_gate(base[q],mem,dd,state['gate'])
                diff=float(np.max(abs(pp-arr['probabilities'][bi,METHODS.index(name)])))
                max_gate=max(max_gate,diff);assert diff<1e-6
            log=LogisticRegression(C=1,max_iter=2000).fit(z[g],labels[g])
            # No BLAS for independent logistic forward or gradient.
            logits=np.einsum('ij,kj->ik',z[q].astype(float),log.coef_,optimize=False)+log.intercept_
            ep=np.exp(logits-logits.max(1,keepdims=True));lp=ep/ep.sum(1,keepdims=True)
            diff=float(abs(lp-arr['probabilities'][bi,METHODS.index('adapted-logistic')]).max());max_log=max(max_log,diff);assert diff<1e-10
            tl=np.einsum('ij,kj->ik',z[g].astype(float),log.coef_,optimize=False)+log.intercept_
            ep=np.exp(tl-tl.max(1,keepdims=True));res=ep/ep.sum(1,keepdims=True)-np.eye(4)[labels[g]]
            grad=np.einsum('ik,ij->kj',res,z[g].astype(float),optimize=False)/len(g)+log.coef_/len(g)
            max_gradient=max(max_gradient,float(abs(grad).max()),float(abs(res.mean(0)).max()))
            forest=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,
                random_state=result['seed'],n_jobs=1).fit(f[g],labels[g])
            diff=float(abs(forest.predict_proba(f[q])-arr['probabilities'][bi,METHODS.index('adapted-RF')]).max())
            max_rf=max(max_rf,diff);assert diff==0
            for mi,method in enumerate(METHODS):
                pp=arr['probabilities'][bi,mi];ub=np.unique(blocks[q])
                # Original gate/controls were float64; encoder was float32. Preserve reduction dtype.
                if method=='encoder-only':pp=pp.astype('f4')
                bp=np.array([np.mean(pp[blocks[q]==b],axis=0) for b in ub])
                bt=np.array([truth[blocks[q]==b][0] for b in ub])
                saved=result['results'][bi]['metrics'][method]
                np.testing.assert_allclose(bp,saved['block_probabilities'],rtol=0,atol=1e-15)
                assert abs(manual_f1(bt,bp.argmax(1))-saved['block_macro_f1'])<1e-14
                metrics_checked+=1
        summary.append({'case':path.stem,'metric_sets':metrics_checked,'encoder_exact':True,
            'nearest_ids_exact':True,'gate_max_abs_error':max_gate,'logistic_max_abs_error':max_log,
            'logistic_max_gradient':max_gradient,'rf_max_abs_error':max_rf,
            'full_2205_cycle_encoder_and_head_seconds':encode_time})
        print('audited',path.stem,flush=True);case_count+=1
    assert case_count==30
    # Raw source check: all episodes involved, all14 physical sensor channels.
    refs=np.array(sorted(all_refs));source_checks=[]
    with zipfile.ZipFile(archive) as zf:
        for channel,spec in enumerate(sources['sensors']):
            content=zf.read(spec['member'])
            import hashlib
            assert hashlib.sha256(content).hexdigest()==spec['member_sha256']
            raw=np.loadtxt(io.BytesIO(content));derived=raw[refs].reshape(len(refs),60,spec['sample_rate_hz']).mean(2)
            np.testing.assert_array_equal(derived,a['temporal'][refs,:,channel])
            source_checks.append({'member':spec['member'],'cycles_checked':len(refs),'max_abs_error':0.})
    save_json(out/'audit.json',{'cases':summary,'source_checks':source_checks,'source_cycle_ids':refs.tolist(),
        'archive_sha256':sha(archive),'manifest_matches_harness_protocol_input':True})


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--data',type=Path,required=True)
    ap.add_argument('--archive',type=Path,required=True);args=ap.parse_args();audit(args.out,args.data,args.archive)
