"""Post-run numerical audit, not a new experiment or retuned model.

macOS Accelerate emitted matmul floating-point warnings. Recompute ridge predictions
using explicit einsum contractions (no BLAS matmul) and an independent positive-definite
linear solve. Verify EVERY saved source, cut-index and refit prediction. Reconstruct
the other arms from the audited source predictions using the frozen selectors.
"""
import json
from pathlib import Path
import sys
import numpy as np
from scipy.linalg import solve
from run import TOOLS, SEEDS, eligible, nearest, corrected


def ridge(X, y, Q, weights=None):
    w = np.ones(len(y)) if weights is None else weights
    xm = np.sum(X * w[:, None], axis=0) / w.sum()
    ym = np.sum(y * w) / w.sum()
    a, b = X - xm, y - ym
    gram = np.einsum('ni,nj,n->ij', a, a, w, optimize=False)
    rhs = np.einsum('ni,n,n->i', a, b, w, optimize=False)
    coef = solve(gram + 10*np.eye(X.shape[1]), rhs, assume_a='pos')
    result = np.einsum('ni,i->n', Q-xm, coef, optimize=False) + ym
    assert np.isfinite(result).all()
    return result


def main(out):
    d = np.load(out/'features.npz')
    X, y, tools, cuts = (d[k] for k in ('X', 'y', 'tool', 'cut'))
    saved = {(r['tool'], r['cut']): r['predictions'] for r in json.loads((out/'predictions.json').read_text())}
    errors = {}
    for tool in TOOLS:
        tr, te = tools != tool, tools == tool
        mu, sd = X[tr].mean(0), np.maximum(X[tr].std(0), 1e-8)
        a, b = (X[tr]-mu)/sd, (X[te]-mu)/sd
        ct, yt = cuts[te], y[te]
        source = ridge(a, y[tr], b)
        cx = np.c_[cuts, cuts**2].astype(float)
        cm, cs = cx[tr].mean(0), cx[tr].std(0)
        cp = ridge((cx[tr]-cm)/cs, y[tr], (cx[te]-cm)/cs)
        for i in np.flatnonzero(ct >= 31):
            avail = eligible(ct, ct[i])
            recent = avail[-5:]
            near, _ = nearest(b, ct, avail, b[i])
            p = {'source_ridge': max(0., float(source[i])), 'cut_ridge': max(0., float(cp[i])),
                 'latest_wear': float(yt[avail[-1]])}
            for name, refs in (('recent_residual', recent), ('similar_residual', near)):
                p[name] = corrected(source[i], source[refs], yt[refs])
            for seed in SEEDS:
                rng = np.random.default_rng(np.random.SeedSequence([seed, tool, int(ct[i])]))
                refs = rng.choice(avail, size=min(5, len(avail)), replace=False)
                p[f'random_{seed}'] = corrected(source[i], source[refs], yt[refs])
            # Explicit closed-form least-squares trend instead of polyfit.
            tx = ct[recent].astype(float)
            ry = yt[recent]-source[recent]
            slope = np.sum((tx-tx.mean())*(ry-ry.mean())) / np.sum((tx-tx.mean())**2)
            p['local_trend'] = max(0., float(source[i]+ry.mean()+slope*(ct[i]-tx.mean())))
            p['refit_ridge'] = max(0., float(ridge(np.vstack([a,b[avail]]), np.r_[y[tr],yt[avail]],
                b[i:i+1], np.r_[np.ones(len(a)),np.full(len(avail),len(a)/len(avail))])[0]))
            for arm, value in p.items():
                error = abs(value-saved[(tool,int(ct[i]))][arm])
                assert error < 1e-6, (tool, int(ct[i]), arm, error)
                errors[arm] = max(errors.get(arm, 0), error)
        print(f'Audited cutter {tool}', flush=True)
    result = {'queries': len(saved), 'all_predictions_finite': True,
              'max_absolute_error_by_arm': errors, 'tolerance_micrometres': 1e-6,
              'method': 'Explicit contractions and independent SPD solve; closed-form residual trend',
              'post_run_reason': 'Validate Apple Accelerate matmul warnings; original results unchanged'}
    (out/'numerical_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(Path(sys.argv[1]))
