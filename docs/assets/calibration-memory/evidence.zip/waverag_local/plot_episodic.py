"""Plot measured memory-growth results, not illustrative data."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).parent/'results'
s=json.loads((root/'episodic_summary.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(11,4.5),sharey=True)
styles={'encoder-only':('Frozen encoder','#888888'),
        'embedding-knn':('Embedding retrieval','#167c95'),
        'gated-memory':('Gated memory','#8057b1'),
        'gated-random':('Random-memory control','#d79842'),
        'adapted-RF':('Adapted random forest','#277e38')}
for ax,target in zip(axes,('valve','accumulator')):
    for m,(label,color) in styles.items():
        ax.plot(range(4),[s[target]['means'][str(n)][m] for n in (0,1,2,8)],marker='o',label=label,color=color)
    ax.set_title(target.capitalize());ax.set_xticks(range(4),['0','1','2','8'])
    ax.set_xlabel('New labelled episodes per class (categorical spacing)')
    ax.set_ylim(0,1);ax.grid(alpha=.2)
axes[0].set_ylabel('Block macro-F1 (higher is better)')
axes[1].legend(fontsize=8,loc='upper left')
fig.suptitle('WRL4: fixed encoder, growing memory; one hydraulic rig',fontsize=13)
fig.text(.5,.01,'Means over 3 cooler holdouts × 5 seeds. Exploratory; 96 source labels shared by all methods.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.04,1,.94));fig.savefig(root/'episodic_memory_growth.png',dpi=180)
