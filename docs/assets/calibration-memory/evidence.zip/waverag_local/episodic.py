"""WRL4: frozen encoder plus explicit episodic memory. See EPISODIC_PROTOCOL.md."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import platform
import time
import numpy as np
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
import torch
from torch import nn
from hydraulic import COOLERS, TARGETS, evaluate, nearest, save_json, sha

BUDGETS=(0,1,2,8)
METHODS=('stat-knn','encoder-only','embedding-knn','gated-memory','gated-random',
         'gated-shuffled','adapted-logistic','adapted-RF','gated-adversarial')


def split(profile,blocks,column,held,seed):
    rng=np.random.default_rng(4400+column*100+held)
    draw=np.random.default_rng(440000+seed)
    groups={'train':[],'validation':[],'support':[],'query':[]}
    stable=profile[:,4]==0
    for cooler in COOLERS:
        for label in np.unique(profile[:,column]):
            eligible=np.flatnonzero(stable&(profile[:,0]==cooler)&(profile[:,column]==label))
            bs=rng.permutation(np.unique(blocks[eligible]))
            assert len(bs)==12
            for j,b in enumerate(bs):
                ids=eligible[blocks[eligible]==b]
                if cooler==held:
                    name='support' if j<8 else 'query'
                else:
                    name='train' if j<8 else 'validation'
                groups[name].extend(ids.tolist() if name=='query' else [int(draw.choice(ids))])
    return {k:np.array(v,dtype=int) for k,v in groups.items()}


def support_ids(pool,n):
    return pool.reshape(4,8)[:,:n].reshape(-1)


def standardize(x,train,temporal=False):
    axes=(0,1) if temporal else 0
    mean=x[train].mean(axis=axes);sd=x[train].std(axis=axes)
    sd=np.where(sd>=1e-6,sd,1.)
    return (x-mean)/sd,mean,sd


class Encoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.features=nn.Sequential(nn.Conv1d(14,32,5,padding=2),nn.ReLU(),
            nn.Conv1d(32,64,5,padding=2),nn.ReLU(),nn.AdaptiveAvgPool1d(6),
            nn.Flatten(),nn.Linear(384,64),nn.Tanh())
        self.head=nn.Linear(64,4)
    def embed(self,x):return nn.functional.normalize(self.features(x),dim=1)
    def forward(self,x):return self.head(self.embed(x))


def fit_encoder(x,y,train,val,seed):
    torch.manual_seed(seed)
    m=Encoder();opt=torch.optim.Adam(m.parameters(),lr=.001,weight_decay=.0001)
    rng=np.random.default_rng(seed);losses=[];best=float('inf');state=None;chosen=-1
    for epoch in range(100):
        m.train();order=rng.permutation(train);loss_sum=0.
        for j in range(0,len(order),32):
            ids=order[j:j+32];opt.zero_grad()
            loss=nn.functional.cross_entropy(m(x[ids]),y[ids]);assert torch.isfinite(loss)
            loss.backward();opt.step();loss_sum+=loss.item()*len(ids)
        m.eval()
        with torch.no_grad():vl=nn.functional.cross_entropy(m(x[val]),y[val]).item()
        losses.append([loss_sum/len(train),vl])
        if vl<best:best=vl;state=copy.deepcopy(m.state_dict());chosen=epoch
    m.load_state_dict(state);m.eval()
    return m,losses,chosen


def squared(q,g):
    d=q[:,None,:].astype('f8')-g[None,:,:].astype('f8')
    return np.einsum('qnd,qnd->qn',d,d,optimize=False)


def memory(z,q,g,y,rng,mode='nearest',base=None):
    d=squared(z[q],z[g]);k=min(5,len(g))
    idx=nearest(d,g,k) if mode!='random' else np.stack([rng.choice(len(g),k,replace=False) for _ in q])
    labels=y[g].copy()
    if mode=='shuffled':labels=labels[rng.permutation(len(g))]
    p=np.eye(4)[labels[idx]].mean(1)
    if mode=='adversarial':
        # Same random references as supplied by caller, synthetic false labels.
        p=np.eye(4)[base.argmin(1)]
    return p,g[idx],np.take_along_axis(d,idx,axis=1),labels


def gate_features(base,mem,dist):
    entropy=-(mem*np.log(np.maximum(mem,1e-12))).sum(1)/np.log(4)
    return np.stack([base.max(1),mem.max(1),dist.mean(1),
        (base.argmax(1)==mem.argmax(1)).astype(float),entropy],axis=1).astype('f4')


def blend(base,mem,weight):return (1-weight)*base+weight*mem


def fit_gate(z,base,y,profile,train,val,seed):
    xs=[];bs=[];ms=[];ys=[];rng=np.random.default_rng(441000+seed)
    for cooler in np.unique(profile[train,0]):
        q=val[profile[val,0]==cooler];g=train[profile[train,0]!=cooler]
        for mode in ('nearest','random'):
            p,_,d,_=memory(z,q,g,y,rng,mode)
            xs.append(gate_features(base[q],p,d));bs.append(base[q]);ms.append(p);ys.append(y[q])
    x=torch.tensor(np.concatenate(xs));b=torch.tensor(np.concatenate(bs),dtype=torch.float32)
    mem=torch.tensor(np.concatenate(ms),dtype=torch.float32);truth=torch.tensor(np.concatenate(ys))
    gate=nn.Linear(5,1);nn.init.zeros_(gate.weight);nn.init.zeros_(gate.bias)
    opt=torch.optim.Adam(gate.parameters(),lr=.02,weight_decay=.01);losses=[]
    for _ in range(300):
        opt.zero_grad();p=blend(b,mem,gate(x).sigmoid())
        loss=-p[torch.arange(len(p)),truth].clamp_min(1e-9).log().mean()
        assert torch.isfinite(loss);loss.backward();opt.step();losses.append(loss.item())
    return gate.eval(),losses


def gated(gate,base,mem,d):
    with torch.no_grad():w=gate(torch.tensor(gate_features(base,mem,d))).sigmoid().numpy()
    return blend(base,mem,w),w


def case(a,target,held,seed,out):
    started=time.perf_counter();p=a['profile'];blocks=a['blocks'];col=TARGETS[target]
    y=np.searchsorted(np.unique(p[:,col]),p[:,col]);s=split(p,blocks,col,held,seed)
    train,val,q=s['train'],s['validation'],s['query'];source=np.r_[train,val]
    for name in ('train','validation','support'):
        assert set(blocks[s[name]]).isdisjoint(blocks[q])
    t,tm,ts=standardize(a['temporal'],train,True);f,fm,fs=standardize(a['features'],train)
    x=torch.tensor(t.transpose(0,2,1),dtype=torch.float32);truth=torch.tensor(y)
    model,losses,epoch=fit_encoder(x,truth,train,val,seed)
    with torch.no_grad():z=model.embed(x).numpy();base=model(x).softmax(1).numpy()
    assert np.isfinite(z).all() and np.isfinite(base).all()
    gate,gloss=fit_gate(z,base,y,p,train,val,seed)
    stem=f'{target}-cooler{held}-s{seed}'
    torch.save({'encoder':model.state_dict(),'gate':gate.state_dict()},out/(stem+'.pt'))
    allprob=[];results=[];arrays={'train_ids':train,'validation_ids':val,'query_ids':q,
        'support_pool_ids':s['support'],'query_blocks':blocks[q],'truth':y[q],
        'temporal_mean':tm,'temporal_std':ts,'feature_mean':fm,'feature_std':fs,
        'embeddings':z,'base_probabilities':base}
    for n in BUDGETS:
        support=support_ids(s['support'],n);g=np.r_[source,support]
        assert set(blocks[g]).isdisjoint(blocks[q]) and len(np.unique(g))==len(g)
        rng=np.random.default_rng(442000+seed*100+held+n)
        start=time.perf_counter();mp,ids,d,_=memory(z,q,g,y,rng)
        gp,w=gated(gate,base[q],mp,d);memory_time=time.perf_counter()-start
        rp,rids,rd,_=memory(z,q,g,y,rng,'random');gr,rw=gated(gate,base[q],rp,rd)
        sp,sids,sd,sl=memory(z,q,g,y,rng,'shuffled');gs,sw=gated(gate,base[q],sp,sd)
        adversarial=np.eye(4)[base[q].argmin(1)];ga,aw=gated(gate,base[q],adversarial,rd)
        fp,fids,fd,_=memory(f,q,g,y,rng)
        begin=time.perf_counter()
        log=LogisticRegression(C=1,max_iter=2000).fit(z[g],y[g])
        rf=RandomForestClassifier(n_estimators=200,max_features='sqrt',min_samples_leaf=1,
             random_state=seed,n_jobs=1).fit(f[g],y[g]);adapt_seconds=time.perf_counter()-begin
        prob={'stat-knn':fp,'encoder-only':base[q],'embedding-knn':mp,'gated-memory':gp,
              'gated-random':gr,'gated-shuffled':gs,'adapted-logistic':log.predict_proba(z[q]),
              'adapted-RF':rf.predict_proba(f[q]),'gated-adversarial':ga}
        assert tuple(prob)==METHODS
        for pp in prob.values():assert np.isfinite(pp).all() and np.allclose(pp.sum(1),1,atol=1e-6)
        allprob.append(np.stack(list(prob.values())))
        metrics={k:evaluate(pp,y[q],blocks[q]) for k,pp in prob.items()}
        arrays.update({f'n{n}_gallery':g,f'n{n}_nearest_ids':ids,f'n{n}_distances':d,
            f'n{n}_random_ids':rids,f'n{n}_random_distances':rd,f'n{n}_shuffled_labels':sl,
            f'n{n}_stat_ids':fids,f'n{n}_gate':w,f'n{n}_random_gate':rw,
            f'n{n}_shuffled_gate':sw,f'n{n}_adversarial_gate':aw})
        results.append({'budget_per_class':n,'gallery_size':len(g),'metrics':metrics,
            'purity':float((y[ids]==y[q,None]).mean()),'random_purity':float((y[rids]==y[q,None]).mean()),
            'gate_mean':float(w.mean()),'random_gate_mean':float(rw.mean()),
            'shuffled_gate_mean':float(sw.mean()),'adversarial_gate_mean':float(aw.mean()),
            'memory_batch_seconds':memory_time,'memory_ms_per_cycle':1000*memory_time/len(q),
            'adaptation_seconds':adapt_seconds})
    arrays['probabilities']=np.stack(allprob);np.savez_compressed(out/(stem+'.npz'),**arrays)
    save_json(out/(stem+'.json'),{'target':target,'held_cooler':held,'seed':seed,'methods':METHODS,
        'budgets':BUDGETS,'selected_epoch_zero_based':epoch,'encoder_losses':losses,'gate_losses':gloss,
        'train_ids':train.tolist(),'validation_ids':val.tolist(),'query_ids':q.tolist(),
        'support_pool_ids':s['support'].tolist(),'results':results,'seconds':time.perf_counter()-started})
    print(json.dumps({'case':stem,'seconds':round(time.perf_counter()-started,2),
        'n8_f1':{k:round(v['block_macro_f1'],4) for k,v in results[-1]['metrics'].items()}}),flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    assert not list(args.out.glob('*-cooler*.json')),'Use a fresh output directory'
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    save_json(args.out/'run.json',{'python':platform.python_version(),'numpy':np.__version__,
        'torch':torch.__version__,'sklearn':sklearn.__version__,'input_sha256':sha(args.input),
        'harness_sha256':sha(__file__),'protocol_sha256':sha(Path(__file__).with_name('EPISODIC_PROTOCOL.md'))})
    a=np.load(args.input)
    for target in TARGETS:
        for held in COOLERS:
            for seed in range(5):case(a,target,held,seed,args.out)


if __name__=='__main__':main()
