# Calibration memory: evidence accompanying the MorletDB research post

Snapshot: research/waverag-local-evidence, commit15f1c58. Prior WRL1–5 reports,
frozen protocols, source code, tests, summaries and audits are retained as recorded.
No original sensor recordings, credentials, virtual environments or model weights
are included. Original reports contain historical local reproduction paths;
the portable WRL5 instructions below supersede those paths for this package.

Primary study: waverag_local/BEARING_RESULTS.md and BEARING_PROTOCOL.md.
Primary result: waverag_local/results/bearing_summary.json.
Earlier negative result: waverag_local/EPISODIC_RESULTS.md (WRL4).

## Reproduce WRL5 (network and approximately0.5GB original data required)

Original data: Nguyen Duc Thuan and Hoang Si Hong, HUST bearing (Hanoi),
Mendeley DataV3, DOI10.17632/cbv7jyx4p9.3, CC BY4.0.
https://data.mendeley.com/datasets/cbv7jyx4p9/3

Environment used: Python3.12.13, NumPy2.2.6, SciPy1.16.3, scikit-learn1.7.2,
Torch2.9.0; CPU, two Torch threads. No GPU or database is required.
Platform and numerical-library differences can change fitted predictions.
Use a new output directory; completed outputs are not overwritten by the harness.

```sh
python3.12 -m venv .venv
. .venv/bin/activate
pip install numpy==2.2.6 scipy==1.16.3 scikit-learn==1.7.2 torch==2.9.0
mkdir run
cp source_metadata.json run/
python -m unittest discover -s waverag_local -p 'test_bearing_memory.py' -v
python waverag_local/download_bearing.py --out run
python waverag_local/bearing_memory.py prepare --out run
python waverag_local/bearing_memory.py select --out run
python waverag_local/bearing_memory.py confirm --out run
python waverag_local/summarize_bearing_memory.py --out run --destination reproduced-results
python waverag_local/audit_bearing_memory.py --out run
```

The eight WRL5 unit tests use synthetic fixtures. The complete historical test
suite additionally needs the other datasets described in its protocols.
`source_metadata.json` contains the original publisher URLs and SHA256 checksums.
All75 selected MAT files are checked before use. No resampling or raw replacement.
`MANIFEST.json` hashes the files in this package. Original run hashes are in
`original-run.json`; protocol and harness are identical to the frozen study.

Interpretation:20 target query acquisitions from two bearing-type groups on one
laboratory rig. Positive support budgets use one labelled zero-load acquisition
per class/type, split into correlated windows. No population significance, JEPA,
repair-outcome learning, deployment savings or database advantage was established.
